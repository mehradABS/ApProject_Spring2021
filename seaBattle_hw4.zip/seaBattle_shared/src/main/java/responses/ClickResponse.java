package responses;

import models.Board;
import responses.visitors.GameResponsesVisitors;
import responses.visitors.ResponseVisitor;

public class ClickResponse extends Response{

    private final String message;
    private final Board myBoard;

    public ClickResponse(String message, Board myBoard) {
        this.message = message;
        this.myBoard = myBoard;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((GameResponsesVisitors)responseVisitor).checkClickResponse(myBoard, message);
    }

    @Override
    public String getVisitorType() {
        return "GameResponsesVisitors";
    }
}
