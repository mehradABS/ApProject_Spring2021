package responses;

import responses.visitors.LoginResponseVisitor;
import responses.visitors.ResponseVisitor;

public class LoginResponse extends Response{


    private String answer;

    public LoginResponse(String answer) {
        this.answer = answer;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((LoginResponseVisitor)responseVisitor).checkLoginResponse(answer);
    }

    @Override
    public String getVisitorType() {
        return "loginResponseVisitor";
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
