package responses;

import models.Game;
import responses.visitors.ResponseVisitor;
import responses.visitors.VisitGamesResponseVisitor;

import java.util.List;

public class GetAllGamesResponse extends Response{

    private final List<Game> games;

    public GetAllGamesResponse(List<Game> games) {
        this.games = games;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((VisitGamesResponseVisitor)responseVisitor).setAllGamesInfo(games);
    }

    @Override
    public String getVisitorType() {
        return "VisitGamesResponseVisitor";
    }
}
