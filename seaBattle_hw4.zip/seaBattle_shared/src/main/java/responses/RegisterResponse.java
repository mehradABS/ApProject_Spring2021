package responses;

public class RegisterResponse extends LoginResponse{

    public RegisterResponse(String answer) {
        super(answer);
    }

    @Override
    public String getVisitorType() {
        return "registerResponseVisitor";
    }
}
