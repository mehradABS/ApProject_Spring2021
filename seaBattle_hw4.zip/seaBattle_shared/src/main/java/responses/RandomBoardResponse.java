package responses;

import models.Board;
import responses.visitors.GameInitialResponsesVisitors;
import responses.visitors.ResponseVisitor;

public class RandomBoardResponse extends Response{

    private final Board board;

    public RandomBoardResponse(Board board) {
        this.board = board;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((GameInitialResponsesVisitors)responseVisitor).setRandomBoard(board);
    }

    @Override
    public String getVisitorType() {
        return "GameInitialResponsesVisitors";
    }
}
