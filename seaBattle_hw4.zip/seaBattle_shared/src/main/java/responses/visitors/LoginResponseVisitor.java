package responses.visitors;

public interface LoginResponseVisitor extends ResponseVisitor{

    void checkLoginResponse(String answer);
}
