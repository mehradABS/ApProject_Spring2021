package responses.visitors;

import models.Player;

import java.util.List;

public interface ScoreBoardResponseVisitor extends ResponseVisitor{

    void setScoreBoard(List<Integer> onlinePlayers, List<Player> allPlayers);
}
