package responses.visitors;

import models.Board;

public interface GameResponsesVisitors extends ResponseVisitor{

    void checkClickResponse(Board myBoard ,String message);
    void getMyBoard(Board rivalBoard, String message);
}
