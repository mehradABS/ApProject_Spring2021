package responses.visitors;

import models.Board;
import models.Side;

public interface GameInitialResponsesVisitors extends ResponseVisitor{
    void visitResponse(Board board, Side side, String name);
    void setRandomBoard(Board board);
}
