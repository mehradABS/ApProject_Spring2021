package responses.visitors;

import models.Board;
import models.Side;

public interface StartRequestResponseVisitor extends ResponseVisitor {
    void checkResponse(String answer, Side side, Board board);
}
