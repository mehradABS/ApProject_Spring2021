package responses.visitors;

import models.Game;

import java.util.List;

public interface VisitGamesResponseVisitor extends ResponseVisitor{

    void setAllGamesInfo(List<Game> games);
    void setCurrentGameInfo(Game game);
}
