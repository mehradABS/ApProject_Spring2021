package responses.visitors;

public interface ResponseVisitor {

}
