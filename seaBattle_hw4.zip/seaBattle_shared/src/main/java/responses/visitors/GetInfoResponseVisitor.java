package responses.visitors;

import models.Player;

public interface GetInfoResponseVisitor extends ResponseVisitor{

    void setInfo(Player player);
}
