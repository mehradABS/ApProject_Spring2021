package responses;

import models.Player;
import responses.visitors.ResponseVisitor;
import responses.visitors.ScoreBoardResponseVisitor;

import java.util.List;

public class ScoreBoardResponse extends Response{

    private final List<Player> allPlayers;
    private final List<Integer> onlinePlayers;

    public ScoreBoardResponse(List<Player> allPlayers, List<Integer> onlinePlayers) {
        this.allPlayers = allPlayers;
        this.onlinePlayers = onlinePlayers;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((ScoreBoardResponseVisitor)responseVisitor).setScoreBoard(onlinePlayers,
                allPlayers);
    }

    @Override
    public String getVisitorType() {
        return "ScoreBoardResponseVisitor";
    }
}
