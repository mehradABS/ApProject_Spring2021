package responses;

import models.Player;
import responses.visitors.GetInfoResponseVisitor;
import responses.visitors.ResponseVisitor;

public class GetInfoResponse extends Response{
    private final Player player;

    public GetInfoResponse(Player player) {
        this.player = player;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((GetInfoResponseVisitor)responseVisitor).setInfo(player);
    }

    @Override
    public String getVisitorType() {
        return "GetInfoResponseVisitor";
    }
}
