package responses;

import models.Board;
import models.Side;
import responses.visitors.ResponseVisitor;
import responses.visitors.StartRequestResponseVisitor;

public class StartRequestResponse extends Response{

    private final Side side;
    private String answer;
    private final Board board;

    public StartRequestResponse(String answer, Side side, Board board) {
        this.answer = answer;
        this.side = side;
        this.board = board;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((StartRequestResponseVisitor)responseVisitor).checkResponse(answer,side,
                board);
    }

    @Override
    public String getVisitorType() {
        return "StartRequestResponseVisitor";
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

}
