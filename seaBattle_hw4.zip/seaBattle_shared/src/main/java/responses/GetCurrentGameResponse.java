package responses;


import models.Game;
import responses.visitors.ResponseVisitor;
import responses.visitors.VisitGamesResponseVisitor;

public class GetCurrentGameResponse extends Response{

    private final Game game;

    public GetCurrentGameResponse(Game game) {
        this.game = game;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((VisitGamesResponseVisitor)responseVisitor).setCurrentGameInfo(game);
    }

    @Override
    public String getVisitorType() {
        return "VisitGamesResponseVisitor";
    }
}
