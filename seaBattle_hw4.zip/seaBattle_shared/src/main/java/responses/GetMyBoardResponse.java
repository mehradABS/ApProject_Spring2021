package responses;

import models.Board;
import responses.visitors.GameResponsesVisitors;
import responses.visitors.ResponseVisitor;

public class GetMyBoardResponse extends Response {

    private final Board rivalBoard;
    private final String message;

    public GetMyBoardResponse(Board board, String message) {
        this.rivalBoard = board;
        this.message = message;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((GameResponsesVisitors)responseVisitor).getMyBoard(rivalBoard, message);
    }

    @Override
    public String getVisitorType() {
        return "GameResponsesVisitors";
    }
}
