package responses;


import models.Board;
import models.Side;
import responses.visitors.GameInitialResponsesVisitors;
import responses.visitors.ResponseVisitor;

public class GameStartedResponse extends Response {

    private final Board board;
    private final Side side;
    private final String rivalName;

    public GameStartedResponse(Board board, Side side, String rivalName) {
        this.board = board;
        this.side = side;
        this.rivalName = rivalName;
    }

    @Override
    public void visit(ResponseVisitor responseVisitor) {
        ((GameInitialResponsesVisitors)responseVisitor).visitResponse(board, side,
                rivalName);
    }

    @Override
    public String getVisitorType() {
        return "GameInitialResponsesVisitors";
    }
}
