package events;

import events.visitors.EventVisitor;
import events.visitors.GameEventsVisitor;
import models.Side;
import responses.Response;

public class GetMyBoard extends Event{

    private final Side side;

    public GetMyBoard(Side side) {
        this.side = side;
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((GameEventsVisitor)eventVisitor).sendMyBoard(side);
    }

    @Override
    public String getVisitorType() {
        return "GameEventsVisitor";
    }
}
