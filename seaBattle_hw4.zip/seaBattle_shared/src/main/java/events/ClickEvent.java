package events;

import events.visitors.EventVisitor;
import events.visitors.GameEventsVisitor;
import models.Side;
import responses.Response;

public class ClickEvent extends Event{

    private final int x_coordinate;
    private final int y_coordinate;
    private final Side side;

    public ClickEvent(int x_coordinate, int y_coordinate, Side side) {
        this.x_coordinate = x_coordinate;
        this.y_coordinate = y_coordinate;
        this.side = side;
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((GameEventsVisitor)eventVisitor).checkClickedCell(x_coordinate,
                y_coordinate, side);
    }

    @Override
    public String getVisitorType() {
        return "GameEventsVisitor";
    }
}
