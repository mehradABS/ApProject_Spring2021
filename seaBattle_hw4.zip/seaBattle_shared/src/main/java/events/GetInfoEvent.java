package events;

import events.visitors.EventVisitor;
import events.visitors.GetInfoEventVisitor;
import responses.Response;

public class GetInfoEvent extends Event{

    public GetInfoEvent() {

    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((GetInfoEventVisitor)eventVisitor).sendInfo();
    }

    @Override
    public String getVisitorType() {
        return "GetInfoEventVisitor";
    }
}
