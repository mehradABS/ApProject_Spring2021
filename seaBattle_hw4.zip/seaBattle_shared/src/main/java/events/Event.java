package events;

import events.visitors.EventVisitor;
import responses.Response;

public abstract class Event {

    protected long authToken;

    public abstract Response visit(EventVisitor eventVisitor);
    public abstract String getVisitorType();

    public long getAuthToken() {
        return authToken;
    }

    public void setAuthToken(long authToken) {
        this.authToken = authToken;
    }
}