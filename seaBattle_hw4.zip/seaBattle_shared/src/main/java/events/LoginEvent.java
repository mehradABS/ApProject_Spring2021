package events;

import events.visitors.EventVisitor;
import events.visitors.LoginEventVisitor;
import responses.Response;

public class LoginEvent extends Event{

    private String username;
    private String password;

    public LoginEvent() {
       super();
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((LoginEventVisitor)eventVisitor).checkLogin(username, password);
    }

    @Override
    public String getVisitorType() {
        return "loginEventVisitor";
    }


    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}