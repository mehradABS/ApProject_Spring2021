package events;

import events.visitors.EventVisitor;
import events.visitors.VisitGamesEventsVisitor;
import responses.Response;

public class GetCurrentGameEvent extends Event{

    private final int gameId;

    public GetCurrentGameEvent(int gameId) {
        this.gameId = gameId;
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((VisitGamesEventsVisitor)eventVisitor).sendGame(gameId);
    }

    @Override
    public String getVisitorType() {
        return "VisitGamesEventsVisitor";
    }
}
