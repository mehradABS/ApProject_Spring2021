package events;

import events.visitors.EventVisitor;
import events.visitors.GameEventsVisitor;
import models.Board;
import models.Side;
import responses.Response;

public class GameStartedEvent extends Event{

    private final Board board;
    private final Side side;


    public GameStartedEvent(Board board, Side side) {
        this.board = board;
        this.side = side;
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((GameEventsVisitor)eventVisitor).setPlayerBoard(board, side);
    }

    @Override
    public String getVisitorType() {
        return "GameEventsVisitor";
    }
}
