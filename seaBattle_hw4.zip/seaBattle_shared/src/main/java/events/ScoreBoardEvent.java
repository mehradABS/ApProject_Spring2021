package events;

import events.visitors.EventVisitor;
import events.visitors.ScoreBoardEventVisitor;
import responses.Response;

public class ScoreBoardEvent extends Event{

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((ScoreBoardEventVisitor)eventVisitor).sendScoreBoard();
    }

    @Override
    public String getVisitorType() {
        return "ScoreBoardEventVisitor";
    }
}
