package events;

import events.visitors.EventVisitor;
import events.visitors.VisitGamesEventsVisitor;
import responses.Response;

public class GetAllGamesEvent extends Event{

    public GetAllGamesEvent() {
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((VisitGamesEventsVisitor)eventVisitor).sendAllGames();
    }

    @Override
    public String getVisitorType() {
        return "VisitGamesEventsVisitor";
    }
}
