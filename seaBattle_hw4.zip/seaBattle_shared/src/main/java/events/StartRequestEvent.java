package events;

import events.visitors.EventVisitor;
import events.visitors.StartRequestEventVisitor;
import responses.Response;

public class StartRequestEvent extends Event{

    private final boolean begin;

    public StartRequestEvent(boolean begin) {
        this.begin = begin;
    }

    @Override
    public Response visit(EventVisitor eventVisitor) {
        return ((StartRequestEventVisitor)eventVisitor).checkStartGameRequest(begin);
    }

    @Override
    public String getVisitorType() {
        return "StartRequestEventVisitor";
    }
}