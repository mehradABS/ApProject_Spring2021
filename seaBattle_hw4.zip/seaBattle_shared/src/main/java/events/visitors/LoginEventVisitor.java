package events.visitors;

import responses.Response;

public interface LoginEventVisitor extends EventVisitor {

    Response checkLogin(String username, String password);
    Response checkRegistration(String username, String password);

}
