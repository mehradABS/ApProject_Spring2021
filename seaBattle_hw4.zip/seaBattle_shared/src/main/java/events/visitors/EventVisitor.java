package events.visitors;

public interface EventVisitor {
}
