package events.visitors;

import responses.Response;

public interface ScoreBoardEventVisitor extends EventVisitor{

    Response sendScoreBoard();
}
