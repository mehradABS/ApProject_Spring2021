package events.visitors;

import responses.Response;

public interface StartRequestEventVisitor extends EventVisitor {
    Response checkStartGameRequest(boolean begin);
}