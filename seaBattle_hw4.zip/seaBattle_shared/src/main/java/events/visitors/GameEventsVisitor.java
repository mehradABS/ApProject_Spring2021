package events.visitors;

import models.Board;
import models.Side;
import responses.Response;

public interface GameEventsVisitor extends EventVisitor{

    Response setPlayerBoard(Board board, Side side);
    Response checkClickedCell(int x, int y, Side side);
    Response sendMyBoard(Side side);
    Response setRandomBoard(Side side);

}
