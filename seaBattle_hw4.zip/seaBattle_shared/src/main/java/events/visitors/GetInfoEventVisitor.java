package events.visitors;

import responses.Response;

public interface GetInfoEventVisitor extends EventVisitor{

    Response sendInfo();
}
