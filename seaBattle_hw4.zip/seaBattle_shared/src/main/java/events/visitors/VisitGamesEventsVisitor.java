package events.visitors;

import responses.Response;

public interface VisitGamesEventsVisitor extends EventVisitor{

    Response sendAllGames();
    Response sendGame(int gameId);
}
