package models;

public enum CellCondition {
    DAMAGED,
    NOT_DAMAGED
}