package models;




import java.util.Random;


public class Game {

    private static int ID_COUNTER = 0;
    private static final Object LOCK = new Object();
    private final Player playerOne;
    private final Player playerTwo;
    private Side side;
    private final Board board1;
    private final Board board2;
    private boolean isStarted = false;
    private boolean endGame = false;
    private final int id;
    private int playerOneActions = 0;
    private int playerOneSuccessfulActions = 0;
    private int playerTwoActions = 0;
    private int playerTwoSuccessfulActions = 0;

    public Game(Player playerOne, Player playerTwo) {
        synchronized (LOCK){
            ID_COUNTER ++;
            id = ID_COUNTER;
        }
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        int a = new Random().nextInt(2);
        if(a == 0){
            side = Side.PLAYER_ONE;
        }
        else{
            side = Side.PLAYER_TWO;
        }
        board1 = new Board(10, 10);
        board2 = new Board(10, 10);
    }

    public Board getMyBoard(Side side){
        if(side == Side.PLAYER_ONE){
            return board1;
        }
        else{
            return board2;
        }
    }

    public Board getRivalBoard(Side side){
        if(side == Side.PLAYER_ONE){
            return board2;
        }
        else{
            return board1;
        }
    }

    public Player getPlayerOne() {
        return playerOne;
    }

    public Player getPlayerTwo() {
        return playerTwo;
    }

    public Side getSide() {
        return side;
    }

    public void changeSide() {
        if(side == Side.PLAYER_ONE){
            side = Side.PLAYER_TWO;
        }
        else{
            side = Side.PLAYER_ONE;
        }
    }

    public void setStarted(boolean started) {
        this.isStarted = started;
    }

    public boolean isStarted() {
        return isStarted;
    }

    public boolean isEndGame() {
        return endGame;
    }

    public void setEndGame(boolean endGame) {
        this.endGame = endGame;
    }

    public int getId() {
        return id;
    }

    public int getPlayerOneActions() {
        return playerOneActions;
    }

    public void setPlayerOneActions(int playerOneActions) {
        this.playerOneActions = playerOneActions;
    }

    public int getPlayerOneSuccessfulActions() {
        return playerOneSuccessfulActions;
    }

    public void setPlayerOneSuccessfulActions(int playerOneSuccessfulActions) {
        this.playerOneSuccessfulActions = playerOneSuccessfulActions;
    }

    public int getPlayerTwoActions() {
        return playerTwoActions;
    }

    public void setPlayerTwoActions(int playerTwoActions) {
        this.playerTwoActions = playerTwoActions;
    }

    public int getPlayerTwoSuccessfulActions() {
        return playerTwoSuccessfulActions;
    }

    public void setPlayerTwoSuccessfulActions(int playerTwoSuccessfulActions) {
        this.playerTwoSuccessfulActions = playerTwoSuccessfulActions;
    }
}