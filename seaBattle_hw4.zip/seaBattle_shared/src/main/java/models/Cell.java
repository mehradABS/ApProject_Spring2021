package models;

public class Cell {

    private final int x_coordinate;
    private final int y_coordinate;
    private CellCondition cellCondition;
    private Boat boat = null;

    public Cell(int x_coordinate, int y_coordinate) {
        this.x_coordinate = x_coordinate;
        this.y_coordinate = y_coordinate;
        cellCondition = CellCondition.NOT_DAMAGED;
    }

    public int getX_coordinate() {
        return x_coordinate;
    }

    public int getY_coordinate() {
        return y_coordinate;
    }

    public void setCellCondition(CellCondition cellCondition) {
        this.cellCondition = cellCondition;
    }

    public CellCondition getCellCondition() {
        return cellCondition;
    }

    public Boat getBoat() {
        return boat;
    }

    public void setBoat(Boat boat) {
        this.boat = boat;
    }
}
