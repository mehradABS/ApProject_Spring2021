package models;

public enum Side {
    PLAYER_ONE
    ,PLAYER_TWO
}
