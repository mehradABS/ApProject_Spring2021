package models;


public class Player {

    private static int ID_COUNTER;
    private final int id;
    private final Account account;
    private static final Object LOCK = new Object();
    private boolean isReady = false;
    private int win;
    private int loose;

    public Player(Account account) {
        synchronized (LOCK) {
            ID_COUNTER++;
        }
        id = ID_COUNTER;
        this.account = account;
    }

    public static void setIdCounter(int idCounter) {
        synchronized (LOCK) {
            ID_COUNTER = idCounter;
        }
    }

    public int getId() {
        synchronized (LOCK) {
            return id;
        }
    }

    public Account getAccount() {
        return account;
    }

    public boolean isReady() {
        return isReady;
    }

    public void setReady(boolean ready) {
        isReady = ready;
    }

    public int getWin() {
        return win;
    }

    public void setWin(int win) {
        this.win = win;
    }

    public int getLoose() {
        return loose;
    }

    public void setLoose(int loose) {
        this.loose = loose;
    }
}