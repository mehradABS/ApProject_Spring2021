package models;


public class Boat {

    private final int length;
    private int numberOfDamagedCell = 0;
    private transient Cell firstCell;
    private transient Cell lastCell;
    private boolean damaged = false;

    public Boat(int length) {
        this.length = length;
    }

    public int getLength() {
        return length;
    }

    public void addToNumberOfDamagedCell(){
        numberOfDamagedCell++;
    }

    public boolean isDamaged(){
        return numberOfDamagedCell == length;
    }

    public Cell getFirstCell() {
        return firstCell;
    }

    public void setFirstCell(Cell firstCell) {
        this.firstCell = firstCell;
    }

    public Cell getLastCell() {
        return lastCell;
    }

    public void setLastCell(Cell lastCell) {
        this.lastCell = lastCell;
    }

    public int getNumberOfDamagedCell() {
        return numberOfDamagedCell;
    }

    public void setDamaged(boolean damaged) {
        this.damaged = damaged;
    }

    public boolean getDamaged(){
        return damaged;
    }
}