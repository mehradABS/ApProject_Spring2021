package models;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Board {

    private static final Random RANDOM = new Random();
    private final Cell[][] cells;
    private final List<Boat> boats;

    public Board(int width, int height) {
        cells = new Cell[width][height];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                cells[i][j] = new Cell(i, j);
            }
        }
        boats = new LinkedList<>();
        addBoats();
    }

    public void addBoats(){
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 5-i ; j++) {
                 boats.add(new Boat(i));
            }
        }
    }

    public void setBoatsInRandom(){
        removeBoats();
        int r = RANDOM.nextInt(4);
        if(r == 0){
            cells[0][9].setBoat(boats.get(0));
            boats.get(0).setFirstCell(cells[0][9]);
            boats.get(0).setLastCell(cells[0][9]);
            cells[3][4].setBoat(boats.get(1));
            boats.get(1).setFirstCell(cells[3][4]);
            boats.get(1).setLastCell(cells[3][4]);
            cells[6][4].setBoat(boats.get(2));
            boats.get(2).setFirstCell(cells[6][4]);
            boats.get(2).setLastCell(cells[6][4]);
            cells[9][4].setBoat(boats.get(3));
            boats.get(3).setFirstCell(cells[9][4]);
            boats.get(3).setLastCell(cells[9][4]);
            cells[0][4].setBoat(boats.get(4));
            cells[0][5].setBoat(boats.get(4));
            boats.get(4).setFirstCell(cells[0][4]);
            boats.get(4).setLastCell(cells[0][5]);
            cells[0][2].setBoat(boats.get(5));
            cells[1][2].setBoat(boats.get(5));
            boats.get(5).setFirstCell(cells[0][2]);
            boats.get(5).setLastCell(cells[1][2]);
            cells[7][8].setBoat(boats.get(6));
            cells[7][9].setBoat(boats.get(6));
            boats.get(6).setFirstCell(cells[7][8]);
            boats.get(6).setLastCell(cells[7][9]);
            cells[3][0].setBoat(boats.get(7));
            cells[3][1].setBoat(boats.get(7));
            cells[3][2].setBoat(boats.get(7));
            boats.get(7).setFirstCell(cells[3][0]);
            boats.get(7).setLastCell(cells[3][2]);
            cells[4][6].setBoat(boats.get(8));
            cells[4][7].setBoat(boats.get(8));
            cells[4][8].setBoat(boats.get(8));
            boats.get(8).setFirstCell(cells[4][6]);
            boats.get(8).setLastCell(cells[4][8]);
            cells[6][1].setBoat(boats.get(9));
            cells[7][1].setBoat(boats.get(9));
            cells[8][1].setBoat(boats.get(9));
            cells[9][1].setBoat(boats.get(9));
            boats.get(9).setFirstCell(cells[6][1]);
            boats.get(9).setLastCell(cells[9][1]);
        }
        else if(r == 1){
            cells[0][8].setBoat(boats.get(0));
            boats.get(0).setFirstCell(cells[0][8]);
            boats.get(0).setLastCell(cells[0][8]);
            cells[3][9].setBoat(boats.get(1));
            boats.get(1).setFirstCell(cells[3][9]);
            boats.get(1).setLastCell(cells[3][9]);
            cells[5][0].setBoat(boats.get(2));
            boats.get(2).setFirstCell(cells[5][0]);
            boats.get(2).setLastCell(cells[5][0]);
            cells[5][9].setBoat(boats.get(3));
            boats.get(3).setFirstCell(cells[5][9]);
            boats.get(3).setLastCell(cells[5][9]);
            cells[0][1].setBoat(boats.get(4));
            cells[1][1].setBoat(boats.get(4));
            boats.get(4).setFirstCell(cells[0][1]);
            boats.get(4).setLastCell(cells[1][1]);
            cells[4][6].setBoat(boats.get(5));
            cells[4][7].setBoat(boats.get(5));
            boats.get(5).setFirstCell(cells[4][6]);
            boats.get(5).setLastCell(cells[4][7]);
            cells[7][7].setBoat(boats.get(6));
            cells[7][8].setBoat(boats.get(6));
            boats.get(6).setFirstCell(cells[7][7]);
            boats.get(6).setLastCell(cells[7][8]);
            cells[0][3].setBoat(boats.get(7));
            cells[0][4].setBoat(boats.get(7));
            cells[0][5].setBoat(boats.get(7));
            boats.get(7).setFirstCell(cells[0][3]);
            boats.get(7).setLastCell(cells[0][5]);
            cells[6][2].setBoat(boats.get(8));
            cells[7][2].setBoat(boats.get(8));
            cells[8][2].setBoat(boats.get(8));
            boats.get(8).setFirstCell(cells[6][2]);
            boats.get(8).setLastCell(cells[8][2]);
            cells[3][4].setBoat(boats.get(9));
            cells[4][4].setBoat(boats.get(9));
            cells[5][4].setBoat(boats.get(9));
            cells[6][4].setBoat(boats.get(9));
            boats.get(9).setFirstCell(cells[3][4]);
            boats.get(9).setLastCell(cells[6][4]);
        }
        else if(r == 2){
            cells[0][3].setBoat(boats.get(0));
            boats.get(0).setFirstCell(cells[0][3]);
            boats.get(0).setLastCell(cells[0][3]);
            cells[0][9].setBoat(boats.get(1));
            boats.get(1).setFirstCell(cells[0][9]);
            boats.get(1).setLastCell(cells[0][9]);
            cells[7][1].setBoat(boats.get(2));
            boats.get(2).setFirstCell(cells[7][1]);
            boats.get(2).setLastCell(cells[7][1]);
            cells[6][4].setBoat(boats.get(3));
            boats.get(3).setFirstCell(cells[6][4]);
            boats.get(3).setLastCell(cells[6][4]);
            cells[0][6].setBoat(boats.get(4));
            cells[1][6].setBoat(boats.get(4));
            boats.get(4).setFirstCell(cells[0][6]);
            boats.get(4).setLastCell(cells[1][6]);
            cells[4][4].setBoat(boats.get(5));
            cells[4][5].setBoat(boats.get(5));
            boats.get(5).setFirstCell(cells[4][4]);
            boats.get(5).setLastCell(cells[4][5]);
            cells[8][4].setBoat(boats.get(6));
            cells[8][5].setBoat(boats.get(6));
            boats.get(6).setFirstCell(cells[8][4]);
            boats.get(6).setLastCell(cells[8][5]);
            cells[1][0].setBoat(boats.get(7));
            cells[2][0].setBoat(boats.get(7));
            cells[3][0].setBoat(boats.get(7));
            boats.get(7).setFirstCell(cells[1][0]);
            boats.get(7).setLastCell(cells[3][0]);
            cells[4][7].setBoat(boats.get(8));
            cells[4][8].setBoat(boats.get(8));
            cells[4][9].setBoat(boats.get(8));
            boats.get(8).setFirstCell(cells[4][7]);
            boats.get(8).setLastCell(cells[4][9]);
            cells[6][7].setBoat(boats.get(9));
            cells[7][7].setBoat(boats.get(9));
            cells[8][7].setBoat(boats.get(9));
            cells[9][7].setBoat(boats.get(9));
            boats.get(9).setFirstCell(cells[6][7]);
            boats.get(9).setLastCell(cells[9][7]);
        }
        else{
            cells[0][9].setBoat(boats.get(0));
            boats.get(0).setFirstCell(cells[0][9]);
            boats.get(0).setLastCell(cells[0][9]);
            cells[1][6].setBoat(boats.get(1));
            boats.get(1).setFirstCell(cells[1][6]);
            boats.get(1).setLastCell(cells[1][6]);
            cells[6][2].setBoat(boats.get(2));
            boats.get(2).setFirstCell(cells[6][2]);
            boats.get(2).setLastCell(cells[6][2]);
            cells[8][6].setBoat(boats.get(3));
            boats.get(3).setFirstCell(cells[8][6]);
            boats.get(3).setLastCell(cells[8][6]);
            cells[3][9].setBoat(boats.get(4));
            cells[4][9].setBoat(boats.get(4));
            boats.get(4).setFirstCell(cells[3][9]);
            boats.get(4).setLastCell(cells[4][9]);
            cells[3][1].setBoat(boats.get(5));
            cells[3][2].setBoat(boats.get(5));
            boats.get(5).setFirstCell(cells[3][1]);
            boats.get(5).setLastCell(cells[3][2]);
            cells[5][0].setBoat(boats.get(6));
            cells[6][0].setBoat(boats.get(6));
            boats.get(6).setFirstCell(cells[5][0]);
            boats.get(6).setLastCell(cells[6][0]);
            cells[1][0].setBoat(boats.get(7));
            cells[1][1].setBoat(boats.get(7));
            cells[1][2].setBoat(boats.get(7));
            boats.get(7).setFirstCell(cells[1][0]);
            boats.get(7).setLastCell(cells[1][2]);
            cells[8][1].setBoat(boats.get(8));
            cells[8][2].setBoat(boats.get(8));
            cells[8][3].setBoat(boats.get(8));
            boats.get(8).setFirstCell(cells[8][1]);
            boats.get(8).setLastCell(cells[8][3]);
            cells[5][4].setBoat(boats.get(9));
            cells[5][5].setBoat(boats.get(9));
            cells[5][6].setBoat(boats.get(9));
            cells[5][7].setBoat(boats.get(9));
            boats.get(9).setFirstCell(cells[5][7]);
            boats.get(9).setLastCell(cells[5][4]);
        }
    }

    public Boat putBomb(int x, int y){
        cells[x][y].setCellCondition(CellCondition.DAMAGED);
        if(cells[x][y].getBoat() == null){
             return null;
        }
         cells[x][y].getBoat().addToNumberOfDamagedCell();
         return cells[x][y].getBoat();
    }

    public Cell[][] getCells() {
        return cells;
    }

    public List<Boat> getBoats() {
        return boats;
    }

    public void removeBoats(){
        for (Cell[] cell : cells) {
            for (int j = 0; j < cells[0].length; j++) {
                cell[j].setBoat(null);
            }
        }
    }
}