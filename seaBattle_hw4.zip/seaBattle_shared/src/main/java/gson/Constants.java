package gson;
// this class was written by sadat

public class Constants {
    public static final String CLASSNAME = "CLASSNAME";
    public static final String INSTANCE = "INSTANCE";
}