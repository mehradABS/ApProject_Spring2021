package graphic.game.authentication;


import auth.AuthToken;
import events.RegisterEvent;
import network.EventListener;
import responses.visitors.ResponseVisitor;

import java.util.HashMap;

public class RegistrationPanel extends LoginPanel {

    private final RegisterEvent registerEvent;

    public RegistrationPanel(EventListener eventListener, HashMap<String, ResponseVisitor>
            responseVisitors, AuthToken authToken) {
        super(eventListener, responseVisitors, authToken);
        //
        registerEvent = new RegisterEvent();
        //
        welcomeLabel.setText("welcome!");
        welcomeLabel.setBounds(680,240,600,200);
        loginButton.setText("register");
    }

    public void addResponseVisitor(HashMap<String, ResponseVisitor>
                                           responseVisitors){
        responseVisitors.put("registerResponseVisitor", this);
    }

    public void loginAction(){
        StringBuilder password = new StringBuilder();
        char[] a = passwordField.getPassword();
        for (char c : a) {
            password.append(c);
        }
        registerEvent.setUsername(usernameField.getText());
        registerEvent.setPassword(password.toString());
        eventListener.listen(registerEvent);
    }
}
