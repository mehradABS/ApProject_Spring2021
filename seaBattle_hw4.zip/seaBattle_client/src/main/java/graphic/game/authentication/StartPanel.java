package graphic.game.authentication;

import resources.Images;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class StartPanel extends JPanel{

    private final JButton loginButton;
    private final JButton registerButton;
    private final JLabel welcomeLabel;
    private StringListener stringListener;

    public StartPanel() {
        loginButton = new JButton("login");
        loginButton.setBounds(650,340,250,40);
        loginButton.setBackground(Color.decode("#3f51b5"));
        loginButton.setFocusable(false);
        loginButton.setFont(new Font("",Font.BOLD,20));
        loginButton.addActionListener(e->
        {
            try {
                listenMe(loginButton.getText());
            } catch (IOException ignored) {

            }
        });
        //
        registerButton = new JButton("register");
        registerButton.setBounds(650,390,250,40);
        registerButton.setBackground(Color.decode("#3f51b5"));
        registerButton.setFocusable(false);
        registerButton.setFont(new Font("",Font.BOLD,20));
        registerButton.addActionListener(e->
        {
            try {
                listenMe(registerButton.getText());
            } catch (IOException ignored) {

            }
        });
        //
        welcomeLabel = new JLabel("welcome to SeaBattle");
        welcomeLabel.setBounds(520,200,600,200);
        welcomeLabel.setForeground(Color.decode("#3e2723"));
        welcomeLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,50));
        //
        this.setLayout(null);
        this.add(welcomeLabel);
        this.add(registerButton);
        this.add(loginButton);
        this.setBounds(0,0,2000,800);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }


    public void listenMe(String buttonText) throws IOException {
        stringListener.stringEventOccurred(buttonText);
    }

    public void setListener(StringListener stringListener){
        this.stringListener = stringListener;
    }
}
