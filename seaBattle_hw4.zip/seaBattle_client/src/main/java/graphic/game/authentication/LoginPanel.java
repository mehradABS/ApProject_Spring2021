package graphic.game.authentication;


import auth.AuthToken;
import events.LoginEvent;
import network.EventListener;
import resources.Images;
import responses.visitors.LoginResponseVisitor;
import responses.visitors.ResponseVisitor;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;

public class LoginPanel extends JPanel implements LoginResponseVisitor {

    protected final JTextField usernameField;
    protected final JPasswordField passwordField;
    protected final JButton backButton;
    protected final JButton loginButton;
    protected final JLabel invalidLabel;
    protected StringListener stringListener;
    protected final JLabel welcomeLabel;
    protected final LoginEvent loginEvent;
    protected final EventListener eventListener;
    protected AuthToken authToken;

    public LoginPanel(EventListener eventListener, HashMap<String, ResponseVisitor>
            responseVisitors, AuthToken authToken) {
        this.authToken = authToken;
        //
        addResponseVisitor(responseVisitors);
        //
        this.eventListener = eventListener;
        //
        loginEvent = new LoginEvent();
        //
        welcomeLabel = new JLabel("welcome back!");
        welcomeLabel.setBounds(610,240,600,200);
        welcomeLabel.setForeground(Color.decode("#3e2723"));
        welcomeLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,50));
        //
        usernameField = new JTextField();
        usernameField.setBounds(650,390,250,40);
        usernameField.setBackground(Color.decode("#3f51b5"));
        usernameField.setFont(new Font("",Font.BOLD,20));
        //
        JLabel usernameLabel = new JLabel("username");
        usernameLabel.setBounds(540,390,130,40);
        usernameLabel.setForeground(Color.decode("#3e2723"));
        usernameLabel.setFont(new Font("",Font.BOLD,20));
        //
        passwordField = new JPasswordField();
        passwordField.setBounds(650,440,250,40);
        passwordField.setBackground(Color.decode("#3f51b5"));
        passwordField.setFont(new Font("",Font.BOLD,20));
        //
        JLabel passwordLabel = new JLabel("password");
        passwordLabel.setBounds(540,435,130,40);
        passwordLabel.setForeground(Color.decode("#3e2723"));
        passwordLabel.setFont(new Font("",Font.BOLD,20));
        //
        loginButton = new JButton("login");
        loginButton.setBounds(650,490,250,40);
        loginButton.setBackground(Color.decode("#3f51b5"));
        loginButton.setFocusable(false);
        loginButton.setFont(new Font("",Font.BOLD,20));
        loginButton.addActionListener(e-> loginAction());
        //
        invalidLabel = new JLabel();
        invalidLabel.setBounds(630,540,400,40);
        invalidLabel.setForeground(Color.decode("#f44336"));
        invalidLabel.setFont(new Font("",Font.BOLD,20));
        invalidLabel.setVisible(false);
        //
        backButton = new JButton("back");
        backButton.setBounds(520,490,100,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e->{
            resetPanel();
            try {
                listenMe(backButton.getText());
            } catch (IOException ignored) {

            }
        });
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        this.add(backButton);
        this.add(loginButton);
        this.add(passwordField);
        this.add(usernameField);
        this.add(welcomeLabel);
        this.add(passwordLabel);
        this.add(usernameLabel);
        this.add(invalidLabel);
    }

    public void addResponseVisitor(HashMap<String, ResponseVisitor>
                                           responseVisitors){
        responseVisitors.put("loginResponseVisitor", this);
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    public void setListener(StringListener stringListener){
        this.stringListener = stringListener;
    }

    public void loginAction(){
        StringBuilder password = new StringBuilder();
        char[] a = passwordField.getPassword();
        for (char c : a) {
            password.append(c);
        }
        loginEvent.setUsername(usernameField.getText());
        loginEvent.setPassword(password.toString());
        eventListener.listen(loginEvent);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void resetPanel(){
        invalidLabel.setVisible(false);
        passwordField.setText(null);
        usernameField.setText(null);
    }

    @Override
    public void checkLoginResponse(String message) {
         if(message.startsWith("ok")){
            authToken.setAuthToken(Long.parseLong(message.substring(2)));
            resetPanel();
            try {
                 listenMe("login");
             } catch (IOException e) {
                 System.out.println(e.getMessage());
             }
         }
         else{
             invalidLabel.setText(message);
             invalidLabel.setVisible(true);
             repaint();
             revalidate();
         }
    }
}