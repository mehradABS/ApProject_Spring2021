package graphic.game.authentication;


import auth.AuthToken;
import network.EventListener;
import responses.visitors.ResponseVisitor;
import view.listeners.StringListener;

import javax.swing.*;
import java.io.IOException;
import java.util.HashMap;

public class AuthenticationMainPanel extends JPanel {

    private  StringListener stringListener;
    private final StartPanel startPanel;
    private final RegistrationPanel registrationPanel;
    private final LoginPanel loginPanel;

    public AuthenticationMainPanel(EventListener eventListener,
                                   HashMap<String, ResponseVisitor> responseVisitors
    , AuthToken authToken) {
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        //
        startPanel = new StartPanel();
        startPanel.setListener(new StringListener() {
            @Override
            public void stringEventOccurred(String text) {
                if(text.equals("login")){
                    removeAll();
                    add(loginPanel);
                    repaint();
                    revalidate();
                }
                else if(text.equals("register")){
                    removeAll();
                    add(registrationPanel);
                    repaint();
                    revalidate();
                }
            }
        });
        //

        registrationPanel = new RegistrationPanel(eventListener, responseVisitors,
                 authToken);
        registrationPanel.setListener(text -> {
            if(text.equals("back")){
                 removeAll();
                 add(startPanel);
                 repaint();
                 revalidate();
            }
            else if(text.equals("login")){
                removeAll();
                repaint();
                revalidate();
                listenMe();
                add(startPanel);
            }
        });
        //
        loginPanel = new LoginPanel(eventListener, responseVisitors,
                 authToken);
        loginPanel.setListener(text -> {
            if(text.equals("login")){
                removeAll();
                repaint();
                revalidate();
                listenMe();
                add(startPanel);
            }
            else if(text.equals("back")){
                removeAll();
                add(startPanel);
                repaint();
                revalidate();
            }
        });
        //
        this.add(startPanel);
        repaint();
        revalidate();
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe() throws IOException {
        stringListener.stringEventOccurred("aut");
    }
}