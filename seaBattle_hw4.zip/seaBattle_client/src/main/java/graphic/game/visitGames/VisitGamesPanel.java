package graphic.game.visitGames;

import events.GetAllGamesEvent;
import events.GetCurrentGameEvent;
import models.Board;
import models.Game;
import models.Side;
import network.EventListener;
import resources.Images;
import responses.visitors.ResponseVisitor;
import responses.visitors.VisitGamesResponseVisitor;
import util.Loop;
import view.BoardView;
import view.CellView;
import view.GameInfoViewContainer;
import view.listeners.CellViewListener;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class VisitGamesPanel extends JPanel implements VisitGamesResponseVisitor {

    private int currentGameId;
    private final JButton backButton;
    private StringListener stringListener;
    private final GameInfoViewContainer gameInfoViewContainer;
    private final BoardView boardView1;
    private final BoardView boardView2;
    private final Loop getAllGamesLoop;
    private final Loop getCurrentGameLoop;
    private final JScrollPane scrollPane;
    private final EventListener eventListener;
    private final JLabel nameLabel1;
    private final JLabel nameLabel2;

    public VisitGamesPanel(EventListener eventListener,
                           HashMap<String, ResponseVisitor> responseVisitors) {
        nameLabel1 = new JLabel();
        nameLabel1.setBounds(500,640,600,200);
        nameLabel1.setForeground(Color.decode("#3e2723"));
        nameLabel1.setFont(new Font
                ("MV Boli",Font.PLAIN,30));
        nameLabel2 = new JLabel();
        nameLabel2.setBounds(1200,640,600,200);
        nameLabel2.setForeground(Color.decode("#3e2723"));
        nameLabel2.setFont(new Font
                ("MV Boli",Font.PLAIN,30));
        //
        this.eventListener = eventListener;
        responseVisitors.put("VisitGamesResponseVisitor", this);
        //
        getAllGamesLoop = new Loop(1, this::getAllGamesInfo);
        getCurrentGameLoop = new Loop(1, this::getCurrentGameInfo);
        //
        backButton = new JButton("back");
        backButton.setBounds(40,20,150,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e-> backButtonAction());
        //
        gameInfoViewContainer = new GameInfoViewContainer();
        scrollPane = new JScrollPane(gameInfoViewContainer,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(450,50,600,700);
        scrollPane.setViewportView(gameInfoViewContainer);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBackground(Color.CYAN);
        //
        boardView1 = new BoardView(100,100);
        boardView2 = new BoardView(800,100);
        CellViewListener cellViewListener = this::doNothing;
        boardView2.setCellViewsListener(cellViewListener);
        boardView1.setCellViewsListener(cellViewListener);
        //
        setLayout(null);
        setBounds(0,0,2000,800);
        add(scrollPane);
        add(backButton);
    }

    private void backButtonAction() {
         resetPanel();
        try {
            listenMe("back");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void doNothing(CellView cellView) {
    }

    public void getAllGamesInfo(){
        eventListener.listen(new GetAllGamesEvent());
    }

    public void getCurrentGameInfo(){
        eventListener.listen(new GetCurrentGameEvent(currentGameId));
    }

    public void setAllGamesInfo(List<Game> allGamesInfo){
        List<String[]> information = new LinkedList<>();
        for (Game game: allGamesInfo) {
             String one = game.getPlayerOne().getAccount().getUsername() +
                     ",  moves: " +
                     game.getPlayerOneActions() + " successfulMoves: "
                     +game.getPlayerOneSuccessfulActions();
            String two = game.getPlayerTwo().getAccount().getUsername() +
                    ",  moves: " +
                    game.getPlayerTwoActions() + " successfulMoves: "
                    +game.getPlayerTwoSuccessfulActions();
            String[] info = new String[3];
            info[0] = one;
            info[1] = two;
            info[2] = String.valueOf(game.getId());
            information.add(info);
        }
        gameInfoViewContainer.setInfo(information);
        gameInfoViewContainer.setListener(this::gameViewActionListener);
        repaint();
        revalidate();
    }

    public void setCurrentGameInfo(Game game){
        if(game != null) {
            boardView1.setInfo(game.getMyBoard(Side.PLAYER_ONE), false);
            boardView2.setInfo(game.getMyBoard(Side.PLAYER_TWO), false);
            nameLabel1.setText(game.getPlayerOne().getAccount().getUsername());
            nameLabel2.setText(game.getPlayerTwo().getAccount().getUsername());
            add(boardView1);
            add(boardView2);
            add(nameLabel1);
            add(nameLabel2);
            repaint();
            revalidate();
        }
    }

    public void resetPanel(){
       removeAll();
       add(scrollPane);
       add(backButton);
       repaint();
       revalidate();
       getAllGamesLoop.stop();
       getCurrentGameLoop.stop();
    }

    public void startLoop(){
        getAllGamesLoop.restart();
    }

    public void setListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void gameViewActionListener(int gameId){
         currentGameId = gameId;
         remove(scrollPane);
         repaint();
         revalidate();
         getAllGamesLoop.stop();
         getCurrentGameLoop.restart();
    }
}