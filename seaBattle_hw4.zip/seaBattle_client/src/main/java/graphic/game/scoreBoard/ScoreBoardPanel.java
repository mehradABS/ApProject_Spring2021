package graphic.game.scoreBoard;

import events.ScoreBoardEvent;
import models.Player;
import network.EventListener;
import resources.Images;
import responses.visitors.ResponseVisitor;
import responses.visitors.ScoreBoardResponseVisitor;
import util.Loop;
import view.GameInfoViewContainer;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class ScoreBoardPanel extends JPanel implements ScoreBoardResponseVisitor {

    private final GameInfoViewContainer gameInfoViewContainer;
    private final EventListener eventListener;
    private final Loop getScoreBoardLoop;
    private StringListener stringListener;

    public ScoreBoardPanel(EventListener eventListener,
                           HashMap<String, ResponseVisitor> responseVisitors) {
        JButton backButton = new JButton("back");
        backButton.setBounds(40,20,150,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e-> backButtonAction());
        //
        responseVisitors.put("ScoreBoardResponseVisitor", this);
        getScoreBoardLoop = new Loop(1, this::getScoreBoard);
        //
        this.eventListener = eventListener;
        //
        gameInfoViewContainer = new GameInfoViewContainer();
        JScrollPane scrollPane = new JScrollPane(gameInfoViewContainer,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(450,50,600,700);
        scrollPane.setViewportView(gameInfoViewContainer);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBackground(Color.CYAN);
        //
        setLayout(null);
        setBounds(0,0,2000,800);
        add(backButton);
        add(scrollPane);
    }

    private void gameViewActionListener(int id) {
     //do nothing
    }

    public void getScoreBoard(){
        eventListener.listen(new ScoreBoardEvent());
    }

    public void startLoop(){
        getScoreBoardLoop.restart();
    }

    private void backButtonAction() {
        try {
            listenMe("back");
        } catch (IOException e) {
            e.printStackTrace();
        }
        resetPanel();
    }

    public void setListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    public void resetPanel(){
        getScoreBoardLoop.stop();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void setScoreBoard(List<Integer> onlinePlayers, List<Player> allPlayers){
        List<String[]> information = new LinkedList<>();
        for (Player player: allPlayers) {
            String[] info = new String[3];
            info[0] = player.getAccount().getUsername() + "  score: " +
                    (player.getWin() - player.getLoose());
            if(onlinePlayers.contains(player.getId())){
                info[1] = "online";
            }
            else{
                info[1] = "offline";
            }
            info[2] = String.valueOf(player.getId());
            information.add(info);
        }
        gameInfoViewContainer.setInfo(information);
        gameInfoViewContainer.setListener(this::gameViewActionListener);
    }
}