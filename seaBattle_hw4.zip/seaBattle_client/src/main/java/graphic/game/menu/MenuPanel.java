package graphic.game.menu;

import resources.Images;
import view.listeners.StringListener;


import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class MenuPanel extends JPanel {

    private StringListener stringListener;

    public MenuPanel() {
        JButton startButton = new JButton("start Game");
        startButton.setBounds(650,230,250,40);
        startButton.setBackground(Color.decode("#3f51b5"));
        startButton.setFocusable(false);
        startButton.setFont(new Font("",Font.BOLD,20));
        startButton.addActionListener(e->
        {
            try {
                listenMe("start Game");
            } catch (IOException ignored) {

            }
        });
        //
        JButton visitButton = new JButton("visit Games");
        visitButton.setBounds(650,300,250,40);
        visitButton.setBackground(Color.decode("#3f51b5"));
        visitButton.setFocusable(false);
        visitButton.setFont(new Font("",Font.BOLD,20));
        visitButton.addActionListener(e->
        {
            try {
                listenMe("visit");
            } catch (IOException ignored) {

            }
        });
        //
        JButton scoreBoardButton = new JButton("scoreBoard");
        scoreBoardButton.setBounds(650,370,250,40);
        scoreBoardButton.setBackground(Color.decode("#3f51b5"));
        scoreBoardButton.setFocusable(false);
        scoreBoardButton.setFont(new Font("",Font.BOLD,20));
        scoreBoardButton.addActionListener(e->
        {
            try {
                listenMe("scoreBoard");
            } catch (IOException ignored) {

            }
        });
        //
        JButton infoButton = new JButton("info");
        infoButton.setBounds(650,440,250,40);
        infoButton.setBackground(Color.decode("#3f51b5"));
        infoButton.setFocusable(false);
        infoButton.setFont(new Font("",Font.BOLD,20));
        infoButton.addActionListener(e->
        {
            try {
                listenMe("info");
            } catch (IOException ignored) {

            }
        });
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        this.add(startButton);
        add(infoButton);
        add(scoreBoardButton);
        add(visitButton);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void listenMe(String buttonText) throws IOException {
        stringListener.stringEventOccurred(buttonText);
    }

    public void setListener(StringListener stringListener){
        this.stringListener = stringListener;
    }

}