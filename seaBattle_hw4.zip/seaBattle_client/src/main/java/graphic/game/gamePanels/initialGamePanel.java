package graphic.game.gamePanels;

import events.GameStartedEvent;
import events.RefreshBoardEvent;
import models.Board;
import models.GameInfo;
import events.StartRequestEvent;
import models.Side;
import network.EventListener;
import resources.Images;
import responses.visitors.GameInitialResponsesVisitors;
import responses.visitors.ResponseVisitor;
import responses.visitors.StartRequestResponseVisitor;
import util.Loop;
import view.BoardView;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;

public class initialGamePanel extends JPanel implements StartRequestResponseVisitor
, GameInitialResponsesVisitors {

    private final JLabel waitingLabel;
    private StringListener stringListener;
    private final EventListener eventListener;
    private final Loop loop;
    private final Loop barLoop;
    private final GameInfo gameInfo;
    private final BoardView boardView;
    private final JButton refreshBoardButton;
    private final JButton readyButton;
    private final JButton backButton;
    private final JProgressBar bar;
    private final Loop getRivalBoardLoop;
    private int refreshCounter = 5;

    public initialGamePanel(EventListener eventListener,
                            HashMap<String, ResponseVisitor> responseVisitors
    , GameInfo gameInfo) {
        getRivalBoardLoop = new Loop(2, this::readyButtonAction);
        //
        bar = new JProgressBar(0, 100);
        bar.setFont(new Font("MV Boli",Font.PLAIN,25));
        bar.setValue(0);
        bar.setBounds(590,5,400,60);
        bar.setBackground(Color.BLACK);
        bar.setForeground(Color.RED);
        bar.setStringPainted(true);
        //
        boardView = new BoardView(500,100);
        //
        this.gameInfo = gameInfo;
        //
        responseVisitors.put("StartRequestResponseVisitor", this);
        responseVisitors.put("GameInitialResponsesVisitors", this);
        //
        loop = new Loop(2, this::getPanel);
        barLoop = new Loop(3, this::fillBar);
        //
        this.eventListener = eventListener;
        //
        backButton = new JButton("back");
        backButton.setEnabled(false);
        backButton.setBounds(650,340,250,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e-> backButtonAction());
        //
        waitingLabel = new JLabel();
        waitingLabel.setBounds(470,200,700,200);
        waitingLabel.setForeground(Color.decode("#3e2723"));
        waitingLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,50));
        //
        refreshBoardButton = new JButton(Images.REFRESH_IMAGE);
        refreshBoardButton.setBounds(660,710,100,50);
        refreshBoardButton.addActionListener(e-> refreshBoard());
        refreshBoardButton.setFocusable(false);
        refreshBoardButton.setFont(new Font("",Font.BOLD,20));
        refreshBoardButton.setBackground(Color.decode("#3f51b5"));
        refreshBoardButton.setText(String.valueOf(refreshCounter));
        //
        readyButton = new JButton("ready");
        readyButton.setBounds(765,710,150,50);
        readyButton.addActionListener(e-> getRivalBoardLoop.restart());
        readyButton.setFocusable(false);
        readyButton.setFont(new Font("",Font.BOLD,20));
        readyButton.setBackground(Color.decode("#3f51b5"));
        //
        this.setLayout(null);
        this.add(waitingLabel);
        this.add(backButton);
        this.setBounds(0,0,2000,800);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    public void setListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void backButtonAction(){
        try {
            listenMe("back");
            resetPanel();
        } catch (IOException e) {
            e.printStackTrace();
        }
        eventListener.listen(new StartRequestEvent(false));
    }

    public void getPanel(){
         eventListener.listen(new StartRequestEvent(true));
    }

    @Override
    public void checkResponse(String answer, Side side, Board board) {
         if(answer.equals("ok")){
             gameInfo.setSide(side);
             gameInfo.setBoard(board);
             setRandomBoard(board);
             repaint();
             revalidate();
             barLoop.restart();
             loop.stop();
         }
         else {
             waitingLabel.setText(answer);
             backButton.setEnabled(!answer.equals(""));
             repaint();
             revalidate();
         }
    }

    public void resetPanel(){
        loop.stop();
        waitingLabel.setText("");
        bar.setValue(0);
        backButton.setEnabled(false);
        refreshBoardButton.setEnabled(true);
        refreshCounter = 5;
        refreshBoardButton.setText(String.valueOf(refreshCounter));
        removeAll();
        add(waitingLabel);
        add(backButton);
        repaint();
        revalidate();
        barLoop.stop();
    }

    public void startLoop(){
        loop.restart();
    }

    public void refreshBoard(){
        refreshCounter--;
        if(refreshCounter >= 0) {
            refreshBoardButton.setText(String.valueOf(refreshCounter));
            bar.setValue(Math.max(0, bar.getValue() - 15));
            eventListener.listen(new RefreshBoardEvent(gameInfo.getSide()));
        }
        if(refreshCounter == 0){
            refreshBoardButton.setEnabled(false);
        }
    }

    public void setRandomBoard(Board board) {
        boardView.setInfo(board, true);
        removeAll();
        add(boardView);
        add(refreshBoardButton);
        add(readyButton);
        add(bar);
        repaint();
        revalidate();
    }

    public void readyButtonAction(){
        resetPanel();
        waitingLabel.setText("waiting for your rival");
        remove(backButton);
        repaint();
        revalidate();
        eventListener.listen(new GameStartedEvent(gameInfo.getBoard(), gameInfo
                .getSide()));
    }

    public void fillBar(){
        if(bar.getValue() < bar.getMaximum()){
            bar.setValue(bar.getValue() + 1);
        }
        else{
            getRivalBoardLoop.restart();
        }
    }

    @Override
    public void visitResponse(Board board, Side side, String rivalName) {
        if(board != null){
            gameInfo.setRivalName(rivalName);
            gameInfo.setRivalBoard(board);
            gameInfo.setTurn(side);
            try {
                listenMe("start");
            } catch (IOException e) {
                e.printStackTrace();
            }
            getRivalBoardLoop.stop();
            waitingLabel.setText("");
        }
        else{
            gameInfo.setTurn(side);
            gameInfo.setRivalName(rivalName);
        }
    }
}