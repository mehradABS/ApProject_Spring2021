package graphic.game.gamePanels;

import events.ClickEvent;
import events.GetMyBoard;
import models.Board;
import models.CellCondition;
import models.GameInfo;
import network.EventListener;
import resources.Images;
import responses.visitors.GameResponsesVisitors;
import responses.visitors.ResponseVisitor;
import util.Loop;
import view.BoardView;
import view.CellView;
import view.listeners.CellViewListener;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;

public class MainGamePanel extends JPanel implements GameResponsesVisitors {

    private final BoardView myBoard;
    private final BoardView rivalBoard;
    private StringListener stringListener;
    private final EventListener eventListener;
    private final JProgressBar bar;
    private final GameInfo gameInfo;
    private final Loop barLoop;
    private final Loop getMyBoardLoop;
    private final JButton putBombButton;
    private boolean putBombButtonPressed = false;
    private final JLabel rivalNameLabel;
    private final JButton backButton;
    private final JLabel resultLabel;


    public MainGamePanel(EventListener eventListener,
                         HashMap<String, ResponseVisitor> responseVisitors,
                         GameInfo gameInfo) {
        resultLabel = new JLabel();
        resultLabel.setBounds(650,200,700,200);
        resultLabel.setForeground(Color.decode("#3e2723"));
        resultLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,50));
        //
        backButton = new JButton("back");
        backButton.setBounds(650,340,250,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e-> backButtonAction());
        //
        CellViewListener cellViewListener = this::cellViewActionListener;
        //
        responseVisitors.put("GameResponsesVisitors", this);
        //
        getMyBoardLoop = new Loop(1, () -> eventListener.
                listen(new GetMyBoard(gameInfo.getSide())));
        barLoop = new Loop(3, this::fillBar);
        this.eventListener = eventListener;
        this.gameInfo = gameInfo;
        //
        bar = new JProgressBar(0, 100);
        bar.setFont(new Font("MV Boli",Font.PLAIN,25));
        bar.setValue(0);
        bar.setBounds(590,5,400,60);
        bar.setBackground(Color.BLACK);
        bar.setForeground(Color.RED);
        bar.setStringPainted(true);
        //
        myBoard = new BoardView(100,100);
        rivalBoard = new BoardView(800,100);
        myBoard.setCellViewsListener(cellViewListener);
        rivalBoard.setCellViewsListener(cellViewListener);
        //
        rivalNameLabel = new JLabel();
        rivalNameLabel.setBounds(1200,640,600,200);
        rivalNameLabel.setForeground(Color.decode("#3e2723"));
        rivalNameLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,30));
        //
        putBombButton = new JButton("Bomb");
        putBombButton.setBounds(665,710,150,50);
        putBombButton.addActionListener(e-> putBombButtonAction());
        putBombButton.setFocusable(false);
        putBombButton.setFont(new Font("",Font.BOLD,20));
        putBombButton.setBackground(getColor(putBombButtonPressed));
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        this.add(myBoard);
        this.add(rivalBoard);
        this.add(putBombButton);
        this.add(rivalNameLabel);
        this.add(bar);
    }

    private void backButtonAction() {
        resetPanel();
        try {
            listenMe("back");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void resetPanel(){
        removeAll();
        this.add(myBoard);
        this.add(rivalBoard);
        this.add(putBombButton);
        this.add(rivalNameLabel);
        this.add(bar);
        repaint();
        revalidate();
    }

    public void setListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void fillBar(){
        if(bar.getValue() < bar.getMaximum()){
            bar.setValue(bar.getValue() + 1);
        }
        else{
            changeTurn(-1, -1);
        }
    }

    public synchronized void putBombButtonAction(){
        putBombButtonPressed = !putBombButtonPressed;
        putBombButton.setBackground(getColor(putBombButtonPressed));
    }

    public void cellViewActionListener(CellView cellView){
        if(cellView.getBoardView() == rivalBoard && putBombButtonPressed){
            int x = cellView.getX_coordinate();
            int y = cellView.getY_coordinate();
            if(gameInfo.getRivalBoard().getCells()[x][y].getCellCondition() ==
               CellCondition.NOT_DAMAGED){
                 changeTurn(x, y);
            }
        }
    }

    public void setInitialInfo(){
        myBoard.setInfo(gameInfo.getBoard(), true);
        rivalBoard.setInfo(gameInfo.getRivalBoard(), false);
        rivalNameLabel.setText(gameInfo.getRivalName());
        if(gameInfo.getTurn() == gameInfo.getSide()){
            barLoop.restart();
        }
        else{
            getMyBoardLoop.restart();
            putBombButton.setEnabled(false);
            putBombButtonPressed = false;
            putBombButton.setBackground(getColor(false));
        }
        repaint();
        revalidate();
    }

    public synchronized void changeTurn(int x, int y) {
        putBombButtonPressed = false;
        putBombButton.setBackground(getColor(false));
        putBombButton.setEnabled(false);
        repaint();
        revalidate();
        bar.setValue(0);
        barLoop.stop();
        eventListener.listen(new ClickEvent(x, y, gameInfo.getSide()));
    }

    @Override
    public void checkClickResponse(Board rivalBoard,String message) {
        gameInfo.setRivalBoard(rivalBoard);
        this.rivalBoard.setInfo(rivalBoard, false);
        if(message.equals("noNo")){
            getMyBoardLoop.restart();
        }
        else if(message.equals("noYes")){
            putBombButton.setEnabled(true);
            barLoop.restart();
        }
        else if(message.equals("yesYes")){
            removeAll();
            resultLabel.setText("you won!");
            add(backButton);
            add(resultLabel);
            repaint();
            revalidate();
        }
        repaint();
        revalidate();
    }

    @Override
    public void getMyBoard(Board myBoard, String message) {
        if(message.equals("yesYes") || message.equals("noYes")){
            removeAll();
            resultLabel.setText("you loosed!");
            add(backButton);
            add(resultLabel);
            repaint();
            revalidate();
            getMyBoardLoop.stop();
        }
        else if(message.equals("noNo")){
             gameInfo.setBoard(myBoard);
             this.myBoard.setInfo(myBoard, true);
             repaint();
             revalidate();
        }
        else{
             gameInfo.setBoard(myBoard);
             this.myBoard.setInfo(myBoard, true);
             putBombButton.setEnabled(true);
             barLoop.restart();
             repaint();
             revalidate();
             getMyBoardLoop.stop();
        }
    }

    public Color getColor(boolean f){
        if(f){
            return Color.cyan;
        }
        else{
            return Color.decode("#3f51b5");
        }
    }
}