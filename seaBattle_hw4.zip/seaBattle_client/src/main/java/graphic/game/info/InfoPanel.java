package graphic.game.info;

import events.GetInfoEvent;
import models.Player;
import network.EventListener;
import resources.Images;
import responses.visitors.GetInfoResponseVisitor;
import responses.visitors.ResponseVisitor;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.HashMap;

public class InfoPanel extends JPanel implements GetInfoResponseVisitor {

    private StringListener stringListener;
    private final EventListener eventListener;
    private final JLabel infoLabel;


    public InfoPanel(EventListener eventListener, HashMap<String, ResponseVisitor>
                     responseVisitors) {
        responseVisitors.put("GetInfoResponseVisitor",
                this);
        //
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.CYAN);
        panel.setBounds(400,300,600,200);
        infoLabel = new JLabel();
        infoLabel.setForeground(Color.decode("#3e2723"));
        infoLabel.setFont(new Font
                ("MV Boli",Font.PLAIN,25));
        infoLabel.setBounds(10, 10, 500, 100);
        //
        panel.add(infoLabel);
        this.eventListener = eventListener;
        JButton backButton = new JButton("back");
        backButton.setBounds(40,20,150,40);
        backButton.setBackground(Color.decode("#3f51b5"));
        backButton.setFocusable(false);
        backButton.setFont(new Font("",Font.BOLD,20));
        backButton.addActionListener(e-> backButtonAction());
        //
        setLayout(null);
        add(backButton);
        add(panel);
        setBounds(0, 0, 2000, 800);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void setListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String text) throws IOException {
        stringListener.stringEventOccurred(text);
    }

    private void backButtonAction() {
        try {
            listenMe("back");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInfo(Player player){
           String info = player.getAccount().getUsername() +
           "   win : " + player.getWin() + "    loose: " +
           player.getLoose() + "  score : " +
                   (player.getWin() - player.getLoose());
           infoLabel.setText(info);
           repaint();
           revalidate();
    }

    public void getInfo(){
        eventListener.listen(new GetInfoEvent());
    }
}