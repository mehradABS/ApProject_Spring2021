package network;

import events.Event;

public interface EventListener {
    void listen(Event event);
}
