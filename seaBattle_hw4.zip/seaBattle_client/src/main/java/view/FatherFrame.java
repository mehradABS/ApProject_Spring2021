package view;

import auth.AuthToken;
import network.EventListener;
import responses.visitors.ResponseVisitor;

import javax.swing.*;
import java.util.HashMap;

public class FatherFrame extends JFrame {


    public FatherFrame(EventListener eventListener, HashMap<String, ResponseVisitor>
                        responseVisitors, AuthToken authToken)  {
       super();
        ProgramMainPanel programMainPanel = new ProgramMainPanel(eventListener,
                responseVisitors, authToken);
        //
        //
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(programMainPanel);
        this.pack();
        this.setLocationRelativeTo(null);
    }

    public void initialize(){
        this.setVisible(true);
    }
}
