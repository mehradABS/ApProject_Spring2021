package view;

import view.listeners.GameViewListener;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;

public class GameInfoViewContainer extends JPanel {

    private final List<GameInfoView> gameInfoViews = new LinkedList<>();


    public GameInfoViewContainer() {
        setLayout(null);
        setBackground(Color.CYAN);
    }

    public void setInfo(List<String[]> information){
        removeAll();
        gameInfoViews.removeAll(gameInfoViews);
        int h = 0;
        for (String[] info:information) {
            GameInfoView gameInfoView = new GameInfoView(0, h);
            gameInfoView.setInfo(info[0], info[1], info[2]);
            gameInfoViews.add(gameInfoView);
            add(gameInfoView);
            h += 260;
        }
        setPreferredSize(new Dimension(600, h));
        repaint();
        revalidate();
    }

    public void setListener(GameViewListener gameViewListener){
        for (GameInfoView gameInfoView : gameInfoViews) {
            gameInfoView.setGameViewListener(gameViewListener);
        }
    }
}
