package view;

import models.Cell;
import models.CellCondition;
import resources.Images;
import view.listeners.CellViewListener;

import javax.swing.*;
import java.awt.*;

public class CellView extends JButton {

    private CellViewListener cellViewListener;
    private BoardView boardView;
    private final int x_coordinate;
    private final int y_coordinate;

    public CellView(int x, int y, int width, int height, int i, int j) {
        x_coordinate = i;
        y_coordinate = j;
        this.setBackground(Color.decode("#29b6f6"));
        this.setBounds(x, y, width, height);
        this.setFocusable(false);
        this.addActionListener(e-> cellViewListener.listenMe(this));
    }

    public void setInfo(Cell cell, boolean myBoard){
        if(cell.getCellCondition() == CellCondition.NOT_DAMAGED){
            if(cell.getBoat() != null && myBoard){
                setIcon(Images.BOAT_IMAGE);
            }
            else{
                setIcon(null);
            }
        }
        else{
            if(cell.getBoat() == null){
                setIcon(Images.INCORRECT_IMAGE);
            }
            else{
                if(myBoard){
                    setIcon(Images.DAMAGED_BOAT_IMAGE);
                }
                else{
                    setIcon(Images.CORRECT_IMAGE);
                }
            }
        }
        repaint();
        revalidate();
    }

    public int getX_coordinate() {
        return x_coordinate;
    }

    public int getY_coordinate() {
        return y_coordinate;
    }

    public void setCellViewListener(CellViewListener cellViewListener) {
        this.cellViewListener = cellViewListener;
    }

    public BoardView getBoardView() {
        return boardView;
    }

    public void setBoardView(BoardView boardView) {
        this.boardView = boardView;
    }
}