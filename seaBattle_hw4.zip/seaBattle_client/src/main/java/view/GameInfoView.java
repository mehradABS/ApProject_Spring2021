package view;

import view.listeners.GameViewListener;

import javax.swing.*;
import java.awt.*;

public class GameInfoView extends JButton {

    private final JLabel playerOne;
    private final JLabel playerTwo;
    private int gameId;
    private GameViewListener gameViewListener;

    public GameInfoView(int x, int y) {
       playerOne = new JLabel();
       playerTwo = new JLabel();
       playerOne.setForeground(Color.decode("#3e2723"));
       playerTwo.setForeground(Color.decode("#3e2723"));
       playerOne.setFont(new Font
                ("MV Boli",Font.PLAIN,25));
       playerTwo.setFont(new Font
                ("MV Boli",Font.PLAIN,25));
       playerOne.setBounds(10, 10, 500, 100);
       playerTwo.setBounds(10, 120, 500, 100);
       //
       setLayout(null);
       setBounds(x, y, 600, 250);
       add(playerOne);
       add(playerTwo);
       addActionListener(e-> actionListener());
    }

    public void setInfo(String playerOneInfo, String playerTwoInfo, String gameId){
        playerOne.setText(playerOneInfo);
        playerTwo.setText(playerTwoInfo);
        this.gameId = Integer.parseInt(gameId);
    }

    public int getGameId() {
        return gameId;
    }

    public void setGameViewListener(GameViewListener gameViewListener) {
        this.gameViewListener = gameViewListener;
    }

    public void actionListener(){
        gameViewListener.listen(getGameId());
    }
}