package view;

import models.Board;
import view.listeners.CellViewListener;

import javax.swing.*;

public class BoardView extends JPanel {

    private final CellView[][] cellViews;

    public BoardView(int x, int y) {
        cellViews = new CellView[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                cellViews[i][j] = new CellView(i * 60, j * 60, 50, 50
                , i, j);
                cellViews[i][j].setBoardView(this);
                add(cellViews[i][j]);
            }
        }
        this.setLayout(null);
        this.setBounds(x, y, 600, 600);
    }

    public CellView[][] getCellViews() {
        return cellViews;
    }

    public void setInfo(Board board, boolean myBoard){
        for (int i = 0; i < board.getCells().length; i++) {
            for (int j = 0; j < board.getCells()[0].length; j++) {
                cellViews[i][j].setInfo(board.getCells()[i][j], myBoard);
            }
        }
        repaint();
        revalidate();
    }

    public void setCellViewsListener(CellViewListener cellViewListener){
        for (CellView[] cellView : cellViews) {
            for (int j = 0; j < cellViews[0].length; j++) {
                cellView[j].setCellViewListener(cellViewListener);
            }
        }
    }
}