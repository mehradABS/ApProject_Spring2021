package view.listeners;

import view.CellView;

public interface CellViewListener {
    void listenMe(CellView cellView);
}
