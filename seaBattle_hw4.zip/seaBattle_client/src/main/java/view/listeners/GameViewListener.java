package view.listeners;

public interface GameViewListener {

    void listen(int gameId);
}
