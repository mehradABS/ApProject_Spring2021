package view;

import auth.AuthToken;
import graphic.game.gamePanels.MainGamePanel;
import graphic.game.info.InfoPanel;
import graphic.game.scoreBoard.ScoreBoardPanel;
import graphic.game.visitGames.VisitGamesPanel;
import models.GameInfo;
import graphic.game.authentication.AuthenticationMainPanel;
import graphic.game.gamePanels.initialGamePanel;
import graphic.game.menu.MenuPanel;
import network.EventListener;
import resources.Images;
import responses.visitors.ResponseVisitor;
import view.listeners.StringListener;


import javax.swing.*;
import java.awt.*;


import java.util.HashMap;

public class ProgramMainPanel extends JPanel {

    public ProgramMainPanel(EventListener eventListener, HashMap<String, ResponseVisitor>
            responseVisitors, AuthToken authToken) {
        super();
        //
        InfoPanel infoPanel = new InfoPanel(eventListener, responseVisitors);
        ScoreBoardPanel scoreBoardPanel = new ScoreBoardPanel(eventListener,
                responseVisitors);
        VisitGamesPanel visitGamesPanel = new VisitGamesPanel(eventListener,
                responseVisitors);
        GameInfo gameInfo = new GameInfo();
        MainGamePanel mainGamePanel = new MainGamePanel(eventListener,
                responseVisitors, gameInfo);
        MenuPanel menuPanel = new MenuPanel();
        AuthenticationMainPanel authenticationMainPanel =
                new AuthenticationMainPanel(eventListener,
                        responseVisitors, authToken);
        initialGamePanel initialGamePanel = new initialGamePanel
                (eventListener, responseVisitors, gameInfo);
        //
        authenticationMainPanel.setStringListener(text -> {
            backToPanel(menuPanel);
        });
        //
        menuPanel.setListener(text -> {
            if(text.equals("start Game")) {
                removeAll();
                initialGamePanel.startLoop();
                add(initialGamePanel);
                repaint();
                revalidate();
            }
            else if(text.equals("visit")){
                removeAll();
                visitGamesPanel.startLoop();
                add(visitGamesPanel);
                repaint();
                revalidate();
            }
            else if(text.equals("scoreBoard")){
                removeAll();
                scoreBoardPanel.startLoop();
                add(scoreBoardPanel);
                repaint();
                revalidate();
            }
            else if(text.equals("info")){
                removeAll();
                infoPanel.getInfo();
                add(infoPanel);
                repaint();
                revalidate();
            }
        });
        //
        initialGamePanel.setListener(text -> {
            if(text.equals("back")){
                backToPanel(menuPanel);
            }
            else if(text.equals("start")){
                removeAll();
                mainGamePanel.setInitialInfo();
                add(mainGamePanel);
                repaint();
                revalidate();
            }
        });
        //
        mainGamePanel.setListener(text -> {
            if(text.equals("back")){
                backToPanel(menuPanel);
            }
        });
        //
        visitGamesPanel.setListener(text -> {
           if(text.equals("back")){
               backToPanel(menuPanel);
           }
        });
        //
        scoreBoardPanel.setListener(text -> {
            if(text.equals("back")){
                backToPanel(menuPanel);
            }
        });
        //
        infoPanel.setListener(text -> {
            if(text.equals("back")){
                backToPanel(menuPanel);
            }
        });
        //
        setLayout(null);
        setPreferredSize(new Dimension(2000,800));
        add(authenticationMainPanel);
        repaint();
        revalidate();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void backToPanel(JPanel menuPanel){
        removeAll();
        add(menuPanel);
        repaint();
        revalidate();
    }
}
