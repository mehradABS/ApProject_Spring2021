package models;



public class GameInfo {

    private Side side;
    private Side turn;
    private Board board;
    private Board rivalBoard;
    private String rivalName;

    public GameInfo() {
        board = new Board(10,10);
    }

    public Side getSide() {
        return side;
    }

    public void setSide(Side side) {
        this.side = side;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public Board getRivalBoard() {
        return rivalBoard;
    }

    public void setRivalBoard(Board rivalBoard) {
        this.rivalBoard = rivalBoard;
    }

    public Side getTurn() {
        return turn;
    }

    public void setTurn(Side turn) {
        this.turn = turn;
    }

    public String getRivalName() {
        return rivalName;
    }

    public void setRivalName(String rivalName) {
        this.rivalName = rivalName;
    }
}