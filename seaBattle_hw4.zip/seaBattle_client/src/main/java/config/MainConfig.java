package config;

import resources.Images;
import resources.ServerAddress;

import javax.swing.*;
import java.awt.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class MainConfig {

    public MainConfig() {
         setConfig();
    }

    private void setConfig(){
        Properties mainProperty = new Properties();
        Properties portProperty = new Properties();
        Properties imagePathProperty = new Properties();
        try {
            String mainConfigFilePath =
                    "src\\main\\resources\\configs\\mainConfig\\filesPaths";
            mainProperty.load(new FileReader(mainConfigFilePath));
            String portFilePath = (String) mainProperty.get("portsPath");
            portProperty.load(new FileReader(portFilePath));
            ServerAddress.MAIN_ADDRESS =(String) portProperty.get("MAIN_Address");
            ServerAddress.MAIN_PORT =Integer.parseInt(
                    (String) portProperty.get("MAIN_PORT"));
            //TODO
            String imagesPaths = (String) mainProperty.get("imagesPaths");
            imagePathProperty.load(new FileReader(imagesPaths));
            Images.START_PANEL_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("START_PANEL_IMAGE")).getImage();
            Images.CORRECT_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("CORRECT_IMAGE"));
            Images.INCORRECT_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("INCORRECT_IMAGE"));
            Images.BOAT_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("BOAT_IMAGE"));
            Images.DAMAGED_BOAT_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("DAMAGED_BOAT_IMAGE"));
            Images.REFRESH_IMAGE = new ImageIcon(
                    (String)imagePathProperty.get("REFRESH_IMAGE"));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
