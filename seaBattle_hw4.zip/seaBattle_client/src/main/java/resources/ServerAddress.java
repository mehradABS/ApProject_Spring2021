package resources;

public class ServerAddress {
    public static String MAIN_ADDRESS;
    public static int MAIN_PORT;
}
