package resources;

import javax.swing.*;
import java.awt.*;

public class Images {

    public static Image START_PANEL_IMAGE;
    public static ImageIcon CORRECT_IMAGE;
    public static ImageIcon INCORRECT_IMAGE;
    public static ImageIcon BOAT_IMAGE;
    public static ImageIcon DAMAGED_BOAT_IMAGE;
    public static ImageIcon REFRESH_IMAGE;

}
