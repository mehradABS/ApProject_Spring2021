package controller;

import auth.AuthToken;
import events.Event;
import network.EventSender;
import network.SocketEventSender;
import responses.Response;
import responses.visitors.ResponseVisitor;
import util.Loop;
import view.FatherFrame;

import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class MainController {

    private final FatherFrame fatherFrame;
    private final Loop loop;
    private final EventSender eventSender;
    private final List<Event> events;
    private final HashMap<String, ResponseVisitor> visitors;
    private final AuthToken authToken;

    public MainController(Socket socket) throws IOException {
        authToken = new AuthToken();
        visitors = new HashMap<>();
        events = new LinkedList<>();
        fatherFrame = new FatherFrame(this::addEvent, visitors, authToken);
        loop = new Loop(10, this::sendEvent);
        eventSender = new SocketEventSender(socket);
    }

    public void start(){
        loop.start();
        fatherFrame.initialize();
    }

    public void addEvent(Event event){
        event.setAuthToken(authToken.getAuthToken());
        synchronized (events){
            events.add(event);
        }
    }

    public void sendEvent(){
        List<Event> temp;
        synchronized (events) {
            temp = new LinkedList<>(events);
            events.clear();
        }
        for (Event event : temp) {
            Response response = eventSender.sendEvent(event);
            response.visit(visitors.get(response.getVisitorType()));
        }
    }
}