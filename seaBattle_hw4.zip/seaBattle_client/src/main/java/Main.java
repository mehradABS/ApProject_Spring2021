import config.MainConfig;
import controller.MainController;
import resources.ServerAddress;

import java.io.IOException;
import java.net.Socket;

public class Main {
    public static void main(String[] args) {
        new MainConfig();
        try {
            Socket socket = new Socket
                    (ServerAddress.MAIN_ADDRESS, ServerAddress.MAIN_PORT);
            new MainController(socket).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
