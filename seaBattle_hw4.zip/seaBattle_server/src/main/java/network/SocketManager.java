package network;


import game.ClientHandler;
import game.GameLobby;
import resources.Ports;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketManager extends Thread{
    @Override
    public void run() {
        try {
            GameLobby gameLobby = new GameLobby();
            ServerSocket serverSocket = new ServerSocket(Ports.MAIN_PORT);
            while (true){
                Socket socket = serverSocket.accept();
                new ClientHandler(new SocketResponseSender(socket), gameLobby)
                        .start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}