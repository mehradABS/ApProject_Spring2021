package controller;

import db.Context;
import models.Game;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class MainController{


    protected static final List<Game> GAMES = new LinkedList<>();

    protected static final HashMap<Long, Integer> ONLINE_CLIENTS = new HashMap<>();

    protected final Context context;

    private static final SecureRandom secureRandom = new SecureRandom();

    public static long addClient(int id){
        synchronized (ONLINE_CLIENTS){
            long test;
            do {
                test = secureRandom.nextLong();
            } while (ONLINE_CLIENTS.containsKey(test) && test == 0);
            ONLINE_CLIENTS.put(test, id);
            return test;
        }
    }

    public static void removeClient(Long authToken){
        synchronized (ONLINE_CLIENTS){
            System.out.println("hi");
            ONLINE_CLIENTS.remove(authToken);
        }
    }

    public static boolean containsKey(Long test){
        synchronized (ONLINE_CLIENTS){
            return ONLINE_CLIENTS.containsKey(test);
        }
    }

    public static boolean containsValue(int id){
        synchronized (ONLINE_CLIENTS){
            return ONLINE_CLIENTS.containsValue(id);
        }
    }

    public MainController() {
          context = new Context();
    }

    public static void addGames(Game game){
        synchronized (GAMES){
            GAMES.add(game);
        }
    }

    public static void removeGames(Game game){
        synchronized (GAMES){
            GAMES.remove(game);
        }
    }

    public static List<Game> getStartedGames(){
        List<Game> games = new LinkedList<>(GAMES);
        List<Game> games1 = new LinkedList<>();
        for (Game game: games) {
            if(game.isStarted()){
                games1.add(game);
            }
        }
        return games1;
    }

    public static Game getGame(int gameId){
        List<Game> games = new LinkedList<>(GAMES);
        for (Game game: games) {
            if(game.getId() == gameId){
                return game;
            }
        }
        return null;
    }

    public static List<Integer> getOnlineClients(){
        return new LinkedList<>(ONLINE_CLIENTS.values());
    }


}