package config;

import resources.Paths;
import resources.Ports;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class MainConfig {

    public MainConfig() {
       setConfigs();
    }

    private void setConfigs(){
        Properties mainProperty = new Properties();
        Properties portProperty = new Properties();
        Properties pathsProperty = new Properties();
        try {
            String mainConfigFilePath =
                    "src\\main\\resources\\configs\\mainConfig\\filesPaths";
            mainProperty.load(new FileReader(mainConfigFilePath));
            String portFilePath = (String) mainProperty.get("portsPath");
            portProperty.load(new FileReader(portFilePath));
            Ports.MAIN_PORT =Integer.parseInt(
                    (String) portProperty.get("MAIN_PORT"));
            String jsonPaths = (String) mainProperty.get("paths");
            pathsProperty.load(new FileReader(jsonPaths));
            Paths.PLAYER_PATH = (String) pathsProperty.get("PLAYER_PATH");
            Paths.PLAYER_PATH_GET_ALL = (String) pathsProperty.get("" +
                    "PLAYER_PATH_GET_ALL");
            Paths.PLAYER_PATH_ID_COUNTER = (String) pathsProperty.get("" +
                    "PLAYER_PATH_ID_COUNTER");
            //TODO
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}