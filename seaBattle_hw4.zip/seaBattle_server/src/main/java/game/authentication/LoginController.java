package game.authentication;

import auth.AuthToken;
import controller.MainController;
import events.visitors.LoginEventVisitor;
import models.Account;
import models.Player;
import responses.LoginResponse;
import responses.RegisterResponse;
import responses.Response;

import java.io.IOException;
import java.util.List;

public class LoginController extends MainController implements LoginEventVisitor {

    private final AuthToken authToken;


    public LoginController(AuthToken authToken) {
        this.authToken = authToken;
    }

    @Override
    public Response checkLogin(String username, String password) {
        try {
            if(username.equals("") || password.equals("")){
                 return new LoginResponse("             enter your info");
            }
            List<Player> players = context.getPlayers().getAll();
            for (Player player: players) {
                if(player.getAccount().getUsername().equals(username)){
                    if(player.getAccount().getPassword().equals(password)){
                        if(containsValue(player.getId())){
                            return new LoginResponse("you logged in with " +
                                    "another device");
                        }
                        authToken.setAuthToken(addClient(player.getId()));
                        return new LoginResponse("ok" + authToken.getAuthToken());
                    }
                    else{
                        return new LoginResponse
                                ("invalid username or password");
                    }
                }
            }
            return new LoginResponse
                    ("invalid username or password");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Response checkRegistration(String username, String password) {
        try {
            if(username.equals("") || password.equals("")){
                return new RegisterResponse("           enter your info");
            }
            List<Player> players = context.getPlayers().getAll();
            for (Player player: players) {
                if(player.getAccount().getUsername().equals(username)){
                    return new RegisterResponse("       repeated username");
                }
                if(player.getAccount().getPassword().equals(password)){
                    return new RegisterResponse("       repeated password");
                }
            }
            Player.setIdCounter(context.getPlayers().getIDCounter());
            Player player = new Player(new Account(username, password));
            context.getPlayers().setIDCounter(player.getId());
            context.getPlayers().set(player);
            authToken.setAuthToken(addClient(player.getId()));
            return new RegisterResponse("ok" + authToken.getAuthToken());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }
}
