package game;


import auth.AuthToken;
import controller.MainController;
import db.Context;
import events.Event;
import events.visitors.EventVisitor;
import events.visitors.GetInfoEventVisitor;
import events.visitors.StartRequestEventVisitor;
import game.authentication.LoginController;
import game.info.GetInfoController;
import game.scoreBoard.ScoreBoard;
import game.visitGames.VisitGamesController;
import models.Game;
import models.Player;
import models.Side;
import network.ResponseSender;
import responses.Response;
import responses.StartRequestResponse;

import java.util.HashMap;
import java.util.NoSuchElementException;

public class ClientHandler extends Thread implements StartRequestEventVisitor{

    private final ResponseSender responseSender;
    private final HashMap<String, EventVisitor> visitors;
    private final AuthToken authToken;
    private final GameLobby gameLobby;
    private Game game = null;
    private Side side;

    public ClientHandler(ResponseSender responseSender, GameLobby gameLobby) {
        this.gameLobby = gameLobby;
        this.responseSender = responseSender;
        authToken = new AuthToken();
        visitors = new HashMap<>();
        setVisitors();
    }

    public long getId() {
        return authToken.getAuthToken();
    }

    public void setVisitors() {
        visitors.put("loginEventVisitor", new LoginController(authToken));
        visitors.put("StartRequestEventVisitor", this);
        visitors.put("GameEventsVisitor", new GameLogic());
        visitors.put("VisitGamesEventsVisitor", new VisitGamesController());
        visitors.put("ScoreBoardEventVisitor", new ScoreBoard());
        visitors.put("GetInfoEventVisitor", new GetInfoController(authToken));
    }

    public void run() {
        try {
            while (true) {
                Event event = responseSender.getEvent();
                if (authToken.getAuthToken() == 0) {
                    responseSender.sendResponse
                            (event.visit(visitors.get(event.getVisitorType())));
                } else if (authToken.getAuthToken() == event.getAuthToken()) {
                    responseSender.sendResponse
                            (event.visit(visitors.get(event.getVisitorType())));
                }
            }
        } catch (NoSuchElementException e) {
            System.out.println("salam");
            gameLobby.startGameRequest(this, false, getId());
            MainController.removeClient(authToken.getAuthToken());
            MainController.removeGames(game);
        }
    }

    @Override
    public Response checkStartGameRequest(boolean begin) {
        if (game == null) {
            String answer = gameLobby.startGameRequest(this, begin, getId());
            if(!answer.equals("ok")){
                return new StartRequestResponse(answer, side, null);
            }
        }
        game.getMyBoard(side).setBoatsInRandom();
        return new StartRequestResponse("ok", side, game.getMyBoard(side));
    }

    public void setGame(Game game) {
        this.game = game;
        ((GameLogic)visitors.get("GameEventsVisitor")).setGame(game);
    }

    public void setSide(Side side){
        this.side = side;
    }


}