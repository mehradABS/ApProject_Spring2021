package game.visitGames;


import controller.MainController;
import events.visitors.VisitGamesEventsVisitor;
import models.Game;
import responses.GetAllGamesResponse;
import responses.GetCurrentGameResponse;
import responses.Response;

import java.util.List;


public class VisitGamesController implements VisitGamesEventsVisitor {

    public VisitGamesController() {

    }


    @Override
    public Response sendAllGames() {
        List<Game> games = MainController.getStartedGames();
        return new GetAllGamesResponse(games);
    }

    @Override
    public Response sendGame(int gameId) {
        Game game = MainController.getGame(gameId);
        return new GetCurrentGameResponse(game);
    }
}