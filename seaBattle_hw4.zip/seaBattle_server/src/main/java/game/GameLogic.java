package game;



import controller.MainController;
import db.Context;
import events.visitors.GameEventsVisitor;
import models.Board;
import models.Boat;
import models.Game;
import models.Side;
import responses.*;

import java.io.IOException;


public class GameLogic implements GameEventsVisitor {

    private Game game;

    public GameLogic() {

    }

    public void setGame(Game game) {
        this.game = game;
    }

    public boolean gameStarted(){
        return game.getPlayerTwo().isReady() && game.getPlayerOne().isReady();
    }

    public synchronized String putBomb(int x, int y, Side side){
        Board board = game.getRivalBoard(side);
        Boat boat = board.putBomb(x, y);
        if(boat != null){
            if(side == Side.PLAYER_ONE){
                game.setPlayerOneSuccessfulActions(
                        game.getPlayerOneSuccessfulActions() + 1);
            }
            else{
                game.setPlayerTwoSuccessfulActions(
                        game.getPlayerTwoSuccessfulActions() + 1);
            }
            if(boat.isDamaged()){
                boat.setDamaged(true);
                int x1;
                int x2;
                int y1;
                int y2;
                if(boat.getFirstCell().getX_coordinate() == boat
                .getLastCell().getX_coordinate()){
                    if(boat.getLastCell().getY_coordinate() >
                            boat.getFirstCell().getY_coordinate()){
                        y1 = Math.max(boat.getFirstCell().getY_coordinate() - 1, 0);
                        y2 = Math.min(boat.getLastCell().getY_coordinate() + 1,
                                board.getCells()[0].length - 1);
                    }
                    else{
                        y1 = Math.max(boat.getLastCell().getY_coordinate() - 1, 0);
                        y2 = Math.min(boat.getFirstCell().getY_coordinate() + 1,
                                board.getCells()[0].length - 1);
                    }
                    x1 = Math.max(boat.getFirstCell().getX_coordinate() - 1, 0);
                    x2 = Math.min(boat.getFirstCell().getX_coordinate() + 1,
                            board.getCells().length - 1);
                }
                else{
                    if(boat.getFirstCell().getX_coordinate() >
                     boat.getLastCell().getX_coordinate()){
                        x1 = Math.max(boat.getLastCell().getX_coordinate() - 1, 0);
                        x2 = Math.min(boat.getFirstCell().getX_coordinate() + 1,
                                board.getCells().length - 1);
                    }
                    else{
                        x1 = Math.max(boat.getFirstCell().getX_coordinate() - 1, 0);
                        x2 = Math.min(boat.getLastCell().getX_coordinate() + 1,
                                board.getCells().length - 1);
                    }
                    y1 = Math.max(boat.getFirstCell().getY_coordinate() - 1, 0);
                    y2 = Math.min(boat.getLastCell().getY_coordinate() + 1,
                            board.getCells()[0].length - 1);
                }
                for (int i = x1; i <= x2; i++) {
                    for (int j = y1; j<= y2; j++) {
                        board.putBomb(i, j);
                    }
                }
                if(checkForEndGame(board, side)){
                     return "yesYes";
                }
                else{
                     return "noYes";
                }
            }
            return "noYes";
        }
        game.changeSide();
        return "noNo";
    }

    public boolean checkForEndGame(Board gameBoard, Side side){
        for (Boat boat: gameBoard.getBoats()) {
             if(!boat.getDamaged()){
                 return false;
             }
        }
        game.setEndGame(true);
        Context context = new Context();
        if(side == Side.PLAYER_ONE){
            game.getPlayerOne().setWin(game.getPlayerOne().getWin() + 1);
            game.getPlayerTwo().setLoose(game.getPlayerTwo().getLoose() + 1);
        }
        else{
            game.getPlayerTwo().setWin(game.getPlayerOne().getWin() + 1);
            game.getPlayerOne().setLoose(game.getPlayerTwo().getLoose() + 1);
        }
        try {
            context.getPlayers().set(game.getPlayerOne());
            context.getPlayers().set(game.getPlayerTwo());
        } catch (IOException e) {
            e.printStackTrace();
        }
        MainController.removeGames(game);
        return true;
    }

    @Override
    public Response setPlayerBoard(Board board, Side side) {
        String name;
        if(side == Side.PLAYER_ONE){
            game.getPlayerOne().setReady(true);
            name = game.getPlayerTwo().getAccount().getUsername();
        }
        else{
            game.getPlayerTwo().setReady(true);
            name = game.getPlayerOne().getAccount().getUsername();
        }
        if(gameStarted()){
            game.setStarted(true);
            return new GameStartedResponse(game.getRivalBoard(side), game.getSide()
            , name);
        }
        return new GameStartedResponse(null, game.getSide(), name);
    }

    @Override
    public Response checkClickedCell(int x, int y, Side side) {
        if(x != -1 && y != -1) {
            if(side == Side.PLAYER_ONE){
                game.setPlayerOneActions(game.getPlayerOneActions() + 1);
            }
            else{
                game.setPlayerTwoActions(game.getPlayerTwoActions() + 1);
            }
            String message = putBomb(x, y, side);
            return new ClickResponse(message, game.getRivalBoard(side));
        }
        game.changeSide();
        return new ClickResponse("noNo", game.getRivalBoard(side));
    }

    @Override
    public Response sendMyBoard(Side side) {
        if(game.getSide() == side){
              if(game.isEndGame()){
                  return new GetMyBoardResponse(game.getMyBoard(side), "yesYes");
              }
              else{
                  return new GetMyBoardResponse(game.getMyBoard(side), "yesNo");
              }
        }
        if(game.isEndGame()){
            return new GetMyBoardResponse(game.getMyBoard(side), "noYes");
        }
        return new GetMyBoardResponse(game.getMyBoard(side), "noNo");
    }

    @Override
    public Response setRandomBoard(Side side) {
        game.getMyBoard(side).setBoatsInRandom();
        return new RandomBoardResponse(game.getMyBoard(side));
    }
}