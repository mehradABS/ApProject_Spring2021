package game.info;

import auth.AuthToken;
import controller.MainController;
import events.visitors.GetInfoEventVisitor;
import models.Player;
import responses.GetInfoResponse;
import responses.Response;

import java.io.IOException;

public class GetInfoController extends MainController implements GetInfoEventVisitor {

    private final AuthToken id;

    public GetInfoController(AuthToken id) {
        this.id = id;
    }

    @Override
    public Response sendInfo() {
        try {
            Player player = context.getPlayers().get(ONLINE_CLIENTS.get(
                    id.getAuthToken()));
            return new GetInfoResponse(player);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}