package game;

import controller.MainController;
import models.Game;
import models.Side;

import java.io.IOException;

public class GameLobby extends MainController{
    private ClientHandler waiting;

    public GameLobby() {
    }

    public synchronized String startGameRequest(ClientHandler clientHandler,
                                              boolean begin, long clientId) {
        if(begin) {
            if (waiting == null) {
                waiting = clientHandler;
            } else {
                if (waiting != clientHandler) {
                    Game game = null;
                    try {
                        game = new Game(context.getPlayers().get(ONLINE_CLIENTS
                        .get(waiting.getId())), context.getPlayers().get(ONLINE_CLIENTS
                                .get(clientId)));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    GAMES.add(game);
                    waiting.setGame(game);
                    clientHandler.setGame(game);
                    waiting.setSide(Side.PLAYER_ONE);
                    clientHandler.setSide(Side.PLAYER_TWO);
                    waiting = null;
                    return "ok";
                }
            }
            return "waiting for another player";
        }
        else{
            if(waiting != null){
                if(waiting.getId() == clientId){
                    waiting = null;
                }
            }
            return "";
        }
    }
}