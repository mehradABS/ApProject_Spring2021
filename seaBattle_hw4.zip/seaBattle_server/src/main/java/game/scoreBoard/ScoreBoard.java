package game.scoreBoard;

import controller.MainController;
import events.visitors.ScoreBoardEventVisitor;
import models.Player;
import responses.Response;
import responses.ScoreBoardResponse;

import java.io.IOException;
import java.util.List;

public class ScoreBoard extends MainController implements ScoreBoardEventVisitor {

    public ScoreBoard() {
    }

    @Override
    public Response sendScoreBoard() {
        try {
            List<Player> all = context.getPlayers().getAll();
            List<Integer> online = getOnlineClients();
            for (int i = 1; i < all.size() ; i++) {
                for (int j = i; j >=1 ; j--) {
                    if(all.get(j).getWin() - all.get(j).getLoose()
                     < all.get(j - 1).getWin() - all.get(j - 1).getLoose()){
                         Player player = all.get(j);
                         all.set(j, all.get(j - 1));
                         all.set(j - 1, player);
                    }
                    else{
                        break;
                    }
                }
            }
            return new ScoreBoardResponse(all, online);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
