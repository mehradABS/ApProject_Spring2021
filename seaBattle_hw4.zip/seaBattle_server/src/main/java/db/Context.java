package db;

import models.Player;

public class Context {
    private final DBSet<Player> players;

    public Context() {
        this.players = new PlayerDB();
    }

    public DBSet<Player> getPlayers() {
        return players;
    }
}
