package db;


import models.Player;
import resources.Paths;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class PlayerDB implements DBSet<Player>{


    private static final Object LOCK1 = new Object();
    private static final Object LOCK2 = new Object();

    @Override
    public Player get(int id) throws IOException {
        File file = new File(Paths.PLAYER_PATH +id+".json");
        FileReader fileReader = new FileReader(file);
        Player player = gson.fromJson(fileReader, Player.class);
        fileReader.close();
        return player;
    }

    @Override
    public List<Player> getAll() throws IOException {
        List<Player> players = new LinkedList<>();
        synchronized (LOCK1) {
            File file = new File(Paths.PLAYER_PATH_GET_ALL);
            for (File playerFile : Objects.requireNonNull(file.listFiles())) {
                FileReader fileReader = new FileReader(playerFile);
                Player player = gson.fromJson(fileReader, Player.class);
                players.add(player);
                fileReader.close();
            }
        }
        return players;
    }

    @Override
    public void set(Player player) throws IOException {
        synchronized (LOCK1) {
            FileWriter fileWriter = new FileWriter(Paths.PLAYER_PATH+player.
                    getId()+".json",false);
            gson.toJson(player, fileWriter);
            fileWriter.flush();
            fileWriter.close();
        }
    }

    @Override
    public void setIDCounter(int idCounter) throws IOException {
        synchronized (LOCK2) {
            FileWriter fileWriter = new FileWriter(Paths.PLAYER_PATH_ID_COUNTER,
                    false);
            gson.toJson(idCounter, fileWriter);
            fileWriter.flush();
            fileWriter.close();
        }
    }

    @Override
    public int getIDCounter() throws IOException {
        int id = 0;
        synchronized (LOCK2) {
            File file7 = new File(Paths.PLAYER_PATH_ID_COUNTER);
            if (file7.exists()) {
                FileReader fileReader = new FileReader(file7);
                id = gson.fromJson(fileReader, Integer.class);
                fileReader.close();
            }
        }
        return id;
    }

    @Override
    public void delete(int id) {
       //do nothing
    }
}
