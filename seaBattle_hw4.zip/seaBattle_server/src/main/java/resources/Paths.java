package resources;

public class Paths {
    public static String PLAYER_PATH;
    public static String PLAYER_PATH_GET_ALL;
    public static String PLAYER_PATH_ID_COUNTER;
}
