package resources;

public class Ports {

    public static int MAIN_PORT;
}
