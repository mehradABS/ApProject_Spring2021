import config.MainConfig;
import network.SocketManager;

public class Main {
    public static void main(String[] args) {
        new MainConfig();
        new SocketManager().start();
    }
}
