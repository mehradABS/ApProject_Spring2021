package Models;

import Models.messages.Message;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class Chat {
       private final int Id;

       private static int Id_counter;

       private boolean isGroupChat = false;

       private final HashSet<Integer> usersIds;

       private String name;

       private final List<Integer> deletedMessage;

       private final List<Integer> forwardTweets;

       private final List<Integer> forwardComments;

       private final List<Integer> id_Message;

       private final List<Integer> id_forwardMessage;

       public Chat(){
              Id_counter++;
              this.Id = Id_counter;
              messages = new LinkedList<>();
              forwardMessages = new LinkedList<>();
              id_forwardMessage = new LinkedList<>();
              id_Message = new LinkedList<>();
              usersIds = new HashSet<>();
              forwardComments = new LinkedList<>();
              forwardTweets = new LinkedList<>();
              deletedMessage = new LinkedList<>();
       }

       public List<Integer> getForwardTweets() {
              return forwardTweets;
       }

       public List<Integer> getForwardComments() {
              return forwardComments;
       }

       public List<Integer> getDeletedMessage() {
              return deletedMessage;
       }

       public boolean isGroupChat() {
              return isGroupChat;
       }

       public void setGroupChat(boolean groupChat) {
              isGroupChat = groupChat;
       }

       public int getId() {
              return Id;
       }

       public void setMessages(List<Message> messages) {
              this.messages = messages;
       }

       public static int getId_counter() {
              return Id_counter;
       }

       transient private  List<Message> messages;


       public List<Message> getMessages() {
              return messages;
       }

       public List<Message> getForwardMessages() {
              return forwardMessages;
       }

       transient private  List<Message> forwardMessages;

       public static void setId_counter(int id_counter) {
              Id_counter = id_counter;
       }

       public void setForwardMessages(List<Message> forwardMessages) {
              this.forwardMessages = forwardMessages;
       }

       public List<Integer> getId_Message(){
              return id_Message;
       }

       public List<Integer> getId_forwardMessage(){
              return id_forwardMessage;
       }

       public HashSet<Integer> getUsersIds() {
              return usersIds;
       }

       public String getName() {
              return name;
       }

       public void setName(String name) {
              this.name = name;
       }

       public static void sortMessages(List<Message> publicTweets){
              for (int i = 1; i < publicTweets.size(); i++) {
                     for (int j = i; j >0 ; j--) {
                            if(publicTweets.get(j).getLocalDateTime()
                            .isBefore(publicTweets.get(j-1).getLocalDateTime())){
                                   Message tweet= publicTweets.get(j);
                                   publicTweets.set(j,publicTweets.get(j-1));
                                   publicTweets.set(j-1,tweet);
                            }
                     }
              }
       }
}