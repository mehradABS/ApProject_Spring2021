package Models.messages;


import Models.auth.User;

import java.time.LocalDateTime;

import java.util.HashSet;
import java.util.List;


public class Message implements Cloneable{

    private  HashSet<Integer> like;
    private final String MessageType;
    private String Text;
    private  HashSet<Integer> dislike;
    protected int imageId;
    private HashSet<Integer> retweet_userId;
    private static int Id_counter;
    protected int forwarderId = -1;
    protected  int Id;
    private final int userId;

    public Message(String messageType, String text, User user,
                   LocalDateTime localDateTime) {
        Id_counter++;
        this.Id=Id_counter;
        MessageType = messageType;
        Text = text;
        this.localDateTime = localDateTime;
        this.like=new HashSet<>();
        this.dislike=new HashSet<>();
        this.userId=user.getId();
        retweet_userId = new HashSet<>();
        retweet_userId.add(user.getId());
    }

    public static int getId_counter() {
        return Id_counter;
    }

    public int getUserId() {
        return userId;
    }

    public static void setId_counter(int id_counter) {
        Id_counter = id_counter;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public int getId(){
        return Id;
    }

    public HashSet<Integer> getRetweet_userId() {
        return retweet_userId;
    }

    public void setRetweet_userId(HashSet<Integer> retweet_userId) {
        this.retweet_userId = retweet_userId;
    }

    public List<Integer> getCommentsId(){
        return null;
    }

    public HashSet<Integer> getDislike() {
        return dislike;
    }

    public HashSet<Integer> getLike() {
        return like;
    }

    public void setLike(HashSet<Integer> like) {
        this.like = like;
    }

    public void setDislike(HashSet<Integer> dislike) {
        this.dislike = dislike;
    }

    public LocalDateTime getLocalDateTime() {
        return localDateTime;
    }

    private final LocalDateTime localDateTime;

    public String getText() {
        return Text;
    }

    public String getMessageType() {
        return MessageType;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getForwarderId() {
        return forwarderId;
    }

    public void setForwarderId(int forwarderId) {
        this.forwarderId = forwarderId;
    }

    public void setText(String text) {
        Text = text;
    }
}