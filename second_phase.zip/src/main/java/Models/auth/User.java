package Models.auth;




import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class User{

    private final HashSet<Integer> myReqId;
    private final HashSet<Integer> reqFromMeId;
    private final List<String> SystemMessages;
    private final HashSet<Integer> blackUsername;
    private final HashSet<Integer> followerUsername;
    private final HashSet<Integer> followingUsername;
    private final List<ListName> FollowingsList;
    private final HashSet<Integer> silentUsername;
    private String EmailAddress;
    private String PhoneNumber;
    private String Biography;
    private LocalDate Birth;
    private final List<Integer> myChatIds;
    private final List<List<Integer>> myChatMessagesIds;
    private final List<Integer> myUnreadChatMessagesNumbers;
    private final List<Integer> myUnreadChatIds;
    private String Firstname;
    private static int Id_counter;
    private final HashSet<Integer> favouriteID;
    private final List<Integer> tweetsID;
    private final int Id;
    private String Lastname;
    private final Account account;

    public User(String firstname, String lastname, int year, int month, int day,
                String emailAddress, String phoneNumber, String biography,
                String username, String password) {
        Id_counter++;
        Id = Id_counter;
        Firstname = firstname;
        Lastname = lastname;
        Birth = LocalDate.of(year, month, day);
        EmailAddress = emailAddress;
        PhoneNumber = phoneNumber;
        Biography = biography;
        blackUsername = new HashSet<>();
        followerUsername=new HashSet<>();
        followingUsername=new HashSet<>();
        FollowingsList = new LinkedList<>();
        myReqId = new HashSet<>();
        reqFromMeId = new HashSet<>();
        SystemMessages = new LinkedList<>();
        tweetsID=new LinkedList<>();
        favouriteID=new HashSet<>();
        silentUsername=new HashSet<>();
        this.account = new Account(username, password);
        myChatMessagesIds = new LinkedList<>();
        myChatIds = new LinkedList<>();
        myUnreadChatIds = new LinkedList<>();
        myUnreadChatMessagesNumbers = new LinkedList<>();
    }

    public List<Integer> getMyChatIds() {
        return myChatIds;
    }

    public List<List<Integer>> getMyChatMessagesIds() {
        return myChatMessagesIds;
    }

    public List<Integer> getMyUnreadChatMessagesNumbers() {
        return myUnreadChatMessagesNumbers;
    }

    public List<Integer> getMyUnreadChatIds() {
        return myUnreadChatIds;
    }

    public static void setId_counter(int id_counter) {
        Id_counter = id_counter;
    }

    public List<Integer> getTweetsID() {
        return tweetsID;
    }

    public HashSet<Integer> getFavouriteID(){
        return favouriteID;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public void setEmailAddress(String emailAddress) {
        EmailAddress = emailAddress;
    }

    public void setBiography(String biography) {
        Biography = biography;
    }

    public static int getId_counter() {
        return Id_counter;
    }

    public int getId() {
        return Id;
    }

    public String getFirstname() {
        return Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public LocalDate getBirth() {
        return Birth;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public String getBiography() {
        return Biography;
    }

    public List<ListName> getFollowingsList() {
        return FollowingsList;
    }

    public List<String> getSystemMessages() {
        return SystemMessages;
    }

    public Account getAccount() {
        return account;
    }

    public void setBirth(LocalDate birth) {
        Birth = birth;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public HashSet<Integer> getBlackUsername() {
        return blackUsername;
    }

    public HashSet<Integer> getFollowerUsername() {
        return followerUsername;
    }

    public HashSet<Integer> getFollowingUsername() {
        return followingUsername;
    }

    public HashSet<Integer> getSilentUsername() {
        return silentUsername;
    }

    public HashSet<Integer> getMyReqId() {
        return myReqId;
    }

    public HashSet<Integer> getReqFromMeId() {
        return reqFromMeId;
    }

    public static class ListName {
        public HashSet<Integer> getUsernames() {
            return usernames;
        }
        private final HashSet<Integer> usernames;
        private String name;
        public ListName() {
            name = "";
            usernames = new HashSet<>();
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getName() {
            return name;
        }
    }
}
