package Models.auth;


import java.time.LocalDateTime;


public class Account {
    private  String Privacy;
    private  LocalDateTime lastSeen;
    private  String whoCanSeeLastSeen;
    private  boolean IsActive;
    private String Password;
    private String Username;

    public Account(String username, String password) {
        Username = username;
        Password = password;
        IsActive = true;
        Privacy = "public";
        this.whoCanSeeLastSeen = "nobody";
        this.lastSeen=null;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public boolean isActive() {
        return IsActive;
    }

    public String getPrivacy() {
        return Privacy;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public LocalDateTime getLastSeen() {
        return this.lastSeen;
    }

    public String getWhoCanSeeLastSeen() {
        return this.whoCanSeeLastSeen;
    }

    public void setActive(boolean active) {
        IsActive = active;
    }

    public void setPrivacy(String privacy) {
        Privacy = privacy;
    }

    public void setLastSeen(LocalDateTime lastSeen) {
        this.lastSeen = lastSeen;
    }

    public void setWhoCanSeeLastSeen(String whoCanSeeLastSeen) {
        this.whoCanSeeLastSeen = whoCanSeeLastSeen;
    }


}
