package app.setting.listener;

import app.setting.controller.SettingController;

import java.io.IOException;

public class SettingListener {

    private final SettingController settingController = new SettingController();

    public String[] loadInfo(){
        try {
            return settingController.loadInfo();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setLastSeen(String name){
        try {
            settingController.setLastSeen(name);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setPrivacy(){
        try {
            settingController.setPrivacy();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setActivate(boolean activate){
        try {
            settingController.setActivate(activate);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removeAccount(){
        try {
            settingController.removeAccount();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
