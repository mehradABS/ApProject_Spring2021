package app.setting.controller;

import Models.auth.User;
import controller.MainController;
import db.UserDB;

import java.io.IOException;

public class SettingController extends MainController {

    public String[] loadInfo() throws IOException {
        String[] info = new String[3];
        User current = context.getUsers().get(currentUserId);
        info[0] = current.getAccount().getPrivacy();
        info[1] = current.getAccount().getWhoCanSeeLastSeen();
        info[2] = String.valueOf(current.getAccount().isActive());
        return info;
    }

    public void setPrivacy() throws IOException {
        User current = context.getUsers().get(currentUserId);
        if(current.getAccount().getPrivacy().equals("public")){
            current.getAccount().setPrivacy("private");
        }
        else{
            current.getAccount().setPrivacy("public");
        }
        context.getUsers().set(current);
    }

    public void setLastSeen(String lastSeen) throws IOException {
        User current = context.getUsers().get(currentUserId);
        current.getAccount().setWhoCanSeeLastSeen(lastSeen);
        context.getUsers().set(current);
    }

    public void setActivate(boolean activate) throws IOException {
        User current = context.getUsers().get(currentUserId);
        current.getAccount().setActive(activate);
        context.getUsers().set(current);
    }

    public void removeAccount() throws IOException {
        User current = context.getUsers().get(currentUserId);
        current.getAccount().setUsername("deleted Account");
        current.getAccount().setPassword("");
        current.setEmailAddress("-1");
        current.setPhoneNumber("ss");
        current.getAccount().setActive(false);
        ((UserDB)context.getUsers()).deleteProfileImage(currentUserId);
        context.getUsers().set(current);
        System.exit(0);
    }
}
