package app.authentication.listener;

import app.authentication.controller.RegisterController;
import app.authentication.event.RegistrationFormEvent;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;

import java.io.IOException;

public class RegisterListener implements RegistrationFormListener{
    private final RegisterController registerController;

    public RegisterListener() {
        this.registerController = new RegisterController();
    }

    @Override
    public void registrationEventOccurred(RegistrationFormEvent registrationFormEvent)
            throws NullException, IOException, ChosenInfo, InvalidEntrance {
             registerController.register(registrationFormEvent);
    }
}
