package app.authentication.listener;

import app.authentication.event.ManageBiographyFormEvent;
import exceptions.InvalidFile;

import java.io.IOException;

public interface ManageBiographyFormListener {
    String selectFileEventOccurred(ManageBiographyFormEvent manageBiographyFormEvent)
            throws InvalidFile, IOException;
    void registerEventOccurred(ManageBiographyFormEvent manageBiographyFormEvent) throws IOException;

    void backButtonClicked() throws IOException;
}
