package app.authentication.listener;

import app.authentication.controller.LoginController;
import app.authentication.event.LoginFormEvent;
import exceptions.LoginException;
import exceptions.NullException;

import java.io.IOException;

public class LoginListener implements LoginFormListener{
    private final LoginController loginController;

    public LoginListener() {
        loginController = new LoginController();
    }

    @Override
    public void loginEventOccurred(LoginFormEvent loginFormEvent)
            throws IOException, LoginException, NullException {
        loginController.login(loginFormEvent);
    }
}
