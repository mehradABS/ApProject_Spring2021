package app.authentication.listener;

import app.authentication.controller.ManageBiographyController;
import app.authentication.event.ManageBiographyFormEvent;
import exceptions.InvalidFile;


import java.io.IOException;


public class ManageBiographyListener implements ManageBiographyFormListener{
    private final ManageBiographyController manageBiographyController;

    public ManageBiographyListener(){
        manageBiographyController = new ManageBiographyController();
    }
    @Override
    public String selectFileEventOccurred
            (ManageBiographyFormEvent manageBiographyFormEvent)
            throws InvalidFile, IOException {
            return manageBiographyController.checkFile(manageBiographyFormEvent);
    }

    @Override
    public void registerEventOccurred
            (ManageBiographyFormEvent manageBiographyFormEvent) throws IOException {
        manageBiographyController.register(manageBiographyFormEvent);
    }

    public void backButtonClicked() throws IOException {
               manageBiographyController.minusUserCounter();
    }

}
