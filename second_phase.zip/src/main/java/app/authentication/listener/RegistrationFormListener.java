package app.authentication.listener;

import app.authentication.event.RegistrationFormEvent;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;

import java.io.IOException;

public interface RegistrationFormListener {
    void registrationEventOccurred(RegistrationFormEvent registrationFormEvent) throws NullException, IOException, ChosenInfo, InvalidEntrance;
}
