package app.authentication.listener;

import app.authentication.event.LoginFormEvent;
import exceptions.LoginException;
import exceptions.NullException;

import java.io.IOException;

public interface LoginFormListener {
     void loginEventOccurred(LoginFormEvent loginFormEvent) throws IOException, LoginException, NullException;
}
