package app.authentication.view;

import app.authentication.event.ManageBiographyFormEvent;
import exceptions.InvalidFile;
import app.authentication.listener.ManageBiographyListener;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class ManageBiography extends JPanel {
    private final JFileChooser chooser;
    private final ImagePanel imagePanel;
    private final JTextArea biographyField;
    private final JLabel pngLabel;
    private final JButton backButton;
    private final ManageBiographyListener manageBiographyListener;
    private final ManageBiographyFormEvent manageBiographyFormEvent;
    private StringListener stringListener;

    public ManageBiography() {
        manageBiographyFormEvent = new ManageBiographyFormEvent(this);
        manageBiographyListener = new ManageBiographyListener();
        //
        pngLabel = new JLabel(Texts.PNG_LABEL);
        pngLabel.setBounds(830,455,400,40);
        pngLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        pngLabel.setFont(Fonts.Label_FONT);
        pngLabel.setVisible(false);
        //
        JLabel biographyLabel = new JLabel(Texts.BIOGRAPHY);
       biographyLabel.setBounds(520,30,600,200);
       biographyLabel.setForeground(Color.decode(Colors.WELCOME_LABEL_COLOR));
       biographyLabel.setFont(Fonts.BIOGRAPHY_FONT);
       //
        biographyField = new JTextArea();
        biographyField.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(biographyField,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBounds(520,170,450,80);
        biographyField.setBounds(520,170,450,80);
       biographyField.setBackground(Color.decode(Colors.BUTTONS_COLOR));
       biographyField.setFont(Fonts.BUTTONS_FONT);
       //
        JButton selectPhotoButton = new JButton(Texts.SELECT_BUTTON);
       selectPhotoButton.setBounds(688,580,100,40);
       selectPhotoButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
       selectPhotoButton.setFocusable(false);
       selectPhotoButton.setFont(Fonts.BUTTONS_FONT);
       selectPhotoButton.addActionListener(e-> selectPhotoButtonAction());
       //
       chooser = new JFileChooser();
       //
       imagePanel = new ImagePanel();
       imagePanel.setLayout(null);
       imagePanel.setBackground(Color.decode(Colors.IMAGE_KEEPER_COLOR));
       imagePanel.setBounds(665,400,150,150);
       //
        JLabel profileImageLabel = new JLabel(Texts.PROFILE_IMAGE);
       profileImageLabel.setBounds(635,280,600,150);
       profileImageLabel.setForeground(Color.decode(Colors.WELCOME_LABEL_COLOR));
       profileImageLabel.setFont(Fonts.BIOGRAPHY_FONT);
       //

        JButton registerButton = new JButton(Texts.REGISTER_BUTTON_TEXT);
        registerButton.setBounds(619,650,250,40);
        registerButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        registerButton.setFocusable(false);
        registerButton.setFont(Fonts.BUTTONS_FONT);
        registerButton.addActionListener(e->{
            try {
                registerButtonAction();
            } catch (InvalidFile | IOException ignored) {

            }
            resetPanel();
            try {
                listenMe(Texts.REGISTER_BUTTON_TEXT);
            } catch (IOException ignored) {

            }
        });
        //
        backButton = new JButton(Texts.BACK);
        backButton.setBounds(500,650,100,40);
        backButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        backButton.setFocusable(false);
        backButton.setFont(Fonts.BUTTONS_FONT);
        backButton.addActionListener(e->{
            try {
                backButtonAction();
            } catch (IOException ignored) {

            }
            resetPanel();
            try {
                listenMe(backButton.getText());
            } catch (IOException ignored) {

            }
        });
        //
        this.setLayout(null);
       this.setBounds(0,0,2000,800);
       this.add(biographyLabel);
       this.add(scrollPane);
       this.add(imagePanel);
       this.add(profileImageLabel);
       this.add(selectPhotoButton);
       this.add(registerButton);
       this.add(pngLabel);
       this.add(backButton);
    }


    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void selectPhotoButtonAction(){
        pngLabel.setVisible(false);
        int res = chooser.showOpenDialog(null);
        if (res == JFileChooser.APPROVE_OPTION) {
            manageBiographyFormEvent.setFile(chooser.getSelectedFile());
            manageBiographyFormEvent.setProfileScaledHeight(150);
            manageBiographyFormEvent.setProfileScaledWidth(150);

            try {
                String filePath = manageBiographyListener.
                        selectFileEventOccurred(manageBiographyFormEvent);
                imagePanel.setProfile(new ImageIcon(ImageIO.read(new File(filePath))));
                imagePanel.repaint();
                imagePanel.revalidate();
                repaint();
                revalidate();
            }
            catch (InvalidFile e){
               pngLabel.setVisible(true);
            }

            catch (Exception ignored){

            }
        }
    }

    public void registerButtonAction() throws InvalidFile, IOException {
        manageBiographyFormEvent.setBiography(biographyField.getText());
        manageBiographyListener.registerEventOccurred(
                manageBiographyFormEvent);
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name) throws IOException {
          stringListener.stringEventOccurred(name);
    }

    public void resetPanel(){
       pngLabel.setVisible(false);
       biographyField.setText(null);
       imagePanel.setProfile(null);
    }

    public void backButtonAction() throws IOException {
       manageBiographyListener.backButtonClicked();
    }

    public static class ImagePanel extends JPanel{

        private JLabel profile;

        public ImagePanel() {
            super();
        }

        public void setProfile(ImageIcon profile) {
            if (profile == null) {
                this.profile = null;
            } else {
                this.profile = new JLabel();
                this.profile.setBounds(0, 0, 150, 150);
                this.profile.setIcon(profile);
            }
        }

        public JLabel getProfile() {
            return profile;
        }

        public void paintComponent(Graphics g){
            super.paintComponent(g);
            this.removeAll();
            if(profile != null)
            this.add(profile);
        }
    }
}
