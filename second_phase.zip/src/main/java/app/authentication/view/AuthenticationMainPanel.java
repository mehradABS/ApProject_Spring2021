package app.authentication.view;


import view.listeners.StringListener;
import resources.Texts;

import javax.swing.*;

import java.io.IOException;

public class AuthenticationMainPanel extends JPanel {

    private  StringListener stringListener;
    private final StartPanel startPanel;
    private final RegistrationPanel registrationPanel;
    private final LoginPanel loginPanel;
    private final ManageBiography manageBiography;

    public AuthenticationMainPanel() {
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        //
        startPanel = new StartPanel();
        startPanel.setListener(new StringListener() {
            @Override
            public void stringEventOccurred(String text) {
                if(text.equals(Texts.LOGIN)){
                    removeAll();
                    add(loginPanel);
                    repaint();
                    revalidate();
                }
                else if(text.equals(Texts.REGISTER_BUTTON_TEXT)){
                    removeAll();
                    add(registrationPanel);
                    repaint();
                    revalidate();
                }
            }
        });
        //
        manageBiography = new ManageBiography();
        manageBiography.setStringListener(new StringListener() {
            @Override
            public void stringEventOccurred(String text) throws IOException {
                if(text.equals("back")){
                    removeAll();
                    add(registrationPanel);
                    repaint();
                    revalidate();
                }
                else if(text.equals("register")){
                    removeAll();
                    repaint();
                    revalidate();
                    listenMe();
                    add(startPanel);
                }
            }
        });

        //
        registrationPanel = new RegistrationPanel();
        registrationPanel.setListener(text -> {
            if(text.equals(Texts.BACK)){
                 removeAll();
                 add(startPanel);
                 repaint();
                 revalidate();
            }
            else if(text.equals(Texts.CONTINUE)){
                removeAll();
                add(manageBiography);
                repaint();
                revalidate();
            }
        });
        //
        loginPanel = new LoginPanel();
        loginPanel.setListener(text -> {
            if(text.equals(Texts.LOGIN)){
                removeAll();
                repaint();
                revalidate();
                listenMe();
                add(startPanel);
            }
            else if(text.equals(Texts.BACK)){
                removeAll();
                add(startPanel);
                repaint();
                revalidate();
            }
        });
        //
        this.add(startPanel);
        repaint();
        revalidate();
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe() throws IOException {
        stringListener.stringEventOccurred("aut");
    }
}