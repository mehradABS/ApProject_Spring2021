package app.authentication.view;

import app.authentication.event.LoginFormEvent;
import exceptions.LoginException;
import exceptions.NullException;
import app.authentication.listener.LoginListener;
import view.listeners.StringListener;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class LoginPanel extends JPanel {

    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton backButton;
    private final JButton loginButton;
    private final JLabel invalidLabel;
    private final JLabel nullLabel;
    private StringListener stringListener;
    private final LoginListener loginListener;
    private final LoginFormEvent loginFormEvent;

    public LoginPanel() {
        loginListener = new LoginListener();
        loginFormEvent = new LoginFormEvent(this);
        //
        JLabel welcomeLabel = new JLabel(Texts.WELCOME_BACK);
        welcomeLabel.setBounds(610,240,600,200);
        welcomeLabel.setForeground(Color.decode(Colors.WELCOME_LABEL_COLOR));
        welcomeLabel.setFont(Fonts.WELCOME_LABEL_FONT);
        //
        usernameField = new JTextField();
        usernameField.setBounds(650,390,250,40);
        usernameField.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        usernameField.setFont(Fonts.BUTTONS_FONT);
        //
        JLabel usernameLabel = new JLabel(Texts.USERNAME);
        usernameLabel.setBounds(540,390,130,40);
        usernameLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        usernameLabel.setFont(Fonts.Label_FONT);
        //
        passwordField = new JPasswordField();
        passwordField.setBounds(650,440,250,40);
        passwordField.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        passwordField.setFont(Fonts.BUTTONS_FONT);
        //
        JLabel passwordLabel = new JLabel(Texts.PASSWORD);
        passwordLabel.setBounds(540,435,130,40);
        passwordLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        passwordLabel.setFont(Fonts.Label_FONT);
        //
        loginButton = new JButton(Texts.LOGIN);
        loginButton.setBounds(650,490,250,40);
        loginButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        loginButton.setFocusable(false);
        loginButton.setFont(Fonts.BUTTONS_FONT);
        loginButton.addActionListener(e->
        {
            try {
                loginAction();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        invalidLabel = new JLabel(Texts.INVALID_LOGIN);
        invalidLabel.setBounds(630,540,400,40);
        invalidLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        invalidLabel.setFont(Fonts.Label_FONT);
        invalidLabel.setVisible(false);
        //
        nullLabel = new JLabel(Texts.NULL);
        nullLabel.setBounds(700,540,400,40);
        nullLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        nullLabel.setFont(Fonts.Label_FONT);
        nullLabel.setVisible(false);
        //
        backButton = new JButton(Texts.BACK);
        backButton.setBounds(520,490,100,40);
        backButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        backButton.setFocusable(false);
        backButton.setFont(Fonts.BUTTONS_FONT);
        backButton.addActionListener(e->{
            resetPanel();
            try {
                listenMe(backButton.getText());
            } catch (IOException ignored) {

            }
        });
        //
        this.setLayout(null);
        this.setBounds(0,0,2000,800);
        this.add(backButton);
        this.add(loginButton);
        this.add(passwordField);
        this.add(usernameField);
        this.add(welcomeLabel);
        this.add(passwordLabel);
        this.add(usernameLabel);
        this.add(invalidLabel);
        this.add(nullLabel);
    }

    public void listenMe(String buttonText) throws IOException {
        stringListener.stringEventOccurred(buttonText);
    }

    public void setListener(StringListener stringListener){
        this.stringListener = stringListener;
    }

    public void loginAction() throws IOException {
        try {
            loginFormEvent.setUsername(usernameField.getText());
            StringBuilder password = new StringBuilder();
            char[] a = passwordField.getPassword();
            for (char c : a) {
                password.append(c);
            }
            loginFormEvent.setPassword(password.toString());
            loginListener.loginEventOccurred(loginFormEvent);
            resetPanel();
            listenMe(loginButton.getText());
        }
        catch (LoginException e){
            nullLabel.setVisible(false);
            invalidLabel.setVisible(true);
        }
        catch (NullException e){
            invalidLabel.setVisible(false);
            nullLabel.setVisible(true);
        }
        catch (Exception ignored){

        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void resetPanel(){
        invalidLabel.setVisible(false);
        nullLabel.setVisible(false);
        passwordField.setText(null);
        usernameField.setText(null);
    }
}