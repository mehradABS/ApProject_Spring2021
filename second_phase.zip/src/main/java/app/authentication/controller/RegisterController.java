package app.authentication.controller;

import controller.log.Log;
import app.authentication.event.RegistrationFormEvent;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;
import Models.auth.User;
import controller.MainController;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class RegisterController extends MainController {
    public void register(RegistrationFormEvent registrationFormEvent)
            throws NullException, IOException, ChosenInfo, InvalidEntrance {

        List <User> users = context.getUsers().getAll();
        String firstname = registrationFormEvent.getFirstname();
        String lastname = registrationFormEvent.getLastname();
        String username = registrationFormEvent.getUsername();
        String password = registrationFormEvent.getPassword();
        String email = registrationFormEvent.getEmail();
        String phone = registrationFormEvent.getPhone();
        //
        int j = email.length()-1;
        for (; j >=0 ; j--) {
            if(email.charAt(j) != ' ') {
                break;
            }
        }
        email = email.substring(0,j+1);
        int k = phone.length()-1;
        for (; k >=0 ; k--) {
            if(phone.charAt(k) != ' ') {
                break;
            }
        }
        phone = phone.substring(0,k+1);
        //
        if(firstname.equals("")){
            throw new NullException();
        }
        if(lastname.equals("")){
            throw new NullException();
        }
        if(username.equals("")){
            throw new NullException();
        }
        if(password.equals("")){
            throw new NullException();
        }
        if(email.equals("")){
            throw new NullException();
        }
        //
        if (!checkNewUsername(username, users)) {
            throw new ChosenInfo("username");
        }
        if (!checkNewPassword(password, users)) {
            throw new ChosenInfo("password");
        }
        if(!(email.toLowerCase().endsWith("@gmail.com") ||
                email.toLowerCase().endsWith("@yahoo.com"))) {
            throw new InvalidEntrance("email");
        }
        if (!checkNewEmail(email, users)) {
            throw new ChosenInfo("email");
        }
        boolean number=true;
        if (phone.equals("")) {
            phone = "---";
        }
        else if (checkNewPhone(phone, users)) {
            for (int i = 0; i < phone.length(); i++) {
                if(!(phone.charAt(i)-'0'<10 &&
                        phone.charAt(i)-'0'>-1)){
                    number=false;
                    break;
                }
            }
            if(!number){
                throw new InvalidEntrance("phone");
            }
        }
        else{
            throw new ChosenInfo("phone");
        }
        String biography = "null";
        User.setId_counter(context.getUsers().getIDCounter());
        User newUser = new User(firstname, lastname,
                registrationFormEvent.getBirth().getYear(),
                registrationFormEvent.getBirth().getMonthValue(),
                registrationFormEvent.getBirth().getDayOfMonth(),
                email, phone, biography, username, password);
        context.getUsers().setIDCounter(User.getId_counter());
        context.getUsers().set(newUser);
        setCurrentUserId(newUser.getId());
        Log log=new Log("new account created", LocalDateTime.now(),
                1,currentUserId);
        Log.log(log);
    }

    public boolean checkNewUsername(String username, List<User> users) {
        for (User user: users) {
            if(user.getAccount().getUsername().equals(username)){
                return false;
            }
        }
        return true;
    }

    public boolean checkNewPassword(String password, List<User> users) {
        for (User user: users) {
            if(user.getAccount().getPassword().equals(password)){
                return false;
            }
        }
        return true;
    }

    public boolean checkNewEmail(String email, List<User> users) {
        for (User user: users) {
            if(user.getEmailAddress().equals(email)){
                return false;
            }
        }
        return true;
    }

    public boolean checkNewPhone(String phone, List<User> users) {
        for (User user: users) {
            if(user.getPhoneNumber().equals(phone)){
                return false;
            }
        }
        return true;
    }
}
