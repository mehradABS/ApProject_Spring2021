package app.authentication.controller;

import controller.log.Log;
import app.authentication.event.LoginFormEvent;
import exceptions.LoginException;
import exceptions.NullException;
import Models.auth.User;
import controller.MainController;

import java.io.IOException;
import java.time.LocalDateTime;

public class LoginController extends MainController {

    public void login(LoginFormEvent loginFormEvent)
            throws IOException, NullException, LoginException {
        if(loginFormEvent.getPassword().equals("") ||
                loginFormEvent.getUsername().equals("")){
            throw new NullException();
        }
        int id = checkValidationLogin(loginFormEvent.getUsername(),
                loginFormEvent.getPassword());
        if (id == -1) {
            throw new LoginException();
        }
        else{
            setCurrentUserId(id);
        }
        Log log = new Log("login successful", LocalDateTime.now(),
                1,currentUserId);
        Log.log(log);
    }

    public int checkValidationLogin(String myUsername, String password)
            throws IOException {
        for (User user: context.getUsers().getAll()) {
            if(user.getAccount().getUsername().equals(myUsername)){
                if(user.getAccount().getPassword().equals(password)){
                    return user.getId();
                }
                return -1;
            }
        }
        return -1;
    }
}
