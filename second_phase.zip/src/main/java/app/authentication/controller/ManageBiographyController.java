package app.authentication.controller;

import controller.log.Log;
import app.authentication.event.ManageBiographyFormEvent;
import exceptions.InvalidFile;
import Models.auth.User;
import controller.MainController;
import db.UserDB;

import java.io.IOException;
import java.time.LocalDateTime;

public class ManageBiographyController extends MainController {

    public void register(ManageBiographyFormEvent manageBiographyFormEvent)
            throws IOException {
       User user = context.getUsers().get(currentUserId);
       user.setBiography(manageBiographyFormEvent.getBiography());
        context.getUsers().set(user);
    }

    public String checkFile(ManageBiographyFormEvent manageBiographyFormEvent)
            throws InvalidFile, IOException {
        if (manageBiographyFormEvent.getFile().getPath().endsWith(".png")) {
            ((UserDB)context.getUsers()).saveProfile(
                    context.getUsers().getIDCounter()
                    ,manageBiographyFormEvent
            .getFile().getPath(), manageBiographyFormEvent.getProfileScaledWidth(),
                    manageBiographyFormEvent.getProfileScaledHeight());
            return ((UserDB)context.getUsers()).loadProfile
                    (context.getUsers().getIDCounter(),
                            manageBiographyFormEvent.getProfileScaledHeight());
        }
        else {
            throw new InvalidFile();
        }
    }

    public void minusUserCounter() throws IOException {
        context.getUsers().delete(context.getUsers().getIDCounter());
        ((UserDB)context.getUsers()).deleteProfileImage
                (context.getUsers().getIDCounter());
        context.getUsers().setIDCounter(context.getUsers().getIDCounter()-1);
        Log log=new Log("newUser deleted his account", LocalDateTime.now(),
                1,currentUserId);
        Log.log(log);
        setCurrentUserId(0);
    }
}