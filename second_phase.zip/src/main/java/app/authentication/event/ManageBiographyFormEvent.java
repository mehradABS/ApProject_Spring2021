package app.authentication.event;

import java.io.File;
import java.util.EventObject;

public class ManageBiographyFormEvent extends EventObject {

    protected File file;
    private String biography;
    protected int profileScaledWidth;
    protected int profileScaledHeight;

    public ManageBiographyFormEvent(Object source) {
        super(source);
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public int getProfileScaledWidth() {
        return profileScaledWidth;
    }

    public void setProfileScaledWidth(int profileScaledWidth) {
        this.profileScaledWidth = profileScaledWidth;
    }

    public int getProfileScaledHeight() {
        return profileScaledHeight;
    }

    public void setProfileScaledHeight(int profileScaledHeight) {
        this.profileScaledHeight = profileScaledHeight;
    }
}
