package app.authentication.event;

import java.util.EventObject;

public class LoginFormEvent extends EventObject {
    private  String username;
    private  String password;

    public LoginFormEvent(Object source) {
        super(source);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

