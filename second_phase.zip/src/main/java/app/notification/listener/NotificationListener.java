package app.notification.listener;

import app.notification.controller.NotificationController;

import java.io.IOException;
import java.util.List;

public class NotificationListener {

    private final NotificationController controller = new NotificationController();

    public List<String[]> loadSystemMessages(){
        try {
            return controller.loadSystemMessages();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadMyRequest(){
        try {
            return controller.loadMyRequest();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadOtherRequests(){
        try {
            return controller.loadOtherRequests();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void accept(int id){
        try {
            controller.acceptReq(id);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void reject(int id){
        try {
            controller.rejectWithMessage(id);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void delete(int id){
        try {
            controller.rejectWithoutMessage(id);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
