package app.notification.view;

import app.notification.listener.NotificationListener;
import resources.Colors;
import resources.Fonts;
import resources.Texts;
import view.notificationView.NotificationPanel;
import view.notificationView.RequestPanel;


import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;

public class NotificationMainPanel extends JPanel {

    private final NotificationListener listener = new NotificationListener();
    private final JScrollPane downPanel;
    private final JPanel panel;

    public NotificationMainPanel() {
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        //
        JButton myRequest = new JButton(Texts.MY_REQUEST);
        JButton otherRequest = new JButton(Texts.OTHER_REQUEST);
        JButton systemMessages = new JButton(Texts.SYSTEM_MESSAGES);
        makeButton(myRequest);
        myRequest.addActionListener(e-> setMyRequest());
        makeButton(otherRequest);
        otherRequest.addActionListener(e->setOtherRequests());
        makeButton(systemMessages);
        systemMessages.addActionListener(e->setMessages());
        myRequest.setBounds(20,10,240,60);
        otherRequest.setBounds(270,10,240,60);
        systemMessages.setBounds(520,10,240,60);
        //
        downPanel = new JScrollPane(panel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        downPanel.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        downPanel.setBounds(0,80,800,620);
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.INFO_PANEL));
        this.setBounds(260,50,800,700);
        this.add(myRequest);
        this.add(otherRequest);
        this.add(systemMessages);
        this.add(downPanel);
    }

    public void makeButton(JButton button){
        button.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        button.setFocusable(false);
        button.setFont(Fonts.BUTTONS_FONT);
    }

    public void setOtherRequests(){
        panel.removeAll();
        List<String[]> info = listener.loadOtherRequests();
        List<RequestPanel> messages = new LinkedList<>();
        int height = 5;
        for (String[] string:info) {
            RequestPanel message = new RequestPanel();
            message.setInfo(height,string[0],Integer.parseInt(string[1]));
            setStringListenerForSubPanels(message);
            messages.add(message);
            height += 205;
        }
        panel.setPreferredSize(new Dimension(800, height));
        for (RequestPanel t:messages) {
            panel.add(t);
        }
        downPanel.setViewportView(panel);
        repaint();
        revalidate();
    }

    public void setMyRequest(){
        panel.removeAll();
        List<String[]> info = listener.loadMyRequest();
        List<NotificationPanel> messages = new LinkedList<>();
        int height = 5;
        for (String[] string:info) {
            NotificationPanel message = new NotificationPanel();
            message.setInfo(height,string[0],Integer.parseInt(string[1]));
            messages.add(message);
            height += 205;
        }
        panel.setPreferredSize(new Dimension(800, height));
        for (NotificationPanel t:messages) {
            panel.add(t);
        }
        downPanel.setViewportView(panel);
        repaint();
        revalidate();
    }

    public void setMessages(){
        panel.removeAll();
        List<String[]> info = listener.loadSystemMessages();
        List<NotificationPanel> messages = new LinkedList<>();
        int height = 5;
        for (String[] string:info) {
            NotificationPanel message = new NotificationPanel();
            message.setInfo(height,string[0],Integer.parseInt(string[1]));
            messages.add(message);
            height += 205;
        }
        panel.setPreferredSize(new Dimension(800, height));
        for (NotificationPanel t:messages) {
            panel.add(t);
        }
        downPanel.setViewportView(panel);
        repaint();
        revalidate();
    }

    public void setStringListenerForSubPanels(RequestPanel requestPanel){
     requestPanel.setStringListener(text -> {
         if(text.startsWith("accept")){
             listener.accept(Integer.parseInt(text.substring(6)));
         }
         else if(text.startsWith("delete")){
             listener.delete(Integer.parseInt(text.substring(6)));
             System.out.println("hh");
         }
         else if(text.startsWith("reject")){
             listener.reject(Integer.parseInt(text.substring(6)));
             System.out.println("hh");
         }
         setOtherRequests();
         repaint();
         revalidate();
     });
    }
}
