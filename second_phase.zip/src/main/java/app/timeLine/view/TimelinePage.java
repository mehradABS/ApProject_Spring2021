package app.timeLine.view;

import app.personalPage.subPart.tweetHistory.view.TweetHistoryPanel;
import app.timeLine.listener.TimelineListener;
import view.postView.commentPage.CommentView;

import java.io.IOException;
import java.util.function.Supplier;

public class TimelinePage extends TweetHistoryPanel<CommentView> {

    private final TimelineListener timelineListener;

    public TimelinePage(Supplier<? extends CommentView> ctor) {
        super(ctor);
        timelineListener = new TimelineListener();
    }

    public void loadTweets() throws IOException {
        this.tweetsInfo = timelineListener.loadTweets();
    }
}
