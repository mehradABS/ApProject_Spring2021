package app.timeLine.listener;

import app.timeLine.controller.TimelineController;

import java.io.IOException;
import java.util.LinkedList;

public class TimelineListener {

    private final TimelineController timelineController;

    public TimelineListener() {
        timelineController = new TimelineController();
    }

    public LinkedList<String[]> loadTweets() throws IOException {
        return timelineController.loadTweets();
    }
}
