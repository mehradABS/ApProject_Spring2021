package app.timeLine.controller;

import Models.messages.Tweet;
import Models.auth.User;
import app.personalPage.subPart.tweetHistory.controller.TweetHistoryController;
import controller.MainController;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;

public class TimelineController extends MainController {

    private final TweetHistoryController tweetHistoryController;

    public TimelineController() {
        tweetHistoryController = new TweetHistoryController();
    }

   public LinkedList<String[]> loadTweets() throws IOException {
       LinkedList<String[]> allIfo = new LinkedList<>();
        User current = context.getUsers().get(currentUserId);
       HashSet<Integer> ids = new HashSet<>();
        for (Integer userId : current.getFollowingUsername()) {
            if (!current.getSilentUsername().contains(userId)) {
                User user = context.getUsers().get(userId);
                if (user.getAccount().isActive()) {
                    for (Integer tweetId : user.getTweetsID()) {
                        if (!ids.contains(tweetId)) {
                            Tweet tweet = context.getTweets().get(tweetId, "tweet");
                            User user1 = context.getUsers().get(tweet.getUserId());
                            if (tweet.getUserId() != user.getId()) {
                                allIfo.add(tweetHistoryController.loadTweetInfo
                                        (tweet, user1,
                                        user.
                                                getAccount().getUsername() +
                                                " retweeted: "));
                            } else {
                                allIfo.add(tweetHistoryController.loadTweetInfo(
                                        tweet, user1, ""));
                            }
                            ids.add(tweetId);
                        }
                    }
                }
            }
        }
        for (Integer tweetId: current.getFavouriteID()) {
           if(!ids.contains(tweetId)) {
               Tweet tweet = context.getTweets().get(tweetId, "tweet");
               User user = context.getUsers().get(tweet.getUserId());
               allIfo.add(tweetHistoryController.loadTweetInfo(tweet, user,
                       ""));
               ids.add(tweetId);
           }
        }
       return allIfo;
    }
}
