package app.timeLine.subPart.commentsPage.event;

import java.util.EventObject;

public class CommentPageFormEvent extends EventObject {

    private int tweetId;
    private String type;

    public CommentPageFormEvent(Object source) {
        super(source);
    }

    public void setTweetId(int tweetId) {
        this.tweetId = tweetId;
    }

    public int getTweetId() {
        return tweetId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
