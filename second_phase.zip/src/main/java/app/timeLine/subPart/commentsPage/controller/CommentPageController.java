package app.timeLine.subPart.commentsPage.controller;


import Models.messages.Comment;


import Models.messages.Tweet;
import Models.auth.User;
import app.personalPage.subPart.tweetHistory.controller.TweetHistoryController;
import controller.MainController;

import java.io.IOException;
import java.util.LinkedList;

public class CommentPageController extends MainController {

    private final TweetHistoryController tweetHistoryController =
            new TweetHistoryController();

    public String[] loadOriginalTweet(int tweetId, String type) throws IOException {
        if(type.equals("tweet")){
            Tweet tweet = context.getTweets().get(tweetId, type);
            User user = context.getUsers().get(tweet.getUserId());
            return tweetHistoryController.loadTweetInfo(tweet, user,"");
        }
        else{
            Comment tweet = context.getComments().get(tweetId, type);
            User user = context.getUsers().get(tweet.getUserId());
            return tweetHistoryController.loadTweetInfo(tweet, user,"");
        }
    }

    public LinkedList<String[]> loadComments(int originalId, String type)
            throws IOException {
         LinkedList<String[]> allInfo = new LinkedList<>();
         if(type.equals("tweet")){
             Tweet message = context.getTweets().get(originalId, type);
             for(Integer commentId: message.getCommentsId()){
                 Comment message1 = context.getComments().get(commentId, "comment");
                 User user = context.getUsers().get(message1.getUserId());
                 if(!context.getUsers().get(currentUserId).
                         getSilentUsername().contains(message1.getUserId())
                   && user.getAccount().isActive()) {
                     allInfo.add(tweetHistoryController.loadTweetInfo(message1, user,""));
                 }
             }
         }
         else{
             Comment message = context.getComments().get(originalId, type);
             for(Integer commentId: message.getCommentsId()){
                 Comment message1 = context.getComments().get(commentId, "comment");
                 User user = context.getUsers().get(message1.getUserId());
                 if(!context.getUsers().get(currentUserId).
                         getSilentUsername().contains(message1.getUserId())
                  && user.getAccount().isActive()) {
                     allInfo.add(tweetHistoryController.loadTweetInfo(message1, user,
                             ""));
                 }
             }
         }
        return allInfo;
    }
}
