package app.timeLine.subPart.commentsPage.listener;

import app.timeLine.subPart.commentsPage.controller.CommentPageController;
import app.timeLine.subPart.commentsPage.event.CommentPageFormEvent;

import java.io.IOException;
import java.util.List;

public class CommentPageListener implements CommentPageFormListener{

    private CommentPageController commentPageController;

    public CommentPageListener() {
       commentPageController = new CommentPageController();
    }

    @Override
    public String[] loadOriginalTweets(CommentPageFormEvent commentPageFormEvent)
            throws IOException {
        return commentPageController.loadOriginalTweet
                (commentPageFormEvent.getTweetId(), commentPageFormEvent.getType());
    }

    @Override
    public List<String[]> loadTweets(CommentPageFormEvent commentPageFormEvent)
            throws IOException {
        return commentPageController.loadComments(commentPageFormEvent.getTweetId(),
                commentPageFormEvent.getType());
    }
}
