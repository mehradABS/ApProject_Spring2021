package app.timeLine.subPart.commentsPage.listener;

import app.timeLine.subPart.commentsPage.event.CommentPageFormEvent;

import java.io.IOException;
import java.util.List;

public interface CommentPageFormListener {

    String[] loadOriginalTweets(CommentPageFormEvent commentPageFormEvent)
            throws IOException;

    List<String[]> loadTweets(CommentPageFormEvent commentPageFormEvent)
            throws IOException;
}
