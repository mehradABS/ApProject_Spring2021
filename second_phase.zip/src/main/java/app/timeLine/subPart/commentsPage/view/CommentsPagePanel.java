package app.timeLine.subPart.commentsPage.view;

import app.personalPage.subPart.tweetHistory.view.TweetHistoryPanel;
import app.timeLine.subPart.commentsPage.event.CommentPageFormEvent;
import app.timeLine.subPart.commentsPage.listener.CommentPageListener;
import exceptions.InvalidEntrance;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.postView.commentPage.CommentView;
import view.postView.tweetHistory.PostView;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.function.Supplier;


public class CommentsPagePanel<T extends CommentView>
        extends TweetHistoryPanel<T> {

    private CommentView firstPanelCommentView;
    private final JButton backButton;
    private JButton likesButton;
    private JButton dislikesButton;
    private final CommentPageFormEvent commentPageFormEvent;
    private final CommentPageListener commentPageListener;
    private final JPanel firstPanel;

    public CommentsPagePanel(Supplier<? extends T> ctor) {
        super(ctor);
        //
        commentPageFormEvent = new CommentPageFormEvent(this);
        commentPageListener = new CommentPageListener();
        //
        firstPanel = new JPanel();
        firstPanel.setBackground(Color.decode(Colors.PERSONAL_PAGE_DOWN_PANEL));
        firstPanel.setLayout(null);

        //
        backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(630,8,45,45);
        backButton.setFocusable(false);
        backButton.setBackground(Color.decode(Colors.SUB_PANEL));
        backButton.addActionListener(e -> {
            try {
                listenMe("back");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
    }

    public void setInfo() throws IOException {
      postViews.removeAll(postViews);
      height = 0;
      setFirstPanel();
      loadTweets();
      makeTweetsPanels("comment");
      addPanels();
    }

    public void loadTweets() throws IOException {
        this.tweetsInfo = commentPageListener.loadTweets(commentPageFormEvent);
    }

    public void setOriginalTweetId(int id){
        commentPageFormEvent.setTweetId(id);
    }



    public void setOriginalMessageType(String type){
        commentPageFormEvent.setType(type);
    }

    public void setFirstPanel() throws IOException {
        firstPanel.removeAll();
        String[] info = commentPageListener.loadOriginalTweets(commentPageFormEvent);
        firstPanelCommentView = makePostView(info, commentPageFormEvent.getType());
        firstPanelCommentView.getMenuBar().setBounds(570,10,50,40);
        firstPanelCommentView.add(backButton);
        firstPanelCommentView.removeMouseListener(firstPanelCommentView.
                getMouseListeners()[0]);
        firstPanel.add(firstPanelCommentView);
        likesButton = new JButton(Texts.LIKE + info[4]);
        dislikesButton = new JButton(Texts.DISLIKE + info[5]);
        height += 10;
        likesButton.setBounds(140,height-20,150,40);
        dislikesButton.setBounds(300,height-20,150,40);
        likesButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        likesButton.setFont(Fonts.BUTTONS_FONT);
        likesButton.setFocusable(false);
        dislikesButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        dislikesButton.setFont(Fonts.BUTTONS_FONT);
        dislikesButton.setFocusable(false);
        height += 50;
        firstPanel.add(likesButton);
        firstPanel.add(dislikesButton);
        firstPanel.setBounds(0,0,700,height);
        this.add(firstPanel);
        noTweetLabel.setBounds(130,height,500,140);
        height += 150;
        noTweetLabel.setText(Texts.NO_COMMENT);
    }

   public void addStringListenerToPosts(PostView postView, String type){
       postView.addStringListener(text -> {
           if(text.startsWith("like")){
               try {
                   tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                   int[] a = tweetHistoryListener.like(tweetHistoryFormEvent,
                           type);
                   postView.setLikeText(String.valueOf(a[0]), String.valueOf(a[1]));
                   likesButton.setText(Texts.LIKE + a[0]);
                   dislikesButton.setText(Texts.DISLIKE + a[1]);
                   likesButton.repaint();
                   likesButton.revalidate();
                   dislikesButton.repaint();
                   dislikesButton.revalidate();
               }
               catch (Exception ignored){

               }
           }
           else if(text.startsWith("dislike")){
               try {
                   tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                   int[] a = tweetHistoryListener.dislike(tweetHistoryFormEvent,
                           type);
                   postView.setDisLikeText(String.valueOf(a[0]), String.valueOf(a[1]));
                   likesButton.setText(Texts.LIKE + a[0]);
                   dislikesButton.setText(Texts.DISLIKE + a[1]);
                   likesButton.repaint();
                   likesButton.revalidate();
                   dislikesButton.repaint();
                   dislikesButton.revalidate();
               }
               catch (Exception ignored){

               }
           }
           else if(text.startsWith("share")){
               if(type.equals("tweet")) {
                   listenMe(text+"+");
               }
               else{
                   listenMe(text+"-");
               }
           }
           else if(text.startsWith("reply")) {
               listenMe(String.valueOf(postView.getTweetId()));
               if (postView.getMoreIconVisibility()) {
                   newCommentPanel.setDefaultText(
                           Texts.COMMENT_J_TEXTAREA_DEFAULT_TEXT_2);
               }
           }
           else if(text.startsWith("block")){
               tweetHistoryFormEvent.setTweetId(postView.getTweetId());
               tweetHistoryListener.block(tweetHistoryFormEvent, type);
               for(PostView postView1: postViews){
                   postView1.setBlockItem(true);
               }
               firstPanelCommentView.setBlockItem(true);
           }
           else if(text.startsWith("unblock")){
               tweetHistoryFormEvent.setTweetId(postView.getTweetId());
               tweetHistoryListener.unblock(tweetHistoryFormEvent, type);
               for(PostView postView1: postViews){
                   postView1.setBlockItem(false);
               }
               firstPanelCommentView.setBlockItem(false);
           }

           else if(text.startsWith("report")){
               tweetHistoryFormEvent.setTweetId(postView.getTweetId());
               tweetHistoryListener.report(tweetHistoryFormEvent, type);
           }
           else if(text.startsWith("mute")){
               tweetHistoryFormEvent.setTweetId(postView.getTweetId());
               tweetHistoryListener.mute(tweetHistoryFormEvent, type);
               listenMe("mute");
           }

           else if(text.startsWith("retweet")){
               tweetHistoryFormEvent.setTweetId(postView.getTweetId());
               try {
                   tweetHistoryListener.retweet(tweetHistoryFormEvent, type);
                   postView.setRetweetText(String.valueOf(postView.getRetweetText()+1));
               } catch (InvalidEntrance ignored) {

               }
           }

           else if(text.startsWith("goodPeople")){

           }
           else if(text.startsWith("badPeople")){

           }
           else{
               listenMe("commentPage"+text);
           }
       });
   }


   public void addPanels(){
        super.addPanels();
        this.add(firstPanel);
  }
}

