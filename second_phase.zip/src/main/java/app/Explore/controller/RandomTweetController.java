package app.Explore.controller;

import Models.messages.Tweet;
import Models.auth.User;
import app.personalPage.subPart.tweetHistory.controller.TweetHistoryController;
import controller.MainController;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class RandomTweetController extends MainController {

    private final TweetHistoryController tweetHistoryController =
            new TweetHistoryController();

    public List<String[]> loadTweets() throws IOException {
        LinkedList<String[]> allIfo = new LinkedList<>();
        List<Tweet> tweets = randomTweets(context.getTweets().getAll("tweet"));
        for (Tweet tweet:tweets) {
            allIfo.add(tweetHistoryController.loadTweetInfo(tweet,
                    context.getUsers().get(tweet.getUserId()), ""));
        }
        return allIfo;
    }

    public List<Tweet> randomTweets(List<Tweet> allTweets) throws IOException {
        List<Tweet> publicTweets = new LinkedList<>();
        User current = context.getUsers().get(currentUserId);
        for (Tweet tweet:allTweets) {
             if(tweet.getForwarderId() == -1) {
                 User user = context.getUsers().get(tweet.getUserId());
                 if (user.getAccount().getPrivacy().equals("public")
                         && user.getAccount().isActive()
                         && !current.getSilentUsername().contains(tweet.getUserId())) {
                     publicTweets.add(tweet);
                 }
             }
        }
        for (int i = 1; i < publicTweets.size(); i++) {
            for (int j = i; j >0 ; j--) {
                if(publicTweets.get(j).getLike().size()<
                        publicTweets.get(j-1).getLike().size()){
                    Tweet tweet = publicTweets.get(j);
                    publicTweets.set(j,publicTweets.get(j-1));
                    publicTweets.set(j-1,tweet);
                }
            }
        }
        return publicTweets;
    }
}
