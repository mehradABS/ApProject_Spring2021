package app.Explore.subPart.watchProfile.listener;

import app.Explore.subPart.watchProfile.controller.WatchProfileController;

import java.io.IOException;

public class TopPanelListener {

    private final WatchProfileController watchProfileController;

    public TopPanelListener() {
        watchProfileController = new WatchProfileController();
    }

    public String loadImage(int userId, int scale){
         return watchProfileController.loadImage(userId, scale);
    }

    public String[] loadInfo(int userId) throws IOException {
        return watchProfileController.loadInfo(userId);
    }

    public boolean unfollow(int userId) throws IOException {
        return watchProfileController.unfollow(userId);
    }

    public boolean follow(int userId) throws IOException {
        return watchProfileController.follow(userId);
    }

    public void request(int userId) throws IOException {
        watchProfileController.request(userId);
    }

    public void report(int userId) throws IOException {
        watchProfileController.report(userId);
    }

    public boolean unblock(int userId) throws IOException {
        return watchProfileController.unblock(userId);
    }

    public void block(int userId) throws IOException {
        watchProfileController.block(userId);
    }

    public void mute(int userId) throws IOException {
        watchProfileController.mute(userId);
    }

    public void unMute(int userId) throws IOException {
        watchProfileController.unMute(userId);
    }
}
