package app.Explore.subPart.watchProfile.view;

import resources.Colors;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class ProfileMainPanel extends JPanel {


    private final ProfileTopPanel profileTopPanel;
    private StringListener stringListener;
    private int userId;

    public ProfileMainPanel() {
        profileTopPanel = new ProfileTopPanel();
        profileTopPanel.setStringListener(text -> {
            if(text.equals("back")) {
                listenMe("back");
            }
            else if(text.startsWith("message")){
                listenMe(text);
            }
        });
        //
        this.setLayout(null);
        this.setBounds(0,0,700,700);
        this.setBackground(Color.decode(Colors.INFO_PANEL));
        this.add(profileTopPanel);
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public void resetPanel(){
        //TODO
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public ProfileTopPanel getProfileTopPanel() {
        return profileTopPanel;
    }
}
