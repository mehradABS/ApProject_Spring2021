package app.Explore.subPart.watchProfile.view;


import app.Explore.subPart.watchProfile.listener.TopPanelListener;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ProfileTopPanel extends JPanel {

    private final TopPanelListener topPanelListener;
    private final JLabel usernameLabel;
    private final JTextArea biographyText;
    private StringListener stringListener;
    private final JLabel image;
    private final JButton followButton;
    private final JButton messageButton;
    private final JMenuBar menuBar;
    private final JMenu fileMenu;
    private final JMenuItem blockItem;
    private final JMenuItem reportItem;
    private final JMenuItem muteItem;
    private final JMenuItem unblockItem;
    private final JMenuItem unMuteItem;
    private final JLabel followings;
    private final JLabel followers;
    private final JLabel lastSeen;

    private int userId;

    public ProfileTopPanel() {
        topPanelListener = new TopPanelListener();
        //
        followButton = new JButton(Texts.FOLLOW);
        followButton.setBounds(540,10,100,45);
        followButton.setBackground(Color.decode(Colors.SUB_PANEL));
        followButton.setFocusable(false);
        //
        messageButton = new JButton(Images.MESSAGE_ICON);
        messageButton.setFocusable(false);
        messageButton.setBackground(Color.decode(Colors.POST_VIEW));
        messageButton.setBounds(490,10,45,45);
        //
        biographyText = new JTextArea();
        biographyText.setLineWrap(true);
        biographyText.setBackground(Color.decode(Colors.DEFAULT_INFO_PANEL));
        biographyText.setEditable(false);
        biographyText.setFont(Fonts.LABEL_FONT_INFO_PANEL);
        biographyText.setLayout(null);
        //
        image =new JLabel();
        image.setBounds(0,0,100,100);
        JPanel imagePanel = new JPanel();
        imagePanel.setLayout(null);
        imagePanel.setBounds(20,20,100,100);
        imagePanel.add(image);
        //
        usernameLabel = new JLabel();
        usernameLabel.setBounds(30,115,200,40);
        usernameLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        usernameLabel.setFont(Fonts.USERNAME_FONT);
        //
        menuBar = new JMenuBar();
        fileMenu = new JMenu(Texts.MENUBAR);
        fileMenu.setBackground(Color.decode(Colors.POST_VIEW));
        menuBar.add(fileMenu);
        menuBar.setBounds(620,10,50,40);
        menuBar.setBackground(Color.decode(Colors.POST_VIEW));
        blockItem = new JMenuItem(Images.BLOCK_ICON);
        reportItem = new JMenuItem(Images.REPORT_ICON);
        muteItem = new JMenuItem(Images.MUTE_ICON);
        unMuteItem = new JMenuItem(Images.UNMUTE_ICON);
        unMuteItem.setBackground(Color.decode(Colors.BLOCK));
        blockItem.setBackground(Color.decode(Colors.BLOCK));
        unblockItem = new JMenuItem(Images.UNBLOCK_ICON);
        unblockItem.setBackground(Color.decode(Colors.BLOCK));
        reportItem.setBackground(Color.decode(Colors.BLOCK));
        muteItem.setBackground(Color.decode(Colors.BLOCK));
        fileMenu.add(reportItem);
        menuBar.setBounds(430,10,50,40);
        //TODO add actionListener
        //
        JButton backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(650,10,45,45);
        backButton.setFocusable(false);
        backButton.setBackground(Color.decode(Colors.SUB_PANEL));
        backButton.addActionListener(e -> {
            listenMe("back");
        });
        //
        followers = new JLabel(Texts.FOLLOWERS);
        followings = new JLabel(Texts.FOLLOWINGS);
        followings.setBackground(Color.decode(Colors.SUB_PANEL));
        followers.setBackground(Color.decode(Colors.SUB_PANEL));
        followings.setBounds(230,150,160,40);
        followers.setBounds(400,150,160,40);
        followings.setFont(Fonts.BUTTONS_FONT);
        followers.setFont(Fonts.BUTTONS_FONT);
        lastSeen = new JLabel("lastSeenRecently");
        lastSeen.setBackground(Color.decode(Colors.SUB_PANEL));
        lastSeen.setBounds(10,150,200,40);
        lastSeen.setFont(Fonts.BUTTONS_FONT);
        //
        unMuteItem.addActionListener(e -> {
            try {
                topPanelListener.unMute(userId);
                fileMenu.remove(unMuteItem);
                fileMenu.add(muteItem);
                fileMenu.repaint();
                fileMenu.revalidate();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        muteItem.addActionListener(e -> {
            try {
                topPanelListener.mute(userId);
                fileMenu.remove(muteItem);
                fileMenu.add(unMuteItem);
                fileMenu.repaint();
                fileMenu.revalidate();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        blockItem.addActionListener(e->{
            try {
                topPanelListener.block(userId);
                fileMenu.remove(blockItem);
                fileMenu.add(unblockItem);
                fileMenu.repaint();
                fileMenu.revalidate();
                messageButton.setEnabled(false);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        unblockItem.addActionListener(e->{
            try {
                boolean f = topPanelListener.unblock(userId);
                fileMenu.remove(unblockItem);
                fileMenu.add(blockItem);
                fileMenu.repaint();
                fileMenu.revalidate();
                messageButton.setEnabled(f);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        reportItem.addActionListener(e->{
            try {
                topPanelListener.report(userId);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        followButton.addActionListener(e->{
            try {
                if(followButton.getText().equals(Texts.FOLLOW)){
                    boolean f =topPanelListener.follow(userId);
                    followButton.setText(Texts.UNFOLLOW);
                    followButton.repaint();
                    followButton.revalidate();
                    messageButton.setEnabled(f);
                }
                else if(followButton.getText().equals(Texts.UNFOLLOW)){
                    boolean f = topPanelListener.unfollow(userId);
                    followButton.setText(Texts.FOLLOW);
                    followButton.repaint();
                    followButton.revalidate();
                    messageButton.setEnabled(false);
                }
                else{
                    topPanelListener.request(userId);
                }
                setInfo();
                repaint();
                revalidate();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        messageButton.addActionListener(e -> listenMe("message" + userId));
        //
        this.setLayout(null);
        this.setBounds(0,0,700,200);
        this.setBackground(Color.decode(Colors.SUB_PANEL));
        this.add(imagePanel);
        this.add(usernameLabel);
        this.add(menuBar);
        this.add(followButton);
        this.add(messageButton);
        this.add(backButton);
        this.add(followings);
        this.add(followers);
        this.add(lastSeen);
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public void setInfo() throws IOException {
        String path = topPanelListener.loadImage(userId, 100);
        String[] info = topPanelListener.loadInfo(userId);
        image.setIcon(new ImageIcon(ImageIO.read(new File(path))));
        usernameLabel.setText(info[6]);
        biographyText.setText(info[5]);
        lastSeen.setText(info[0]);
        followButton.setText(info[1]);
        if(info[2].equals("block")){
            fileMenu.add(blockItem);
        }
        else{
            fileMenu.add(unblockItem);
        }
        messageButton.setEnabled(info[3].equals("true"));
        if(info[4].equals("true")){
            fileMenu.add(muteItem);
        }
        else{
            fileMenu.add(unMuteItem);
        }
        followers.setText(Texts.FOLLOWERS+info[7]);
        followings.setText(Texts.FOLLOWINGS+info[8]);

    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }
}
