package app.Explore.subPart.search.listener;

import app.Explore.subPart.search.controller.SearchController;
import app.Explore.subPart.search.event.SearchFormEvent;
import exceptions.InvalidEntrance;

import java.io.IOException;

public class SearchListener {

    private final SearchController searchController;

    public SearchListener() {
        searchController = new SearchController();
    }

    public int findUser(SearchFormEvent searchFormEvent)
            throws IOException, InvalidEntrance {
       return searchController.findUser(searchFormEvent.getUsername());
    }
}
