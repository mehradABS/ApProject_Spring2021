package app.Explore.subPart.search.controller;

import Models.auth.User;
import controller.MainController;
import exceptions.InvalidEntrance;

import java.io.IOException;
import java.util.List;

public class SearchController extends MainController {


    public int findUser(String username) throws IOException, InvalidEntrance {

        User current = context.getUsers().get(currentUserId);
        List<User> users = context.getUsers().getAll();
        User user = null;
        for (User allUser : users) {
            if(allUser.getAccount().isActive()) {
                if (allUser.getAccount().getUsername().equals(username)
                        && !username.equals(current.getAccount().getUsername())) {
                    user = allUser;
                    break;
                }
            }
        }
        if (user != null) {
            return user.getId();
        } else {
           throw new InvalidEntrance("username");
        }
    }
}

