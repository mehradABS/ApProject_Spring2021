package app.Explore.subPart.search.event;

import java.util.EventObject;

public class SearchFormEvent extends EventObject {

    private String username;

    public SearchFormEvent(Object source) {
        super(source);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
