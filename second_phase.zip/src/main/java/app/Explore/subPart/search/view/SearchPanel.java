package app.Explore.subPart.search.view;

import app.Explore.subPart.search.event.SearchFormEvent;
import app.Explore.subPart.search.listener.SearchListener;
import exceptions.InvalidEntrance;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class SearchPanel extends JPanel {

    private final JTextArea searchArea;
    private final JButton searchButton;
    private final JLabel defaultText;
    private final JLabel invalidLabel;
    private StringListener stringListener;
    private final SearchFormEvent searchFormEvent;
    private final SearchListener searchListener;
    private int userId;

    public SearchPanel() {
        searchFormEvent = new SearchFormEvent(this);
        searchListener = new SearchListener();
        //
        searchArea = new JTextArea();
        searchArea.setBounds(10, 10, 500, 84);
        searchArea.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        searchArea.setFont(Fonts.TWEET_FONT);
        defaultText = new JLabel();
        defaultText.setFont(searchArea.getFont());
        defaultText.setText(Texts.SEARCH_AREA_DEFAULT_TEXT);
        defaultText.setBounds(0, -7, 200, 40);
        searchArea.add(defaultText);
        searchArea.getDocument().putProperty("name", "TextArea");
        searchButton = new JButton(Images.SEARCH_ICON);
        searchButton.setEnabled(false);
        searchButton.setFocusable(false);
        searchArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                defaultText.setVisible(false);
                searchButton.setEnabled(true);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                if (searchArea.getText().isEmpty()) {
                    defaultText.setVisible(true);
                    searchButton.setEnabled(false);
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
        searchButton.setBounds(530, 20, 80, 70);
        searchButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        searchButton.addActionListener(e -> searchButtonAction());
        //
        invalidLabel = new JLabel(Texts.INVALID_SEARCH);
        invalidLabel.setBounds(200, 90, 400, 40);
        invalidLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        invalidLabel.setFont(Fonts.Label_FONT);
        invalidLabel.setVisible(false);
        //
        this.setLayout(null);
        this.setBounds(0, 0, 700, 150);
        this.setBackground(Color.decode(Colors.SUB_PANEL));
        this.add(searchArea);
        this.add(searchButton);
        this.add(invalidLabel);
    }

    public JTextArea getSearchArea() {
        return searchArea;
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JLabel getDefaultText() {
        return defaultText;
    }

    public JLabel getInvalidLabel() {
        return invalidLabel;
    }

    public void searchButtonAction() {
        try {
            searchFormEvent.setUsername(searchArea.getText());
            userId = searchListener.findUser(searchFormEvent);
            invalidLabel.setVisible(false);
            listenMe("search");
        }
        catch (InvalidEntrance e){
            invalidLabel.setVisible(true);
        }

        catch (Exception i){
            i.printStackTrace();
        }
    }

    public void setStringListener(StringListener stringListener){
        this.stringListener = stringListener;
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public int getUserId() {
        return userId;
    }

    public void resetPanel(){
        searchArea.setText(null);
        searchButton.setEnabled(false);
        invalidLabel.setVisible(false);
    }
}