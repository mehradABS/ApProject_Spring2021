package app.Explore.listener;

import app.Explore.controller.RandomTweetController;

import java.io.IOException;
import java.util.List;

public class RandomTweetListener {

    private final RandomTweetController controller = new RandomTweetController();

    public List<String[]> loadTweets(){
        try {
            return controller.loadTweets();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
