package app.Explore.view;

import app.Explore.subPart.search.view.SearchPanel;
import app.Explore.subPart.watchProfile.view.ProfileMainPanel;
import app.personalPage.subPart.forwardMessage.view.ForwardPanel;
import app.timeLine.subPart.commentsPage.view.CommentsPagePanel;
import resources.Colors;
import view.listeners.StringListener;
import view.postView.commentPage.CommentView;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ExploreMainPanel extends JPanel {

    private String witchPanel = " ";
    private final SearchPanel searchPanel;
    private StringListener stringListener;
    private final ProfileMainPanel profileMainPanel;
    private final RandomTweetPanel randomTweetPanel;
    private final List<Integer> tweetHistoryKeeperMemento;
    private final JScrollPane tweetHistoryPanelKeeper;
    private final CommentsPagePanel<CommentView> commentsPagePanel;
    private final ForwardPanel forwardPanel = new ForwardPanel();
    public ExploreMainPanel() {
        randomTweetPanel = new RandomTweetPanel(CommentView::new);
        searchPanel = new SearchPanel();
        //
        profileMainPanel = new ProfileMainPanel();
        profileMainPanel.setStringListener(text -> {
            if(text.equals("back")){
                if(witchPanel.equals("list")){
                    witchPanel = "";
                    listenMe("list");
                }
                else {
                    resetPanel();
                    randomTweetPanel.setInfo();
                }
                repaint();
                revalidate();
            }
            else if(text.startsWith("message")){
                listenMe(text);
            }
        });
        //
        searchPanel.setStringListener(text -> {
            searchPanel.resetPanel();
            removeAll();
            profileMainPanel.setUserId(searchPanel.getUserId());
            profileMainPanel.getProfileTopPanel().setUserId(searchPanel.getUserId());
            profileMainPanel.getProfileTopPanel().setInfo();
            add(profileMainPanel);
            repaint();
            revalidate();
        });
        //
        tweetHistoryKeeperMemento = new LinkedList<>();
        tweetHistoryPanelKeeper = new JScrollPane(randomTweetPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        tweetHistoryPanelKeeper.getVerticalScrollBar().setUnitIncrement(16);
        tweetHistoryPanelKeeper.setBounds(0,160,700,550);
        tweetHistoryPanelKeeper.setBackground(Color.decode(Colors.PROFILE_MAIN_PANEL));
        commentsPagePanel = new CommentsPagePanel<>(
                CommentView::new);
        //
        randomTweetPanel.addStringListeners(text -> {
            if(text.startsWith("commentPage")){
                commentsPagePanel.setOriginalTweetId(Integer.parseInt(
                        text.substring(11)));
                tweetHistoryKeeperMemento.add(Integer.parseInt(
                        text.substring(11)));
                if(tweetHistoryKeeperMemento.size() == 1){
                    commentsPagePanel.setOriginalMessageType("tweet");
                }
                else{
                    commentsPagePanel.setOriginalMessageType("comment");
                }
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.equals("mute")){
                randomTweetPanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(randomTweetPanel);
            }
            else if(text.startsWith("share")){
                searchPanel.setVisible(false);
                tweetHistoryPanelKeeper.setVisible(false);
                forwardPanel.setMessageId(Integer.parseInt(text.substring(5,
                        text.length()-1)));
                if(text.charAt(text.length()-1) == '+') {
                    forwardPanel.setMessageType("tweet");
                }
                else{
                    forwardPanel.setMessageType("comment");
                }
                forwardPanel.setInfo();
                add(forwardPanel);
            }
            else {
                tweetHistoryPanelKeeper.setVisible(false);
                randomTweetPanel.getNewCommentPanel().setTweetId(Integer.parseInt(text));
                randomTweetPanel.getNewCommentPanel().setBounds
                        (0,160,700,550);
                add(randomTweetPanel.getNewCommentPanel());
            }
            repaint();
            revalidate();
        });
        //
        commentsPagePanel.addStringListeners(text -> {
            if(text.startsWith("commentPage")){
                tweetHistoryKeeperMemento.add(Integer.parseInt(
                        text.substring(11)));
                commentsPagePanel.setOriginalTweetId(Integer.parseInt(
                        text.substring(11)));
                if(tweetHistoryKeeperMemento.size() == 1){
                    commentsPagePanel.setOriginalMessageType("tweet");
                }
                else{
                    commentsPagePanel.setOriginalMessageType("comment");
                }
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.equals("back")){
                tweetHistoryKeeperMemento.remove(tweetHistoryKeeperMemento
                        .size()-1);
                if(tweetHistoryKeeperMemento.size() > 0){
                    commentsPagePanel.setOriginalTweetId(
                            tweetHistoryKeeperMemento.get(
                                    tweetHistoryKeeperMemento.size()-1));
                    if(tweetHistoryKeeperMemento.size() == 1){
                        commentsPagePanel.setOriginalMessageType("tweet");
                    }
                    else{
                        commentsPagePanel.setOriginalMessageType("comment");
                    }
                    commentsPagePanel.setInfo();
                    tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
                }
                else{
                    randomTweetPanel.setInfo();
                    tweetHistoryPanelKeeper.setViewportView(randomTweetPanel);
                }
            }
            else if(text.equals("mute")){
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.startsWith("share")){
                searchPanel.setVisible(false);
                tweetHistoryPanelKeeper.setVisible(false);
                forwardPanel.setMessageId(Integer.parseInt(text.substring(5,
                        text.length()-1)));
                if(text.charAt(text.length()-1) == '+') {
                    forwardPanel.setMessageType("tweet");
                }
                else{
                    forwardPanel.setMessageType("comment");
                }
                forwardPanel.setInfo();
                add(forwardPanel);
            }
            else {
                tweetHistoryPanelKeeper.setVisible(false);
                randomTweetPanel.getNewCommentPanel().setTweetId(Integer.parseInt(text));
                randomTweetPanel.getNewCommentPanel().setBounds
                        (0,160,700,550);
                add(randomTweetPanel.getNewCommentPanel());
            }
            repaint();
            revalidate();
        });
        //
        randomTweetPanel.getNewCommentPanel().setStringListener(text -> {
            if(text.equals("back")){
                remove(randomTweetPanel.getNewCommentPanel());
                tweetHistoryPanelKeeper.setVisible(true);
                repaint();
                revalidate();
            }
            else if(text.equals("tweetButton")){
                remove(randomTweetPanel.getNewCommentPanel());
                randomTweetPanel.loadCommentsNumberOfPost(
                        randomTweetPanel.getNewCommentPanel().getTweetId());
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setVisible(true);
                repaint();
                revalidate();
            }
        });
        //
        forwardPanel.setStringListener(text -> {
            remove(forwardPanel);
            forwardPanel.resetPanel();
            searchPanel.setVisible(true);
            tweetHistoryPanelKeeper.setVisible(true);
            repaint();
            revalidate();
        });
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.INFO_PANEL));
        this.setBounds(260,50,700,700);
        this.add(searchPanel);
        add(tweetHistoryPanelKeeper);
    }

    public SearchPanel getSearchPanel() {
        return searchPanel;
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public ProfileMainPanel getProfileMainPanel() {
        return profileMainPanel;
    }

    public void resetPanel(){
        removeAll();
        searchPanel.resetPanel();
        profileMainPanel.resetPanel();
        try {
            resetRandomTweetsPanel();
        } catch (IOException e) {
            e.printStackTrace();
        }
        add(tweetHistoryPanelKeeper);
        add(searchPanel);
        repaint();
        revalidate();

        //TODO
    }

    public void setWitchPanel(String witchPanel) {
        this.witchPanel = witchPanel;
    }

    public void resetRandomTweetsPanel() throws IOException {
        tweetHistoryKeeperMemento.removeAll(tweetHistoryKeeperMemento);
        tweetHistoryPanelKeeper.setViewportView(randomTweetPanel);
        randomTweetPanel.getNewCommentPanel().resetPanel();
        tweetHistoryPanelKeeper.setVisible(true);
        repaint();
        revalidate();
    }

    public void setInfo(){
        try {
            randomTweetPanel.setInfo();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
