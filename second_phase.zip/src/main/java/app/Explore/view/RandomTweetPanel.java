package app.Explore.view;

import app.Explore.listener.RandomTweetListener;
import app.timeLine.view.TimelinePage;
import view.postView.commentPage.CommentView;

import java.util.function.Supplier;

public class RandomTweetPanel extends TimelinePage {

    private final RandomTweetListener listener = new RandomTweetListener();
    public RandomTweetPanel(Supplier<? extends CommentView> ctor) {
        super(ctor);
    }

    public void loadTweets(){
       this.tweetsInfo =  listener.loadTweets();
    }
}
