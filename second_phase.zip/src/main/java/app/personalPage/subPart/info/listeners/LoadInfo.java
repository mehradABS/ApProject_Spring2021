package app.personalPage.subPart.info.listeners;

import app.personalPage.subPart.info.controller.LoadInfoController;

import java.io.IOException;

public class LoadInfo implements LoadInfoListener {

    private final LoadInfoController loadInfoController;

    public LoadInfo() {
        loadInfoController = new LoadInfoController();
    }

    @Override
    public String loadImage(int profileScaledHeight) {
        return loadInfoController.loadImage(profileScaledHeight);
    }

    @Override
    public String[] getInfo() throws IOException {
        return loadInfoController.getInfo();
    }

    @Override
    public String[] getAllInfo() throws IOException {
        return loadInfoController.getAllInfo();
    }

}
