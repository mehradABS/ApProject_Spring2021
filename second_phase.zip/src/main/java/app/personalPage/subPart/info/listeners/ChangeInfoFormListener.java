package app.personalPage.subPart.info.listeners;

import app.authentication.event.RegistrationFormEvent;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;

import java.io.IOException;

public interface ChangeInfoFormListener {
    void changeInfoEventOccurred(RegistrationFormEvent registrationFormEvent,
                                 String type) throws InvalidEntrance, IOException, NullException, ChosenInfo;
}
