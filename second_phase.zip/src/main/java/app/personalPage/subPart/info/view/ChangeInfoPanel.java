package app.personalPage.subPart.info.view;

import app.authentication.event.RegistrationFormEvent;
import app.personalPage.subPart.info.listeners.ChangeInfoListener;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.SqlDateModel;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class ChangeInfoPanel extends JPanel {

    private final JTextArea textField;
    private final JLabel label;
    private final List<StringListener> stringListeners;
    private final ChangeInfoListener changeInfoListener;
    private final RegistrationFormEvent registrationFormEvent;
    private final JLabel nullLabel;
    private final JLabel repeatedLabel;
    private final JLabel invalidLabel;
    private final JDatePickerImpl datePicker;
    private final JScrollPane scrollPane;

    public ChangeInfoPanel() {
        stringListeners = new LinkedList<>();
        //
        label = new JLabel();
        label.setFont(Fonts.LABEL_FONT_INFO_PANEL);
        label.setBounds(27,24,200,60);
        //
        SqlDateModel model = new SqlDateModel();
        JDatePanelImpl datePanel = new JDatePanelImpl(model);
        datePicker = new JDatePickerImpl(datePanel);
        datePicker.setBounds(30, 80, 460, 100);
        datePicker.getJFormattedTextField().setBounds(30,80,460,100);
        datePicker.getJFormattedTextField()
                .setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        datePicker.getJFormattedTextField().setFont(Fonts.BUTTONS_FONT);
        datePicker.add(label);
        datePicker.setVisible(false);
        //
        nullLabel = new JLabel(Texts.NULL);
        nullLabel.setBounds(190,200,400,40);
        nullLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        nullLabel.setFont(Fonts.Label_FONT);
        nullLabel.setVisible(false);
        //
        repeatedLabel = new JLabel();
        repeatedLabel.setBounds(190,200,400,40);
        repeatedLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        repeatedLabel.setFont(Fonts.Label_FONT);
        repeatedLabel.setVisible(false);
        //
        invalidLabel = new JLabel();
        invalidLabel.setBounds(190,200,400,40);
        invalidLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        invalidLabel.setFont(Fonts.Label_FONT);
        invalidLabel.setVisible(false);
        //
        changeInfoListener = new ChangeInfoListener();
        registrationFormEvent = new RegistrationFormEvent(this);
        //
        textField = new JTextArea();
        textField.setLineWrap(true);
        textField.setBounds(0,0,460,100);
        textField.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        textField.setFont(Fonts.BUTTONS_FONT);
        scrollPane = new JScrollPane(textField,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(30,80,460,100);
        //
        JButton saveButton = new JButton();
        saveButton.setBounds(160,240,180,50);
        saveButton.setText(Texts.SAVE_BUTTON);
        saveButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        saveButton.setFont(Fonts.BUTTONS_FONT);
        saveButton.setFocusable(false);
        saveButton.addActionListener(e -> {
            saveButtonAction();
            if(label.getText().equals(Texts.USERNAME_INFO_PANEL)
             || label.getText().equals(Texts.BIOGRAPHY_INFO_PANEL)){
                try {
                    listenMe(label.getText());
                } catch (IOException ignored) {

                }
            }
        });
        //
        JButton backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(450,10,45,45);
        backButton.setFocusable(false);
        backButton.setBackground(Color.decode(Colors.SUB_PANEL));
        backButton.addActionListener(e -> {
            resetPanel();
            try {
                listenMe("back");
            } catch (IOException ignored) {

            }
        });
        //
        this.setBackground(Color.decode(Colors.SUB_PANEL));
        this.setBounds(0,0,500,500);
        this.setLayout(null);
        this.add(scrollPane);
        this.add(saveButton);
        this.add(backButton);
        this.add(nullLabel);
        this.add(repeatedLabel);
        this.add(invalidLabel);
        this.add(datePicker);
        this.add(label);
    }

    public void setTextOfTextField(String text){
        textField.setText(text);
    }

    public void setTextOfLabel(String text){
        label.setText(text);
    }

    public void addStringListener(StringListener stringListener) {
        this.stringListeners.add(stringListener);
    }

    public void setDatePicker(String text){
        scrollPane.setVisible(false);
        datePicker.getJFormattedTextField().setText(text);
        datePicker.setVisible(true);
    }

    public void listenMe(String name) throws IOException {
        for (StringListener stringListener : stringListeners) {
            stringListener.stringEventOccurred(name);
        }
    }
    public void saveButtonAction(){
        try {
            switch (label.getText()) {
                case Texts.BIRTH -> registrationFormEvent.setBirth(LocalDate.of(
                        datePicker.getModel().getYear(),
                        datePicker.getModel().getMonth() + 1,
                        datePicker.getModel().getDay()));
                case Texts.BIOGRAPHY_INFO_PANEL, Texts.EMAIL_INFO_PANEL ->
                        registrationFormEvent.setEmail(textField.getText());
                case Texts.FIRSTNAME_INFO_PANEL ->
                        registrationFormEvent.setFirstname(textField.getText());
                case Texts.LASTNAME_INFO_PANEL ->
                        registrationFormEvent.setLastname(textField.getText());
                case Texts.USERNAME_INFO_PANEL ->
                        registrationFormEvent.setUsername(textField.getText());
                case Texts.PASSWORD_INFO_PANEL ->
                        registrationFormEvent.setPassword(textField.getText());
                case Texts.PHONE_INFO_PANEL ->
                        registrationFormEvent.setPhone(textField.getText());
            }
            changeInfoListener.changeInfoEventOccurred(registrationFormEvent,
                    label.getText());
            resetPanel();
            listenMe("save");
        }
        catch (NullException e){
            invalidLabel.setVisible(false);
            repeatedLabel.setVisible(false);
            nullLabel.setVisible(true);
        }
        catch (ChosenInfo e){
            nullLabel.setVisible(false);
            invalidLabel.setVisible(false);
            repeatedLabel.setVisible(true);
            switch (e.getType()) {
                case "username" -> repeatedLabel.setText(Texts.REPEATED_USERNAME);
                case "password" -> repeatedLabel.setText(Texts.REPEATED_PASSWORD);
                case "email" -> repeatedLabel.setText(Texts.REPEATED_EMAIL);
                case "phone" -> repeatedLabel.setText(Texts.REPEATED_PHONE);
            }
        }
        catch (InvalidEntrance e){
            nullLabel.setVisible(false);
            invalidLabel.setVisible(true);
            repeatedLabel.setVisible(false);
            if(e.getType().equals("email")){
                invalidLabel.setText(Texts.INVALID_EMAIL);
            }
            else if(e.getType().equals("phone")){
                invalidLabel.setText(Texts.INVALID_PHONE);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void resetPanel(){
        datePicker.setVisible(false);
        scrollPane.setVisible(true);
        nullLabel.setVisible(false);
        invalidLabel.setVisible(false);
        repeatedLabel.setVisible(false);
    }
}
