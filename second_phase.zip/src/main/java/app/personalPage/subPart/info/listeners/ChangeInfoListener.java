package app.personalPage.subPart.info.listeners;

import app.authentication.event.RegistrationFormEvent;
import app.personalPage.subPart.info.controller.ChangeInfoController;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;

import java.io.IOException;

public class ChangeInfoListener implements ChangeInfoFormListener {

    private final ChangeInfoController changeInfoController;

    public ChangeInfoListener() {
        changeInfoController = new ChangeInfoController();
    }

    @Override
    public void changeInfoEventOccurred
            (RegistrationFormEvent registrationFormEvent, String type)
            throws InvalidEntrance, IOException, NullException, ChosenInfo {
        changeInfoController.change(registrationFormEvent, type);
    }
}
