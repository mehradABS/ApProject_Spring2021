package app.personalPage.subPart.info.listeners;

import java.io.IOException;

public interface LoadInfoListener {
    String loadImage(int profileScaledHeight) throws IOException;
    String[] getInfo() throws IOException;
    String[] getAllInfo() throws IOException;
}
