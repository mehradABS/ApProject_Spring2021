package app.personalPage.subPart.info.event;

import java.util.EventObject;

public class InfoFormEvent extends EventObject {

    public InfoFormEvent(Object source) {
        super(source);
    }
}
