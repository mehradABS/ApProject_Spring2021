package app.personalPage.subPart.info.controller;

import controller.log.Log;
import Models.auth.User;
import app.authentication.controller.RegisterController;
import app.authentication.event.RegistrationFormEvent;
import controller.MainController;
import exceptions.ChosenInfo;
import exceptions.InvalidEntrance;
import exceptions.NullException;
import resources.Texts;

import java.io.IOException;
import java.time.LocalDateTime;

public class ChangeInfoController extends MainController {
    private final RegisterController registerController;

    public ChangeInfoController() {
        registerController = new RegisterController();
    }

    public void change(RegistrationFormEvent registrationFormEvent,
                       String type) throws IOException,
            ChosenInfo, NullException, InvalidEntrance {
        User user = context.getUsers().get(currentUserId);
        switch (type) {
            case Texts.FIRSTNAME_INFO_PANEL -> {
                String firstname = registrationFormEvent.getFirstname();
                if (firstname.equals("")) {
                    throw new NullException();
                }
                user.setFirstname(firstname);
                Log log = new Log("firstname changed", LocalDateTime.now(),
                        1, currentUserId);
                Log.log(log);
            }
            case Texts.LASTNAME_INFO_PANEL -> {
                String lastname = registrationFormEvent.getLastname();
                if (lastname.equals("")) {
                    throw new NullException();
                }
                user.setLastname(lastname);
                Log log = new Log("lastname changed", LocalDateTime.now(),
                        1, currentUserId);
                Log.log(log);
            }
            case Texts.USERNAME_INFO_PANEL -> {
                String username = registrationFormEvent.getUsername();
                if (username.equals("")) {
                    throw new NullException();
                }
                if (registerController.checkNewUsername(username,
                        context.getUsers().getAll())) {
                    user.getAccount().setUsername(username);
                    Log log = new Log("username changed", LocalDateTime.now(),
                            1, currentUserId);
                    Log.log(log);
                } else {
                    throw new ChosenInfo("username");
                }
            }
            case Texts.PASSWORD_INFO_PANEL -> {
                String password = registrationFormEvent.getPassword();
                if (password.equals("")) {
                    throw new NullException();
                }
                if (registerController.checkNewPassword(password,
                        context.getUsers().getAll())) {
                    user.getAccount().setPassword(password);
                    Log log = new Log("password changed", LocalDateTime.now(),
                            1, currentUserId);
                    Log.log(log);
                } else {
                    throw new ChosenInfo("password");
                }
            }
            case Texts.EMAIL_INFO_PANEL -> {
                String email = registrationFormEvent.getEmail();
                int j = email.length() - 1;
                for (; j >= 0; j--) {
                    if (email.charAt(j) != ' ') {
                        break;
                    }
                }
                email = email.substring(0, j + 1);
                if (!(email.toLowerCase().endsWith("@gmail.com") ||
                        email.toLowerCase().endsWith("@yahoo.com"))) {
                    throw new InvalidEntrance("email");
                }
                if (registerController.checkNewEmail(email,
                        context.getUsers().getAll())) {
                    user.setEmailAddress(email);
                    Log log = new Log("email changed", LocalDateTime.now(),
                            1, currentUserId);
                    Log.log(log);
                } else {
                    throw new ChosenInfo("email");
                }
            }
            case Texts.PHONE_INFO_PANEL -> {
                String phone = registrationFormEvent.getPhone();
                int k = phone.length() - 1;
                for (; k >= 0; k--) {
                    if (phone.charAt(k) != ' ') {
                        break;
                    }
                }
                phone = phone.substring(0, k + 1);
                boolean number = true;
                if (phone.equals("")) {
                    phone = "---";
                } else if (registerController.checkNewPhone(phone,
                        context.getUsers().getAll())) {
                    for (int i = 0; i < phone.length(); i++) {
                        if (!(phone.charAt(i) - '0' < 10 &&
                                phone.charAt(i) - '0' > -1)) {
                            number = false;
                            break;
                        }
                    }
                    if (!number) {
                        throw new InvalidEntrance("phone");
                    }
                } else {
                    throw new ChosenInfo("phone");
                }
                user.setPhoneNumber(phone);
                Log log = new Log("phone changed", LocalDateTime.now(),
                        1, currentUserId);
                Log.log(log);
            }
            case Texts.BIRTH -> {
                user.setBirth(registrationFormEvent.getBirth());
                Log log = new Log("birth changed", LocalDateTime.now(),
                        1, currentUserId);
                Log.log(log);
            }
            case Texts.BIOGRAPHY_INFO_PANEL -> {
                String biography = registrationFormEvent.getEmail();
                if(biography.equals("")){
                    biography = "null";
                }
                user.setBiography(biography);
                Log log = new Log("biography changed", LocalDateTime.now(),
                        1, currentUserId);
                Log.log(log);
            }
        }
        context.getUsers().set(user);
    }
}
