package app.personalPage.subPart.newPost.controller;

import controller.log.Log;
import Models.messages.Message;
import Models.messages.Tweet;
import Models.auth.User;
import exceptions.InvalidFile;
import app.personalPage.subPart.newPost.event.PostFormEvent;
import controller.MainController;

import java.io.IOException;
import java.time.LocalDateTime;

public class PostController extends MainController {

    public String checkPhoto(PostFormEvent postFormEvent)
            throws IOException, InvalidFile {
        if (postFormEvent.getFile().getPath().endsWith(".png")) {
            context.getTweets().setTweetImage(
                    context.getMessages().getIDCounter() + 1, postFormEvent
                            .getFile().getPath(), postFormEvent.getProfileScaledWidth(),
                    postFormEvent.getProfileScaledHeight());
            return context.getTweets().loadTweetImage(
                    context.getMessages().getIDCounter() + 1);
        } else {
            throw new InvalidFile();
        }
    }

    public void NewTweet(PostFormEvent postFormEvent)
            throws IOException {
        User user = context.getUsers().get(currentUserId);
        Message.setId_counter(context.getMessages().getIDCounter());
        Tweet tweet = new Tweet("Tweet", postFormEvent.getTweetText(),
                user,
                LocalDateTime.now(),
                "hello");
        context.getMessages().setIDCounter(Message.getId_counter());
        user.getTweetsID().add(tweet.getId());
        context.getUsers().set(user);
        context.getTweets().set(tweet, "tweet");
        Log log = new Log("wrote a new tweet", LocalDateTime.now(),
                2, currentUserId);
        Log.log(log);
    }

    public void deleteTweetImage(int id) throws IOException {
        if (id == -1) {
            context.getTweets().deleteTweetImage(
                    context.getMessages().getIDCounter() + 1);
        }
        else{
            context.getTweets().deleteTweetImage(id);
        }
    }
}