package app.personalPage.subPart.newPost.view;

import app.personalPage.subPart.newPost.event.PostFormEvent;
import app.personalPage.subPart.newPost.listener.PostListener;
import exceptions.InvalidFile;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;


public class NewPostPanel extends JPanel {

    protected final JTextArea tweetText;
    protected final JButton tweetButton;
    protected final JLabel defaultText;
    protected final JLabel pngLabel;
    protected final JFileChooser chooser;
    protected final PostFormEvent postFormEvent;
    protected final PostListener postListener;
    protected final Panel imagePanel;
    protected final JLabel imageKeeper;
    protected StringListener stringListener;

    public NewPostPanel() {
        imageKeeper = new JLabel();
        imageKeeper.setBounds(0,0,500,200);
        //
        JButton closeImageButton = new JButton(Images.CLOSE_ICON);
        closeImageButton.setBounds(10,10,45,45);
        closeImageButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        closeImageButton.setFocusable(false);
        closeImageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeImageButtonAction();
                } catch (IOException ignored) {

                }
                imageKeeper.setIcon(null);
                imagePanel.setVisible(false);
            }
        });
        //
        imagePanel = new Panel();
        imagePanel.setBounds(100,200,500,180);
        imagePanel.setBackground(Color.decode(Colors.IMAGE_KEEPER_COLOR));
        imagePanel.add(imageKeeper);
        imageKeeper.add(closeImageButton);
        imagePanel.setVisible(false);
        //
        postListener = new PostListener();
        //
        postFormEvent = new PostFormEvent(this);
        //
        chooser = new JFileChooser();
        //
        pngLabel = new JLabel(Texts.PNG_LABEL);
        pngLabel.setBounds(280,300,400,40);
        pngLabel.setForeground(Color.decode(Colors.LABEL_COLOR));
        pngLabel.setFont(Fonts.Label_FONT);
        pngLabel.setVisible(false);
        //
        JButton addPhotoButton = new JButton(Texts.ADD_PHOTO_FOR_TWEET);
        addPhotoButton.setBounds(50,440,150,40);
        addPhotoButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        addPhotoButton.setFocusable(false);
        addPhotoButton.setFont(Fonts.BUTTONS_FONT);
        addPhotoButton.addActionListener(e-> addPhotoButtonAction());
        //
        tweetButton = new JButton(Texts.ADD_TWEET_BUTTON_TEXT);
        tweetButton.setBounds(200,440,150,40);
        tweetButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        tweetButton.setFocusable(false);
        tweetButton.setFont(Fonts.BUTTONS_FONT);
        tweetButton.setEnabled(false);
        tweetButton.addActionListener(e -> {
            try {
                PostButtonAction();
                listenMe("tweetButton");
            } catch (IOException ignored) {

            }
        });
        //
        tweetText = new JTextArea();
        tweetText.setLayout(null);
        tweetText.setFont(Fonts.TWEET_FONT);
        tweetText.setLineWrap(true);
        JScrollPane tweetTextPanel = new JScrollPane(tweetText,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        tweetTextPanel.setBounds(10,10,600,180);
        tweetText.setBounds(10,10,600,180);
        tweetText.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        tweetText.setFont(Fonts.TWEET_FONT);
        defaultText = new JLabel(Texts.TWEET_DEFAULT_TEXT);
        defaultText.setBounds(0,-5,200,40);
        defaultText.setFont(tweetText.getFont());
        tweetText.add(defaultText);
        tweetText.getDocument().putProperty("name","TextArea");
        tweetText.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                defaultText.setVisible(false);
                tweetButton.setEnabled(true);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                   if(tweetText.getText().isEmpty()){
                       defaultText.setVisible(true);
                       tweetButton.setEnabled(false);
                   }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });

        this.setLayout(null);
        this.add(tweetTextPanel);
        this.add(addPhotoButton);
        this.add(tweetButton);
        this.add(imagePanel);
        this.add(pngLabel);
        this.setBounds(0,200,700,500);
        this.setBackground(Color.decode(Colors.PERSONAL_PAGE_DOWN_PANEL));
    }

    public void setImage(ImageIcon icon){
        imageKeeper.setIcon(icon);
        imagePanel.setVisible(true);
    }

    public void PostButtonAction() throws IOException {
        postFormEvent.setTweetText(tweetText.getText());
        postListener.newPostEventOccurred(postFormEvent);
        resetPanel();
    }

    public void resetPanel() throws IOException {
        if(imageKeeper.getIcon() != null){
            closeImageButtonAction();
            imageKeeper.setIcon(null);
        }
        imagePanel.setVisible(false);
        tweetButton.setEnabled(false);
        tweetText.setText("");
        defaultText.setVisible(true);
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name) throws IOException {
        stringListener.stringEventOccurred(name);
    }

    public void closeImageButtonAction() throws IOException {
      postListener.deleteTweetImage();
    }

    public void addPhotoButtonAction(){
        pngLabel.setVisible(false);
        int res = chooser.showOpenDialog(null);
        if (res == JFileChooser.APPROVE_OPTION) {
            postFormEvent.setFile(chooser.getSelectedFile());
            postFormEvent.setProfileScaledHeight(200);
            postFormEvent.setProfileScaledWidth(500);

            try {
                String filePath = postListener.
                        addPhotoEventOccurred(postFormEvent);
                setImage(new ImageIcon(ImageIO.read(new File(filePath))));
                imagePanel.repaint();
                imagePanel.revalidate();
                repaint();
                revalidate();
            }
            catch (InvalidFile e){
                pngLabel.setVisible(true);
            }

            catch (Exception ignored){

            }
        }
    }
}