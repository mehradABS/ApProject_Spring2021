package app.personalPage.subPart.newPost.listener;

import app.personalPage.subPart.newPost.event.PostFormEvent;
import exceptions.InvalidFile;

import java.io.IOException;

public interface PostFormListener {
     String addPhotoEventOccurred(PostFormEvent postFormEvent) throws IOException, InvalidFile;
     void newPostEventOccurred(PostFormEvent postFormEvent) throws IOException;
}
