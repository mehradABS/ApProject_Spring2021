package app.personalPage.subPart.newPost.listener;

import app.personalPage.subPart.newPost.controller.PostController;
import app.personalPage.subPart.newPost.event.PostFormEvent;
import exceptions.InvalidFile;

import java.io.IOException;

public class PostListener implements PostFormListener{

    private final PostController postController;

    public PostListener() {
        this.postController = new PostController();
    }

    @Override
    public String addPhotoEventOccurred(PostFormEvent postFormEvent)
            throws IOException, InvalidFile {
        return postController.checkPhoto(postFormEvent);
    }

    @Override
    public void newPostEventOccurred(PostFormEvent postFormEvent)
            throws IOException {
        postController.NewTweet(postFormEvent);
    }

    public void deleteTweetImage() throws IOException {
        postController.deleteTweetImage(-1);
    }

    public PostController getPostController() {
        return postController;
    }
}
