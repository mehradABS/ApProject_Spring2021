package app.personalPage.subPart.newPost.event;


import app.authentication.event.ManageBiographyFormEvent;

public class PostFormEvent extends ManageBiographyFormEvent {

    private String tweetText;

    public PostFormEvent(Object source) {
        super(source);
    }

    public void setTweetText(String tweetText) {
        this.tweetText = tweetText;
    }

    public String getTweetText() {
        return tweetText;
    }
}