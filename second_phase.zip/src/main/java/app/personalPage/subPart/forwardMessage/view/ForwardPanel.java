package app.personalPage.subPart.forwardMessage.view;

import app.personalPage.subPart.forwardMessage.listener.ForwardPanelListener;
import resources.Colors;
import resources.Images;
import view.listeners.StringListener;
import view.usersView.UserPanelSelectable;
import view.usersView.UsersViewPanel;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class ForwardPanel extends JPanel {

    private String messageType;
    private int messageId;
    private final JButton backButton;
    private final UsersViewPanel<UserPanelSelectable> usersViewPanel;
    private final JButton sendButton;
    private StringListener stringListener;
    private final ForwardPanelListener listener =
            new ForwardPanelListener();

    public ForwardPanel() {
        usersViewPanel = new UsersViewPanel<>(700,UserPanelSelectable::new);
        JScrollPane downPa = new JScrollPane(usersViewPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        downPa.setBounds(0,50,700,380);
        //
        backButton = new JButton(Images.CLOSE_ICON);
        sendButton = new JButton(Images.SEND_ICON);
        //
        sendButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        sendButton.setBounds(350,440,54,45);
        sendButton.setEnabled(false);
        sendButton.addActionListener(e->{
            try {
                sendButtonAction(usersViewPanel.selectedPanelIds());
                listenMe("ap is ....");
            }
            catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        backButton.setBounds(10, 5, 54, 45);
        backButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        backButton.setFocusable(false);
        backButton.addActionListener(e -> {
            try {
                resetPanel();
                listenMe("back");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        usersViewPanel.setStringListener(text -> {
            if(usersViewPanel.isAnyPanelChosen()){
                sendButton.setEnabled(true);
            }
        });
        //
        this.setLayout(null);
        this.setBounds(0,200,700,500);
        this.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        this.add(backButton);
        this.add(sendButton);
        this.add(downPa);
    }

    public void resetPanel(){
        usersViewPanel.resetSelectedPanels();
        usersViewPanel.resetPanel();
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name) throws IOException {
        stringListener.stringEventOccurred(name);
    }

    public void sendButtonAction(List<Integer> ids) throws IOException {
        listener.sendMessage(ids, messageId, messageType);
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public void setInfo(){
        try {
            usersViewPanel.setUserPanels(listener.loadFollowings());
            usersViewPanel.setSize();
            usersViewPanel.addPanels();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }
}
