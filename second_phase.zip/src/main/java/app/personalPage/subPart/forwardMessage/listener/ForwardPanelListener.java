package app.personalPage.subPart.forwardMessage.listener;

import app.personalPage.subPart.forwardMessage.controller.ForwardController;

import java.io.IOException;
import java.util.List;

public class ForwardPanelListener {

    private final ForwardController controller = new ForwardController();

    public void sendMessage(List<Integer> ids, int messageId, String type)
            throws IOException {
            controller.sendMessage(ids, messageId, type);
    }

    public List<String[]> loadFollowings(){
        try {
            return controller.loadFollowings();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
