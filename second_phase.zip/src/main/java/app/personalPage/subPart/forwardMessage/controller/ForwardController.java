package app.personalPage.subPart.forwardMessage.controller;

import Models.Chat;
import Models.messages.Message;
import Models.messages.Tweet;
import Models.auth.User;
import app.chat.controller.ContactPanelController;
import controller.MainController;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class ForwardController extends MainController {

    private final ContactPanelController chatController =
            new ContactPanelController();

    public void sendMessage(List<Integer> ids, int messageId, String type)
            throws IOException {
        User current = context.getUsers().get(currentUserId);
        Message.setId_counter(context.getMessages().getIDCounter());
        Message forwardMessage = context.getMessages().get(messageId,type);
        User user1 = context.getUsers().get(forwardMessage.getUserId());
        String text = "forwarded from: " + user1.getAccount().getUsername()+"\n" +
                forwardMessage.getText();
        Tweet message = new Tweet(
                "forward", text, user1,
                LocalDateTime.now(), "hi");
        message.setImageId(messageId);
        context.getMessages().setIDCounter(Message.getId_counter());
        message.setForwarderId(currentUserId);
        context.getMessages().set(message,type);
        for (Integer id: ids) {
            Chat chat = context.getChats().get(id);
            if(type.equals("tweet")) {
                chat.getForwardTweets().add(message.getId());
            }
            else{
                chat.getForwardComments().add(message.getId());
            }
            int a = 0;
            for (int i = 0; i < current.getMyChatIds().size(); i++) {
                if(current.getMyChatIds().get(i) == chat.getId()){
                    a = i;
                    break;
                }
            }
            current.getMyChatMessagesIds().get(a).add(message.getId());
            for (Integer userId:chat.getUsersIds()) {
                if(userId != currentUserId){
                    User user = context.getUsers().get(userId);
                    int b = 0;
                    boolean f = true;
                    for (int i = 0; i < user.getMyUnreadChatIds().size(); i++) {
                        if(user.getMyUnreadChatIds().get(i) == chat.getId()){
                            b = i;
                            f = false;
                            break;
                        }
                    }
                    if(!f) {
                        int c = user.getMyUnreadChatMessagesNumbers().get(b);
                        user.getMyUnreadChatMessagesNumbers().set(b, c + 1);
                    }
                    else{
                        user.getMyUnreadChatIds().add(chat.getId());
                        user.getMyUnreadChatMessagesNumbers().add(1);
                    }
                    context.getUsers().set(user);
                }
            }
            context.getChats().set(chat);
        }
        context.getUsers().set(current);
    }
    public List<String[]> loadFollowings() throws IOException {
        return chatController.loadChats();
    }
}