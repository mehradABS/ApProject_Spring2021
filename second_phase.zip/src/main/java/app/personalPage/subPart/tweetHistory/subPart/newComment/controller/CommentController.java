package app.personalPage.subPart.tweetHistory.subPart.newComment.controller;

import Models.auth.User;
import Models.messages.Comment;
import Models.messages.Message;
import Models.messages.Tweet;
import app.personalPage.subPart.tweetHistory.subPart.newComment.event.NewCommentFormEvent;
import controller.MainController;
import controller.log.Log;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class CommentController extends MainController {

    public void newComment(NewCommentFormEvent newCommentFormEvent) throws IOException {
        boolean isTweet = false;
        List<Tweet> tweets = context.getTweets().getAll("tweet");
        for (Tweet value : tweets) {
            if (value.getId() == newCommentFormEvent.getTweetId()) {
                isTweet = true;
                break;
            }
        }
        if (isTweet) {
            Tweet tweet = context.getTweets().get(newCommentFormEvent.getTweetId(),
                    "tweet");
            User user = context.getUsers().get(currentUserId);
            Message.setId_counter(context.getMessages().getIDCounter());
            //
            Comment comment = new Comment("Comment",
                    newCommentFormEvent.getText(),
                    user,
                    LocalDateTime.now());
            tweet.getCommentsId().add(comment.getId());
            context.getMessages().setIDCounter(Message.getId_counter());
            context.getTweets().set(tweet, "tweet");
            context.getComments().set(comment, "comment");
            Log log = new Log("wrote a new comment for a tweet", LocalDateTime.now(),
                    2, currentUserId);
            Log.log(log);
        } else {
            Comment comment1 = context.getComments().get(newCommentFormEvent.getTweetId(),
                    "comment");
            User user = context.getUsers().get(currentUserId);
            Message.setId_counter(context.getMessages().getIDCounter());
            //
            Comment comment = new Comment("Comment",
                    newCommentFormEvent.getText(),
                    user,
                    LocalDateTime.now());
            comment1.getCommentsId().add(comment.getId());
            context.getMessages().setIDCounter(Message.getId_counter());
            context.getComments().set(comment1, "comment");
            context.getComments().set(comment, "comment");
            Log log = new Log("wrote a new comment for a comment", LocalDateTime.now(),
                    2, currentUserId);
            Log.log(log);
        }
    }
}