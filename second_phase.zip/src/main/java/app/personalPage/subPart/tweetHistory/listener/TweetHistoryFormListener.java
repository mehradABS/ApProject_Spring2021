package app.personalPage.subPart.tweetHistory.listener;

import app.personalPage.subPart.tweetHistory.event.TweetHistoryFormEvent;
import exceptions.InvalidEntrance;

import java.io.IOException;
import java.util.LinkedList;

public interface TweetHistoryFormListener {

    LinkedList<String[]> loadTweets() throws IOException;

    int[] like(TweetHistoryFormEvent tweetHistoryFormEvent,
                String type) throws IOException;

    int[] dislike(TweetHistoryFormEvent tweetHistoryFormEvent
    , String type) throws IOException;

    int comment(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException;

    void block(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException;

    void unblock(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException;

    void report(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException;

    void mute(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException;

    void retweet(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException, InvalidEntrance;
}
