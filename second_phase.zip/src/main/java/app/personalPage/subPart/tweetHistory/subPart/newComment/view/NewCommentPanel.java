package app.personalPage.subPart.tweetHistory.subPart.newComment.view;

import app.personalPage.subPart.newPost.view.NewPostPanel;
import app.personalPage.subPart.tweetHistory.subPart.newComment.event.NewCommentFormEvent;
import app.personalPage.subPart.tweetHistory.subPart.newComment.listener.NewCommentListener;
import resources.Colors;
import resources.Images;
import resources.Texts;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class NewCommentPanel extends NewPostPanel {

    private final NewCommentFormEvent newCommentFormEvent;
    private final NewCommentListener newCommentListener;

    private int tweetId;
    private String messageType;

    public NewCommentPanel() {
        super();
        //
        newCommentFormEvent = new NewCommentFormEvent(this);
        newCommentListener = new NewCommentListener();
        //
        defaultText.setText(Texts.COMMENT_J_TEXTAREA_DEFAULT_TEXT);
        //
        JButton backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(650,10,45,45);
        backButton.setFocusable(false);
        backButton.setBackground(Color.decode(Colors.SUB_PANEL));
        backButton.addActionListener(e -> {
            try {
                resetPanel();
                listenMe("back");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //

        this.setBounds(0,100,700,500);
        this.setBackground(Color.decode(Colors.SUB_PANEL));
        this.add(backButton);
    }

    public void setTweetId(int tweetId) {
        this.tweetId = tweetId;
    }

    public int getTweetId() {
        return tweetId;
    }

    public void PostButtonAction() throws IOException {
        newCommentFormEvent.setText(tweetText.getText());
        newCommentFormEvent.setTweetId(tweetId);
        newCommentListener.newComment(newCommentFormEvent);
        resetPanel();
    }

   public void setDefaultText(String text){
        defaultText.setText(text);
   }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }
}
