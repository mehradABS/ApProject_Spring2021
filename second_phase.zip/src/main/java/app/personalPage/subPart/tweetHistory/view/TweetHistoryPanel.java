package app.personalPage.subPart.tweetHistory.view;

import app.personalPage.subPart.tweetHistory.event.TweetHistoryFormEvent;
import app.personalPage.subPart.tweetHistory.listener.TweetHistoryListener;
import app.personalPage.subPart.tweetHistory.subPart.newComment.view.NewCommentPanel;
import exceptions.InvalidEntrance;
import resources.Colors;
import resources.Fonts;
import resources.Texts;
import view.listeners.StringListener;
import view.postView.tweetHistory.PostView;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

public class TweetHistoryPanel<T extends PostView> extends JPanel {

    protected int height = 0;
    protected final Supplier<? extends T> ctor;
    protected final NewCommentPanel newCommentPanel;
    protected List<String[]> tweetsInfo;
    protected final JLabel noTweetLabel;
    protected final TweetHistoryFormEvent tweetHistoryFormEvent;
    protected final TweetHistoryListener tweetHistoryListener;
    protected final List<PostView> postViews;
    protected final List<StringListener> stringListeners;

    public TweetHistoryPanel(Supplier<? extends T> ctor) {
        this.ctor  = Objects.requireNonNull(ctor);
        //
        stringListeners = new LinkedList<>();
        //
        newCommentPanel = new NewCommentPanel();
        //
        postViews = new LinkedList<>();
        //
        tweetHistoryListener = new TweetHistoryListener();
        tweetHistoryFormEvent = new TweetHistoryFormEvent(this);
        //
        noTweetLabel = new JLabel(Texts.NO_TWEET);
        noTweetLabel.setBounds(180,130,400,200);
        noTweetLabel.setForeground(Color.decode(Colors.WELCOME_LABEL_COLOR));
        noTweetLabel.setFont(Fonts.NO_TWEET_LABEL_FONT);
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.PERSONAL_PAGE_DOWN_PANEL));
    }


    public NewCommentPanel getNewCommentPanel() {
        return newCommentPanel;
    }

    public void listenMe(String name) throws IOException {
             for (StringListener stringListener: stringListeners){
                 stringListener.stringEventOccurred(name);
             }
    }

    public void addStringListeners(StringListener stringListener){
        stringListeners.add(stringListener);
    }

    public void loadTweets() throws IOException {
        this.tweetsInfo = tweetHistoryListener.loadTweets();
    }

    public void setInfo() throws IOException {
        postViews.removeAll(postViews);
        height = 0;
        this.loadTweets();
        this.makeTweetsPanels("tweet");
        this.addPanels();
    }

    public void makeTweetsPanels(String type) throws IOException {
        for (int i = tweetsInfo.size()-1; i >=0 ; i--) {
            postViews.add(makePostView(tweetsInfo.get(i), type));
        }
        this.setPreferredSize(new Dimension(700,height));
    }

    public T makePostView(String[] info, String type) throws IOException {
        T postView = ctor.get();
        ImageIcon icon = null;
        if(!info[1].equals("null")){
            icon = new ImageIcon(ImageIO.read(new File(info[1])));
        }
        postView.setInfo(info[0],icon,
                info[2],new ImageIcon
                        (ImageIO.read(new File(info[3]))),
                Integer.parseInt(info[4]),
                Integer.parseInt(info[5]),
                Integer.parseInt(info[8]));
        postView.setTweetId(Integer.parseInt(info[6]));
        postView.setBlockItem(Boolean.parseBoolean(info[9]));
        postView.setMoreIcon(!Boolean.parseBoolean(info[10]));
        postView.setRetweetText(info[11]);
        addStringListenerToPosts(postView, type);
        postView.setSizes(0,height);
        postView.addComponent(Boolean.parseBoolean(info[7]));
        height += postView.getHeight() + 50;
        return postView;
    }

    public void addPanels(){
        removeAll();
        for(PostView postView: postViews){
            this.add(postView);
        }
        if(postViews.size() == 0){
            this.add(noTweetLabel);
        }
        repaint();
        revalidate();
    }

    public void loadCommentsNumberOfPost(int tweetId) throws IOException {
        for (PostView postView : postViews) {
            if (postView.getTweetId() == tweetId) {
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                int a = tweetHistoryListener.comment(tweetHistoryFormEvent,
                        "tweet");
                postView.setReplyText(String.valueOf(a));
                break;
            }
        }
    }

    public void addStringListenerToPosts(PostView postView, String type){
        postView.addStringListener(text -> {
            if(text.startsWith("like")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                int[] a = tweetHistoryListener.like(tweetHistoryFormEvent
                ,type);
                postView.setLikeText(String.valueOf(a[0]), String.valueOf(a[1]));
            }
            else if(text.startsWith("dislike")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                int[] a = tweetHistoryListener.dislike(tweetHistoryFormEvent,
                        type);
                postView.setDisLikeText(String.valueOf(a[0]), String.valueOf(a[1]));
            }
            else if(text.startsWith("share")){
                if(type.equals("tweet")) {
                    listenMe(text+"+");
                }
                else{
                    listenMe(text+"-");
                }
            }
            else if(text.startsWith("reply")){
                listenMe(String.valueOf(postView.getTweetId()));
                if (postView.getMoreIconVisibility()) {
                    newCommentPanel.setDefaultText(
                            Texts.COMMENT_J_TEXTAREA_DEFAULT_TEXT_2);
                }
            }

            else if(text.startsWith("block")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                tweetHistoryListener.block(tweetHistoryFormEvent, "tweet");
                for(PostView postView1: postViews){
                    postView1.setBlockItem(true);
                }
            }
            else if(text.startsWith("unblock")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                tweetHistoryListener.unblock(tweetHistoryFormEvent, "tweet");
                for(PostView postView1: postViews){
                    postView1.setBlockItem(false);
                }
            }

            else if(text.startsWith("report")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                tweetHistoryListener.report(tweetHistoryFormEvent, "tweet");
            }
            else if(text.startsWith("mute")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                tweetHistoryListener.mute(tweetHistoryFormEvent, "tweet");
                listenMe("mute");
            }
            else if(text.startsWith("retweet")){
                tweetHistoryFormEvent.setTweetId(postView.getTweetId());
                try {
                    tweetHistoryListener.retweet(tweetHistoryFormEvent, "tweet");
                    postView.setRetweetText(String.valueOf(postView.getRetweetText()+1));
                } catch (InvalidEntrance ignored) {

                }
            }
            else{
                listenMe("commentPage"+text);
            }
        });
    }

}