package app.personalPage.subPart.tweetHistory.subPart.newComment.listener;

import app.personalPage.subPart.tweetHistory.subPart.newComment.event.NewCommentFormEvent;

import java.io.IOException;

public interface NewCommentFormListener {
    void newComment(NewCommentFormEvent newCommentFormEvent) throws IOException;
}
