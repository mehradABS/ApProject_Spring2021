package app.personalPage.subPart.tweetHistory.subPart.newComment.event;

import java.util.EventObject;

public class NewCommentFormEvent extends EventObject {

    private int tweetId;
    private String text;

    public NewCommentFormEvent(Object source) {
        super(source);
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public int getTweetId() {
        return tweetId;
    }

    public void setTweetId(int tweetId) {
        this.tweetId = tweetId;
    }
}
