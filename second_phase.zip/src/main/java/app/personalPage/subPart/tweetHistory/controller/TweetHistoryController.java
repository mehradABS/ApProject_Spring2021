package app.personalPage.subPart.tweetHistory.controller;

import Models.*;
import Models.auth.User;
import Models.messages.Comment;
import Models.messages.Message;
import Models.messages.Tweet;
import app.personalPage.subPart.tweetHistory.event.TweetHistoryFormEvent;
import controller.MainController;
import controller.log.Log;
import exceptions.InvalidEntrance;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.LinkedList;

public class TweetHistoryController extends MainController {

    public LinkedList<String[]> loadTweets(int userId) throws IOException {
        LinkedList<String[]> allInfo = new LinkedList<>();
        User user = context.getUsers().get(userId);
        for(Integer tweetId: user.getTweetsID()){
            Tweet tweet = context.getTweets().get(tweetId, "tweet");
            User user1 = context.getUsers().get(tweet.getUserId());
            if(tweet.getUserId() != user.getId()) {
                allInfo.add(loadTweetInfo(tweet, user1, user.
                        getAccount().getUsername() + " retweeted: "));
            }
            else {
                allInfo.add(loadTweetInfo(tweet, user1, ""));
            }
        }
        return allInfo;
    }

    public <T extends Message>
    String[] loadTweetInfo(T tweet, User user, String retweetUsername) throws IOException {
        String [] info = new String[12];
        info[0] =retweetUsername + tweet.getText();
        File file = new File("src\\Save\\images\\tweets\\"+tweet.getId()+".png");
        if(file.exists()){
            info[1] = "src\\Save\\images\\tweets\\"+tweet.getId()+".png";
        }
        else {
            info[1] = "null";
        }
        String time = tweet.getLocalDateTime().getMonth().toString()
                +", "+tweet.getLocalDateTime().getDayOfMonth()+" -- "+
                tweet.getLocalDateTime().getHour()
                +": "+tweet.getLocalDateTime().getMinute();
        info[2] = "<html>"+user.getAccount().getUsername()+"<br>"+time+"</html>";
        File file1 = new File("src\\Save\\images\\"+
                (user.getId())
                +"\\profile\\profile60.png");
        if(file1.exists()){
            info[3] = "src\\Save\\images\\"+
                    (user.getId())
                    +"\\profile\\profile60.png";
        }
        else {
            info[3] = "src\\Save\\images\\defaultProfileImage\\" +
                    "defaultProfile60.png";
        }
        info[4] = String.valueOf(tweet.getLike().size());
        info[5] = String.valueOf(tweet.getDislike().size());
        info[6] = String.valueOf(tweet.getId());
        boolean like = tweet.getLike().contains(currentUserId);
        info[7] = String.valueOf(like);
        info[8] = String.valueOf(tweet.getCommentsId().size());
        info[9] = String.valueOf(context.getUsers().get(currentUserId).getBlackUsername()
        .contains(user.getId()));
        info[10] = String.valueOf(currentUserId == tweet.getUserId());
        if(tweet.getRetweet_userId() != null) {
            info[11] = String.valueOf(tweet.getRetweet_userId().size() - 1);
        }
        else{
            info[11] = "0";
        }
        return info;
    }

    public int[] like(int id, String type) throws IOException {
        if (type.equals("tweet")) {
            Tweet tweet = context.getTweets().get(id, "tweet");
            User user = context.getUsers().get(currentUserId);
            tweet.getLike().add(user.getId());
            user.getFavouriteID().add(tweet.getId());
            tweet.getDislike().remove(user.getId());
            context.getUsers().set(user);
            context.getTweets().set(tweet, "tweet");
            Log log = new Log("liked his/her tweet", LocalDateTime.now(),
                    2, currentUserId);
            Log.log(log);
            int[] a = new int[2];
            a[0] = tweet.getLike().size();
            a[1] = tweet.getDislike().size();
            return a;
        }
        else{
            Comment comment = context.getComments().get(id, "comment");
            comment.getLike().add(currentUserId);
            comment.getDislike().remove(currentUserId);
            context.getComments().set(comment, "comment");
            Log log=new Log("liked a tweet/comment",LocalDateTime.now(),
                    2,currentUserId);
            Log.log(log);
            int[] a = new int[2];
            a[0] = comment.getLike().size();
            a[1] = comment.getDislike().size();
            return a;
        }
    }
    public int[] dislike(int id , String type) throws IOException {
        if(type.equals("tweet")) {
            Tweet tweet = context.getTweets().get(id, "tweet");
            User user = context.getUsers().get(currentUserId);
            tweet.getLike().remove(user.getId());
            int a = tweet.getId();
            user.getFavouriteID().remove(a);
            tweet.getDislike().add(user.getId());
            context.getUsers().set(user);
            context.getTweets().set(tweet, "tweet");
            Log log = new Log("disliked his/her tweet", LocalDateTime.now(),
                    2, currentUserId);
            Log.log(log);
            int[] b = new int[2];
            b[0] = tweet.getLike().size();
            b[1] = tweet.getDislike().size();
            return b;
        }
        else{
            Comment comment = context.getComments().get(id,"comment");
            comment.getLike().remove(currentUserId);
            comment.getDislike().add(currentUserId);
            context.getComments().set(comment, "comment");
            Log log=new Log("disliked a tweet/comment",LocalDateTime.now(),
                    2,currentUserId);
            Log.log(log);
            int[] b = new int[2];
            b[0] = comment.getLike().size();
            b[1] = comment.getDislike().size();
            return b;
        }
    }

    public int commentsNumber(int tweetId, String type) throws IOException {
          if(type.equals("tweet")) {
              Tweet tweet = context.getTweets().get(tweetId, "tweet");
              return tweet.getCommentsId().size();
          }
          else {
              Comment tweet = context.getComments().get(tweetId, "tweet");
              return tweet.getCommentsId().size();
          }
    }

    public void block(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        User user = context.getUsers().get(currentUserId);
        if(type.equals("comment")){
            Comment comment = context.getComments().get
                    (tweetHistoryFormEvent.getTweetId(), "comment");
            blockHandling(comment, user);
        }
        else if(type.equals("tweet")){
            Tweet comment = context.getTweets().get
                    (tweetHistoryFormEvent.getTweetId(), "tweet");
            blockHandling(comment, user);

        }
    }

    public void blockHandling(Message comment, User user)
            throws IOException {
        user.getBlackUsername().add(comment.getUserId());
        context.getUsers().set(user);
        User user1 = context.getUsers().get(comment.getUserId());
        user1.getSystemMessages().add(
                user.getAccount()
                        .getUsername() + " Blocked you   " +
                        LocalDateTime.now());
        context.getUsers().set(user1);
        Log log=new Log("blocked someone",LocalDateTime.now(),
                2,currentUserId);
        Log.log(log);
    }

    public void unblockHandling(Message comment, User user) throws IOException {
        user.getBlackUsername().remove(comment.getUserId());
        context.getUsers().set(user);
        User user1 = context.getUsers().get(comment.getUserId());
        user1.getSystemMessages().add(
                user.getAccount()
                        .getUsername() + " unBlocked you   " +
                        LocalDateTime.now());
        Log log = new Log("unblocked someone", LocalDateTime.now(), 2,
                currentUserId);
        Log.log(log);
    }

    public void unblock(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        User user = context.getUsers().get(currentUserId);
        if(type.equals("comment")){
            Comment comment = context.getComments().get
                    (tweetHistoryFormEvent.getTweetId(), "comment");
            unblockHandling(comment, user);
        }
        else if(type.equals("tweet")){
            Tweet comment = context.getTweets().get
                    (tweetHistoryFormEvent.getTweetId(), "tweet");
            unblockHandling(comment, user);
        }
    }

    public void reportHandling(Message message, User user)
            throws IOException {
        User user1 = context.getUsers().get(message.getUserId());
        Report rp = context.getProgram().getReports();
        rp.getFirstId().add(user.getId());
        rp.getLastId().add(user1.getId());
        context.getProgram().setReports(rp);
        Log log=new Log("report someone",LocalDateTime.now(),2,
                currentUserId);
        Log.log(log);
    }

    public void report(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        User user = context.getUsers().get(currentUserId);
        if(type.equals("comment")){
            Comment comment = context.getComments().get
                    (tweetHistoryFormEvent.getTweetId(), "comment");
            reportHandling(comment, user);
        }
        else if(type.equals("tweet")){
            Tweet comment = context.getTweets().get
                    (tweetHistoryFormEvent.getTweetId(), "tweet");
            reportHandling(comment, user);
        }
    }

   public void muteHandling(Message message, User user)
           throws IOException {
        user.getSilentUsername().add(message.getUserId());
       context.getUsers().set(user);
       Log log = new Log("muted someone",LocalDateTime.now(),2,
               currentUserId);
       Log.log(log);
    }

    public void mute(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        User user = context.getUsers().get(currentUserId);
        if(type.equals("comment")){
            Comment comment = context.getComments().get
                    (tweetHistoryFormEvent.getTweetId(), "comment");
            muteHandling(comment, user);
        }
        else if(type.equals("tweet")){
            Tweet comment = context.getTweets().get
                    (tweetHistoryFormEvent.getTweetId(), "tweet");
            muteHandling(comment, user);
        }
    }

    public void retweet(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException, InvalidEntrance {
        if(type.equals("tweet")){
            Tweet tweet = context.getTweets().get(tweetHistoryFormEvent.getTweetId(),
                    "tweet");
            if(!tweet.getRetweet_userId().contains(currentUserId)){
                User current = context.getUsers().get(currentUserId);
                Log log = new Log("retweeted a tweet",LocalDateTime.now(),2,
                        currentUserId);
                Log.log(log);
                current.getTweetsID().add(tweet.getId());
                tweet.getRetweet_userId().add(currentUserId);
                context.getUsers().set(current);
                context.getTweets().set(tweet, type);
            }
            else{
                throw new InvalidEntrance("ss");
            }
        }
        else{
           Comment tweet = context.getComments().get(tweetHistoryFormEvent.getTweetId(),
                    "comment");
            if(!tweet.getRetweet_userId().contains(currentUserId)){
                User current = context.getUsers().get(currentUserId);
                Log log = new Log("retweeted a tweet",LocalDateTime.now(),2,
                        currentUserId);
                Log.log(log);
                current.getTweetsID().add(tweet.getId());
                tweet.getRetweet_userId().add(currentUserId);
                context.getUsers().set(current);
                context.getComments().set(tweet, "tweet");
                context.getMessages().set(tweet,"comment");
            }
            else{
                throw new InvalidEntrance("ss");
            }
        }
    }
}