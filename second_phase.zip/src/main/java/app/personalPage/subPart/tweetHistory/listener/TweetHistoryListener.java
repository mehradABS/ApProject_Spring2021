package app.personalPage.subPart.tweetHistory.listener;

import app.personalPage.subPart.tweetHistory.controller.TweetHistoryController;
import app.personalPage.subPart.tweetHistory.event.TweetHistoryFormEvent;
import controller.MainController;
import exceptions.InvalidEntrance;

import java.io.IOException;
import java.util.LinkedList;

public class TweetHistoryListener implements TweetHistoryFormListener{

    private final TweetHistoryController tweetHistoryController;

    public TweetHistoryListener() {
        tweetHistoryController = new TweetHistoryController();
    }

    @Override
    public LinkedList<String[]> loadTweets() throws IOException {
        return tweetHistoryController.loadTweets(MainController.getCurrentUserId());
    }

    @Override
    public int[] like(TweetHistoryFormEvent tweetHistoryFormEvent
    , String type) throws IOException {
        return tweetHistoryController.like(tweetHistoryFormEvent.getTweetId(),
                type);
    }

    @Override
    public int[] dislike(TweetHistoryFormEvent tweetHistoryFormEvent
    , String type) throws IOException {
        return tweetHistoryController.dislike(tweetHistoryFormEvent.getTweetId()
        , type);
    }

    @Override
    public int comment(TweetHistoryFormEvent tweetHistoryFormEvent
    , String type) throws IOException {
        return tweetHistoryController.commentsNumber(tweetHistoryFormEvent
        .getTweetId(), type);
    }

    @Override
    public void block(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
         tweetHistoryController.block(tweetHistoryFormEvent, type);
    }

    @Override
    public void unblock(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        tweetHistoryController.unblock(tweetHistoryFormEvent, type);
    }

    @Override
    public void report(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException {
        tweetHistoryController.report(tweetHistoryFormEvent, type);
    }

    @Override
    public void mute(TweetHistoryFormEvent tweetHistoryFormEvent, String type) throws IOException {
        tweetHistoryController.mute(tweetHistoryFormEvent, type);
    }

    @Override
    public void retweet(TweetHistoryFormEvent tweetHistoryFormEvent, String type)
            throws IOException, InvalidEntrance {
        tweetHistoryController.retweet(tweetHistoryFormEvent, type);
    }
}
