package app.personalPage.subPart.tweetHistory.event;

import java.util.EventObject;

public class TweetHistoryFormEvent extends EventObject {

    private int tweetId;

    public TweetHistoryFormEvent(Object source) {
        super(source);
    }

    public void setTweetId(int tweetId) {
        this.tweetId = tweetId;
    }

    public int getTweetId() {
        return tweetId;
    }
}
