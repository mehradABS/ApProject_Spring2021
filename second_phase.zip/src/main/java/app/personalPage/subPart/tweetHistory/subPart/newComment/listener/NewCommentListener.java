package app.personalPage.subPart.tweetHistory.subPart.newComment.listener;


import app.personalPage.subPart.tweetHistory.subPart.newComment.controller.CommentController;
import app.personalPage.subPart.tweetHistory.subPart.newComment.event.NewCommentFormEvent;

import java.io.IOException;

public class NewCommentListener implements NewCommentFormListener{

    private final CommentController commentController;

    public NewCommentListener() {
        this.commentController = new CommentController();
    }

    @Override
    public void newComment(NewCommentFormEvent newCommentFormEvent) throws IOException {
        commentController.newComment(newCommentFormEvent);
    }
}
