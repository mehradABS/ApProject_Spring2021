package app.List.view;

import app.List.event.ListFormEvent;
import app.List.listener.ListPanelListener;
import app.chat.view.AddPhotoPanel;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;
import view.postView.message.MessageSenderPanel;
import view.usersView.UserPanel;
import view.usersView.UserPanelSelectable;
import view.usersView.UsersViewPanel;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class ListMainPanel extends JPanel {

    private String currentListName;
    private String state;
    private final JButton followersButton;
    private final JButton followingsButton;
    private final JButton blackListButton;
    private final JButton myListButton;
    private final JButton addListButton;
    private final JButton backButton;
    private UsersViewPanel<UserPanel> usersViewPanel;
    private final UsersViewPanel<UserPanel> listsViewPanel;
    private final UsersViewPanel<UserPanelSelectable> addUserViewPanel;
    private StringListener stringListener;
    private final ListPanelListener listPanelListener;
    private final JLabel noFriendLabel;
    private final JScrollPane downPanel;
    private final JTextArea textArea;
    private final JLabel defaultText;
    private final MessageSenderPanel messageSenderPanel;
    private final AddPhotoPanel addPhotoPanel;

    public ListMainPanel() {
        addPhotoPanel = new AddPhotoPanel();
        //
        messageSenderPanel = new MessageSenderPanel(615,800);
        //
        JButton add = new JButton(Texts.ADD);
        JButton remove = new JButton(Texts.REMOVE);
        add.setBounds(300,10,160,60);
        add.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        add.setFont(Fonts.BUTTONS_FONT);
        remove.setBounds(300,10,160,60);
        remove.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        remove.setFont(Fonts.BUTTONS_FONT);
        //
        JButton addButton = new JButton(Images.ADD_PERSON);
        addButton.setBounds(200,10,54,45);
        addButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        addListButton = new JButton(Images.ADD_LIST);
        JButton removeListButton = new JButton(Images.REMOVE_LIST);
        JButton removeButton = new JButton(Images.REMOVE_PERSON);
        removeButton.setBounds(500,10,54,45);
        removeButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(5,10,54,45);
        backButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        textArea = new JTextArea();
        textArea.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        textArea.setBounds(150,10,300,46);
        textArea.setFont(Fonts.TWEET_FONT);
        addListButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        addListButton.setBounds(80, 10, 54, 45);
        removeListButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        removeListButton.setBounds(500, 10, 54, 45);
        defaultText = new JLabel(Texts.LIST_NAME);
        defaultText.setFont(Fonts.TWEET_FONT);
        defaultText.setBounds(0, -7, 200, 40);
        textArea.add(defaultText);
        textArea.getDocument().putProperty("name", "TextArea");
        addListButton.setEnabled(false);
        addListButton.setFocusable(false);
        textArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                defaultText.setVisible(false);
                addListButton.setEnabled(true);
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                if (textArea.getText().isEmpty()) {
                    defaultText.setVisible(true);
                    addListButton.setEnabled(false);
                }
            }
            @Override
            public void changedUpdate(DocumentEvent e) {}
        });
        //
        listsViewPanel = new UsersViewPanel<>(800,UserPanel::new);
        listsViewPanel.setStringListener(text -> {
            remove(addListButton);
            remove(textArea);
            remove(removeListButton);
            add(addButton);
            add(messageSenderPanel);
            add(removeButton);
            state = "usersList";
            currentListName = text;
            usersViewPanel.resetSelectedPanels();
            usersViewPanel.resetPanel();
            listsViewPanel.resetSelectedPanels();
            setUsersOfLists(text);
            repaint();
            revalidate();
        });
        addUserViewPanel = new UsersViewPanel<>(800,UserPanelSelectable::new);
        //
        noFriendLabel = new JLabel(Texts.NO_PEOPLE);
        noFriendLabel.setBounds(300,140,600,200);
        noFriendLabel.setForeground(Color.decode(Colors.WELCOME_LABEL_COLOR));
        noFriendLabel.setFont(Fonts.WELCOME_LABEL_FONT);
        //
        ListFormEvent listFormEvent = new ListFormEvent(this);
        listPanelListener = new ListPanelListener();
        //
        followersButton = new JButton(Texts.FOLLOWERS);
        followersButton.setBounds(30,10,150,40);
        followersButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        followersButton.setFont(Fonts.BUTTONS_FONT);
        followersButton.setFocusable(false);
        followersButton.addActionListener(e->{
            try {
                setFollowers();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        followingsButton = new JButton(Texts.FOLLOWINGS);
        followingsButton.setBounds(220,10,150,40);
        followingsButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        followingsButton.setFont(Fonts.BUTTONS_FONT);
        followingsButton.setFocusable(false);
        followingsButton.addActionListener(e->{
            try {
                setFollowings();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        blackListButton = new JButton(Texts.BLACK_LIST);
        blackListButton.setBounds(410,10,150,40);
        blackListButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        blackListButton.setFont(Fonts.BUTTONS_FONT);
        blackListButton.setFocusable(false);
        blackListButton.addActionListener(e->{
            try {
                setBlackUsers();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        myListButton = new JButton(Texts.MY_LIST);
        myListButton.setBounds(600,10,150,40);
        myListButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        myListButton.setFont(Fonts.BUTTONS_FONT);
        myListButton.setFocusable(false);
        myListButton.addActionListener(e->{
            try {
                state = "list";
                remove(followersButton);
                remove(followingsButton);
                remove(myListButton);
                remove(blackListButton);
                add(backButton);
                add(textArea);
                add(addListButton);
                add(removeListButton);
                setLists();
                repaint();
                revalidate();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        //
        usersViewPanel = new UsersViewPanel<>(800,UserPanel::new);
        usersViewPanel.setStringListener(text -> {
            usersViewPanel.resetSelectedPanels();
            listenMe(text);
        });
        downPanel = new JScrollPane(usersViewPanel,
                 JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        downPanel.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        downPanel.setBounds(0,120,800,490);
        //
        backButton.addActionListener(e->{
            switch (state) {
                case "list":
                    add(followersButton);
                    add(followingsButton);
                    add(myListButton);
                    add(blackListButton);
                    remove(backButton);
                    remove(textArea);
                    remove(addListButton);
                    remove(removeListButton);
                    addUserViewPanel.resetSelectedPanels();
                    addUserViewPanel.resetPanel();
                    usersViewPanel.resetPanel();
                    usersViewPanel.resetSelectedPanels();
                    listsViewPanel.resetSelectedPanels();
                    downPanel.setViewportView(usersViewPanel);
                    break;
                case "removeList":
                    try {
                        remove(remove);
                        state = "list";
                        remove(followersButton);
                        remove(followingsButton);
                        remove(myListButton);
                        remove(blackListButton);
                        add(backButton);
                        add(textArea);
                        add(addListButton);
                        add(removeListButton);
                        addUserViewPanel.resetSelectedPanels();
                        addUserViewPanel.resetPanel();
                        usersViewPanel.resetSelectedPanels();
                        listsViewPanel.resetSelectedPanels();
                        setLists();
                        repaint();
                        revalidate();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    break;
                case "removeUser":
                case "addUser":
                    remove(remove);
                    remove(add);
                    remove(addListButton);
                    remove(textArea);
                    remove(removeListButton);
                    add(addButton);
                    add(messageSenderPanel);
                    add(removeButton);
                    state = "usersList";
                    addUserViewPanel.resetSelectedPanels();
                    addUserViewPanel.resetPanel();
                    usersViewPanel.resetSelectedPanels();
                    listsViewPanel.resetSelectedPanels();
                    try {
                        setUsersOfLists(currentListName);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    repaint();
                    revalidate();
                    break;
                default:
                    state = "list";
                    remove(removeButton);
                    remove(addButton);
                    remove(messageSenderPanel);
                    messageSenderPanel.resetPanel();
                    remove(followersButton);
                    remove(followingsButton);
                    remove(myListButton);
                    remove(blackListButton);
                    add(backButton);
                    add(textArea);
                    add(addListButton);
                    addUserViewPanel.resetSelectedPanels();
                    addUserViewPanel.resetPanel();
                    usersViewPanel.resetSelectedPanels();
                    listsViewPanel.resetSelectedPanels();
                    try {
                        setLists();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    break;
            }
            repaint();
            revalidate();
        });
        //
        addListButton.addActionListener(e->{
            usersViewPanel.resetPanel();
            String name = textArea.getText();
            textArea.setText("");
            textArea.add(defaultText);
            addListButton.setEnabled(false);
            addList(name);
            try {
                setLists();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        removeListButton.addActionListener(e -> {
            state = "removeList";
            remove(addListButton);
            remove(textArea);
            remove(removeListButton);
            add(remove);
            remove.setEnabled(false);
            try {
                setListsForRemove();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            repaint();
            revalidate();
        });
        //
        removeButton.addActionListener(e -> {
            state = "removeUser";
            remove(removeButton);
            remove(addButton);
            remove(messageSenderPanel);
            messageSenderPanel.resetPanel();
            add(remove);
            remove.setEnabled(false);
            try {
                setUsersForRemove(currentListName);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            repaint();
            revalidate();
        });
        //
        addButton.addActionListener(e->{
            state = "addUser";
            remove(removeButton);
            remove(addButton);
            remove(messageSenderPanel);
            messageSenderPanel.resetPanel();
            add(add);
            add.setEnabled(false);
            try {
                setUsersForAdd(currentListName);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            repaint();
            revalidate();
        });
        //
        remove.setFocusable(false);
        add.setFocusable(false);
        remove.addActionListener(e->{
            if(state.equals("removeUser")){
                removePerson(currentListName, addUserViewPanel.selectedPanelIds());
                remove.setEnabled(false);
                addUserViewPanel.resetPanel();
                try {
                    setUsersForRemove(currentListName);
                    repaint();
                    revalidate();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
            else{
                deleteList(addUserViewPanel.selectedPanelNames());
                addUserViewPanel.resetPanel();
                try {
                    setListsForRemove();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
            repaint();
            revalidate();
        });
        //
        add.addActionListener(e->{
            addUsersToList(currentListName, addUserViewPanel.selectedPanelIds());
            try {
                setUsersOfLists(currentListName);
                add(removeButton);
                add(addButton);
                add(messageSenderPanel);
                add.setEnabled(false);
                state = "usersList";
                addUserViewPanel.resetPanel();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            remove(add);
            repaint();
            revalidate();
        });
        //
        addUserViewPanel.setStringListener(text -> {
            if(state.equals("removeList") || state.equals("removeUser")) {
                if (text.equals("exit")) {
                    if (!addUserViewPanel.isAnyPanelChosen()) {
                        remove.setEnabled(false);
                    }
                } else {
                    if (addUserViewPanel.isAnyPanelChosen()) {
                        remove.setEnabled(true);
                    }
                }
            }
            else{
                if (text.equals("exit")) {
                    if (!addUserViewPanel.isAnyPanelChosen()) {
                        add.setEnabled(false);
                    }
                } else {

                    if (addUserViewPanel.isAnyPanelChosen()) {
                        add.setEnabled(true);
                    }
                }
            }
        });
        //
        messageSenderPanel.setStringListener(text -> {
            if(text.equals("send")){
                 listFormEvent.setListName(currentListName);
                 listFormEvent.setTweetText(messageSenderPanel.getTextArea().getText());
                 sendMessage(listFormEvent);
                 messageSenderPanel.resetPanel();
                 downPanel.setBounds(0,120,800,490);
            }
            else if(text.equals("photo")){
                 removeAll();
                 add(addPhotoPanel);
                 add(messageSenderPanel);
                 repaint();
                 revalidate();
                 addPhotoPanel.addPhotoButtonAction();
            }
            else{
                downPanel.setBounds(0,120,800,490 -
                        Integer.parseInt(text));
            }
        });
        //
        addPhotoPanel.setStringListener(text->{
            if(text.equals("back")){
                remove(addPhotoPanel);
                add(addButton);
                add(messageSenderPanel);
                add(downPanel);
                add(removeButton);
                state = "usersList";
                setUsersOfLists(currentListName);
                repaint();
                revalidate();
            }
        });
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.SUB_PANEL));
        this.setBounds(265,50,800,700);
        this.add(followersButton);
        this.add(followingsButton);
        this.add(blackListButton);
        this.add(myListButton);
        this.add(downPanel);
    }

    public void setFollowings() throws IOException {
       usersViewPanel.setUserPanels(listPanelListener.loadFollowings());
       usersViewPanel.setSize();
       usersViewPanel.addPanels();
        if(usersViewPanel.getUserPanelList().size() == 0){
            usersViewPanel.add(noFriendLabel);
        }
        downPanel.setViewportView(usersViewPanel);
        repaint();
        revalidate();
    }

    public void setFollowers() throws IOException {
        usersViewPanel.setUserPanels(listPanelListener.loadFollowers());
        usersViewPanel.setSize();
        usersViewPanel.addPanels();
        if(usersViewPanel.getUserPanelList().size() == 0){
            usersViewPanel.add(noFriendLabel);
        }
        downPanel.setViewportView(usersViewPanel);
        repaint();
        revalidate();
    }

    public void setBlackUsers() throws IOException {
        usersViewPanel.setUserPanels(listPanelListener.loadBlackList());
        usersViewPanel.setSize();
        usersViewPanel.addPanels();
        if(usersViewPanel.getUserPanelList().size() == 0){
            usersViewPanel.add(noFriendLabel);
        }
        downPanel.setViewportView(usersViewPanel);
        repaint();
        revalidate();
    }


    public void setLists() throws IOException {
        listsViewPanel.setUserPanels(listPanelListener.loadLists());
        listsViewPanel.setSize();
        listsViewPanel.addPanels();
        if(listsViewPanel.getUserPanelList().size() == 0){
            listsViewPanel.add(noFriendLabel);
        }
        downPanel.setViewportView(listsViewPanel);
        repaint();
        revalidate();
    }

    public void setListsForRemove() throws IOException {
        addUserViewPanel.setUserPanels(listPanelListener.loadLists());
        addUserViewPanel.setSize();
        addUserViewPanel.addPanels();
        if(addUserViewPanel.getUserPanelList().size() == 0){
            addUserViewPanel.add(noFriendLabel);
        }
        downPanel.setViewportView(addUserViewPanel);
        repaint();
        revalidate();
    }

    public void setUsersOfLists(String listName) throws IOException {
        usersViewPanel.setUserPanels(listPanelListener.loadUsersOfLists(listName));
        usersViewPanel.setSize();
        usersViewPanel.addPanels();
        if(usersViewPanel.getUserPanelList().size() == 0){
            usersViewPanel.add(noFriendLabel);
        }
        listsViewPanel.resetPanel();
        downPanel.setViewportView(usersViewPanel);
        repaint();
        revalidate();
    }


    public void setUsersForRemove(String listName) throws IOException {
        addUserViewPanel.setUserPanels(listPanelListener.loadUsersOfLists(listName));
        addUserViewPanel.setSize();
        addUserViewPanel.addPanels();
        if(addUserViewPanel.getUserPanelList().size() == 0){
            addUserViewPanel.add(noFriendLabel);
        }
        usersViewPanel.resetPanel();
        downPanel.setViewportView(addUserViewPanel);
        repaint();
        revalidate();
    }

    public void setUsersForAdd(String listName) throws IOException {
        addUserViewPanel.setUserPanels(listPanelListener.loadUsersForAdd(listName));
        addUserViewPanel.setSize();
        addUserViewPanel.addPanels();
        if(addUserViewPanel.getUserPanelList().size() == 0){
            addUserViewPanel.add(noFriendLabel);
        }
        usersViewPanel.resetPanel();
        downPanel.setViewportView(addUserViewPanel);
        repaint();
        revalidate();
    }

    public void addList(String name){
        listPanelListener.addList(name);
    }

    public void removePerson(String name ,List<Integer> ids){
        listPanelListener.removePerson(name, ids);
    }

    public void deleteList(List<String> names){
        listPanelListener.deleteList(names);
    }

    public void addUsersToList(String listName, List<Integer> ids){
        listPanelListener.addUsersToList(listName, ids);
    }

    public void sendMessage(ListFormEvent listFormEvent){
        listPanelListener.sendMessage(listFormEvent);
    }

    public void resetPanel(){
        removeAll();
        usersViewPanel.resetPanel();
        addUserViewPanel.resetPanel();
        listsViewPanel.resetPanel();
        this.add(followersButton);
        this.add(followingsButton);
        this.add(blackListButton);
        this.add(myListButton);
        this.add(downPanel);
        repaint();
        revalidate();
    }

    public void setStringListener(StringListener stringListener){
        this.stringListener = stringListener;
    }

    public void listenMe(String text){
        try {
            stringListener.stringEventOccurred(text);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}