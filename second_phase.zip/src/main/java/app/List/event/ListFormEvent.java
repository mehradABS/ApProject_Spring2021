package app.List.event;

import app.chat.event.ChatFormEvent;

public class ListFormEvent extends ChatFormEvent {

    private String listName;

    public ListFormEvent(Object source) {
        super(source);
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }
}
