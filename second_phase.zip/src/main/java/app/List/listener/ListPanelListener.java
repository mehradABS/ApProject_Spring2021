package app.List.listener;

import app.List.controller.ListController;
import app.List.event.ListFormEvent;

import java.io.IOException;
import java.util.List;

public class ListPanelListener {

    private final ListController listController = new ListController();

    public List<String[]> loadFollowings(){
        try {
            return listController.loadFollowings();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadFollowers(){
        try {
            return listController.loadFollowers();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadBlackList(){
        try {
            return listController.loadBlackList();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadLists(){
        try {
            return listController.loadLists();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadUsersOfLists(String text){
        try {
            return listController.loadUsersOfLists(text);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addList(String name){
        try {
            listController.addList(name);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void removePerson(String name,List<Integer> ids){
        for (Integer id: ids) {
            try {
                listController.removeUser(name , id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteList(List<String> names){
        for (String s: names) {
            try {
                listController.removeList(s);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public List<String[]> loadUsersForAdd(String listName){
        try {
            return listController.loadFollowingsForAddTOList(listName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addUsersToList(String listName, List<Integer> ids){
        for (Integer id:ids) {
            try {
                listController.addUser(listName, id);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void sendMessage(ListFormEvent listFormEvent){
        try {
            listController.sendMessage(listFormEvent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
