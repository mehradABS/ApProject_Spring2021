package app.List.controller;

import Models.auth.User;
import app.List.event.ListFormEvent;
import app.chat.controller.ChatPanelController;
import app.chat.controller.ContactPanelController;
import controller.MainController;
import db.ChatDB;
import db.UserDB;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ListController extends MainController {

    private final ChatPanelController chatPanelController =
            new ChatPanelController();

    private final ContactPanelController contactPanelController =
            new ContactPanelController();

    public List<String[]> loadFollowings() throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        for (Integer id:current.getFollowingUsername()) {
            User user = context.getUsers().get(id);
            if(!user.getBlackUsername().contains(currentUserId)
                    && user.getAccount().isActive()){
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB)context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }

    public List<String[]> loadFollowers() throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        for (Integer id:current.getFollowerUsername()) {
            User user = context.getUsers().get(id);
            if(!user.getBlackUsername().contains(currentUserId)
                    && user.getAccount().isActive()){
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB)context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }

    public List<String[]> loadBlackList() throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        for (Integer id:current.getBlackUsername()) {
            User user = context.getUsers().get(id);
            if(user.getAccount().isActive()) {
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB) context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }

    public List<String[]> loadLists() throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        for (User.ListName listName: current.getFollowingsList()) {
            String[] fo = new String[3];
            fo[0] = listName.getName();
            fo[1] = listName.getName();
            fo[2] = ((ChatDB)context.getChats()).loadChatImage(-1);
            info.add(fo);
        }
        return info;
    }

    public List<String[]> loadUsersOfLists(String listName) throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        int index = 0;
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(listName)){
                index = i;
                break;
            }
        }
        for (Integer id:current.getFollowingsList().get(index).getUsernames()) {
            User user = context.getUsers().get(id);
            if(user.getAccount().isActive()) {
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB) context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }


    public void sendMessage(ListFormEvent listFormEvent) throws IOException {
        User current = context.getUsers().get(currentUserId);
        int index = 0;
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(listFormEvent
            .getListName())){
                index = i;
                break;
            }
        }
        for (Integer id: current.getFollowingsList().get(index).getUsernames()) {
            listFormEvent.setChatId(contactPanelController.makeNewChat(id));
            chatPanelController.newMessage(listFormEvent);
        }
    }

    public void addUser(String listName, int userId) throws IOException {
        User current = context.getUsers().get(currentUserId);
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(listName)){
                current.getFollowingsList().get(i).getUsernames().add(userId);
                break;
            }
        }
        context.getUsers().set(current);
    }

    public void removeUser(String listName, int userId) throws IOException {
        User current = context.getUsers().get(currentUserId);
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(listName)){
                current.getFollowingsList().get(i).getUsernames().remove(userId);
                break;
            }
        }
        context.getUsers().set(current);
    }

    public List<String[]> loadFollowingsForAddTOList(String listName)
            throws IOException {
        User current = context.getUsers().get(currentUserId);
        int index = 0;
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(listName)){
                index = i;
                break;
            }
        }
        List<String[]> info = new LinkedList<>();
        for (Integer id:current.getFollowingUsername()) {
            User user = context.getUsers().get(id);
            if(!user.getBlackUsername().contains(currentUserId)
                    && user.getAccount().isActive()
             && !current.getFollowingsList().get(index).getUsernames().contains(id)){
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB)context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }

    public void addList(String name) throws IOException {
        User current = context.getUsers().get(currentUserId);
        User.ListName listName = new User.ListName();
        listName.setName(name);
        current.getFollowingsList().add(listName);
        context.getUsers().set(current);
    }

    public void removeList(String name) throws IOException {
        User current = context.getUsers().get(currentUserId);
        for (int i = 0; i < current.getFollowingsList().size(); i++) {
            if(current.getFollowingsList().get(i).getName().equals(name)){
                current.getFollowingsList().remove(i);
                break;
            }
        }
        context.getUsers().set(current);
    }
}
