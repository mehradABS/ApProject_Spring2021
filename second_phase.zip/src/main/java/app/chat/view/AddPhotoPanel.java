package app.chat.view;



import app.personalPage.subPart.newPost.view.NewPostPanel;
import resources.Colors;
import resources.Images;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class AddPhotoPanel extends NewPostPanel {

    public AddPhotoPanel() {
        super();
        JButton backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(10, 10, 54, 45);
        backButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        backButton.setFocusable(false);
        backButton.addActionListener(e -> {
            try {
                resetPanel();
                listenMe("back");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        this.removeAll();
        this.add(imagePanel);
        this.add(pngLabel);
        this.add(backButton);
        this.setBounds(0,0,700,500);
        this.setBackground(Color.decode(Colors.SUB_PANEL));
    }

}
