package app.chat.view;

import app.chat.event.ChatFormEvent;
import app.chat.listener.ChatPanelListener;
import app.personalPage.subPart.forwardMessage.view.ForwardPanel;
import app.timeLine.subPart.commentsPage.view.CommentsPagePanel;
import resources.Colors;
import view.listeners.StringListener;
import view.postView.commentPage.CommentView;
import view.postView.message.MessageSenderPanel;
import view.postView.message.MessageView;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ChatMainPanel extends JPanel {

    private final AddPhotoPanel addPhotoPanel;
    private StringListener stringListener;
    private final CommentsPagePanel<CommentView> commentsPagePanel;
    private int height;
    private int chatId;
    private final List<JPanel> messages;
    private final MessageSenderPanel messageSenderPanel;
    private final JPanel upPanel;
    private final JScrollPane upPanelKeeper;
    private final ChatPanelListener chatPanelListener;
    private final ChatFormEvent chatFormEvent;
    public ChatMainPanel() {
        messageSenderPanel = new MessageSenderPanel(620,800);
        //
        upPanel = new JPanel();
        upPanel.setLayout(null);
        upPanelKeeper = new JScrollPane(upPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        upPanelKeeper.getVerticalScrollBar().setUnitIncrement(16);
        upPanel.setBackground(Color.decode(Colors.SUB_PANEL));
        upPanelKeeper.setBounds(0,0,800,620);
        //
        addPhotoPanel = new AddPhotoPanel();
        addPhotoPanel.setStringListener(text -> {
            if(text.equals("back")){
                remove(addPhotoPanel);
                add(upPanelKeeper);
                loadMessages();
                repaint();
                revalidate();
            }
        });
        //
        commentsPagePanel = new CommentsPagePanel<>(CommentView::new);
        //
        chatFormEvent = new ChatFormEvent(this);
        //
        chatPanelListener = new ChatPanelListener();
        //
        messageSenderPanel.setStringListener(text -> {
            if(text.equals("send")){
                remove(addPhotoPanel);
                add(upPanelKeeper);
                sendAction();
            }
            else if(text.equals("photo")){
                remove(upPanelKeeper);
                add(addPhotoPanel);
                repaint();
                revalidate();
                addPhotoPanel.addPhotoButtonAction();
            }
            else {
                changeMessagesKeeperCoordinate(Integer.parseInt(text));
            }
        });
        //
        messages = new LinkedList<>();
        this.setLayout(null);
     this.setBackground(Color.decode(Colors.SUB_PANEL));
     this.setBounds(680,50,800,700);
     this.add(upPanelKeeper);
     this.add(messageSenderPanel);
    }

    public void changeMessagesKeeperCoordinate(int y){
        upPanelKeeper.setBounds(0,0,800,620 - y);
    }

    public void loadMessages() throws IOException {
        messages.removeAll(messages);
        height = 15;
        upPanel.removeAll();
        List<String[]> info = chatPanelListener.loadMessages(chatId);
        for (int i = 0; i < info.size(); i++) {
            setMessageInfo(info.get(i));
        }
        addMessages();
        repaint();
        revalidate();
    }

    public void setMessageInfo(String[] info) throws IOException {
        ImageIcon icon1;
        ImageIcon icon2;
        if(info[info.length - 1] .equals("message")){
            if(info[2].equals("null")){
              icon1 = null;
            }
            else{
                icon1 = new ImageIcon(ImageIO.read(new File(info[2])));
            }
            if(info[6].equals("null")){
                icon2 = null;
            }
            else{
                icon2 = new ImageIcon(ImageIO.read(new File(info[6])));
            }
            MessageView messageView = new MessageView();
            messageView.setInfo(info[1], icon1,
                     info[3], info[4], icon2);
            messageView.setMessageId(Integer.parseInt(info[8]));
            int x = messageView.getWidth();
            int increase;
            if(Boolean.parseBoolean(info[7]))
             {increase = messageView.setSizes(0,height) + 15;}
             else{increase = messageView.setSizes(790 - x, height) + 15;}
            messageView.setDeleteItem(Boolean.parseBoolean(info[0]));
            messageView.setEditItem(Boolean.parseBoolean(info[5]));
            messageView.addComponents();
            addStringListenerToMessageView(messageView);
            height += increase;
            messages.add(messageView);
        }
         else{
             CommentView commentView =
                     commentsPagePanel.makePostView(info, info[info.length - 1]);
             int increase = commentView.getHeight() + 15;
            if(Boolean.parseBoolean(info[13])){
                commentView.setSizes(0, height);
                commentView.setDeleteItem(true);
                commentView.addStringListener(text -> {
                       if(text.equals("delete")){
                           deleteTweet(commentView);
                       }
                });
            }
             else{
                 commentView.setSizes(95, height);
                 commentView.setDeleteItem(false);
            }
             height += increase;
             messages.add(commentView);
         }
    }

    public void addMessages(){
        upPanel.setPreferredSize(new Dimension(800,height));
        for (int i = messages.size() - 1; i >= 0; i--) {
            upPanel.add(messages.get(i));
        }
    }

    public int getChatId() {
        return chatId;
    }

    public void setChatId(int chatId) {
        this.chatId = chatId;
    }


    public void sendAction() throws IOException {
       if(messageSenderPanel.getEditableMessageId() == -1) {
           chatFormEvent.setTweetText(messageSenderPanel.getTextArea().getText());
           chatFormEvent.setChatId(chatId);
           String[] info = chatPanelListener.newMessage(chatFormEvent);
           info[info.length - 1] = "message";
           setMessageInfo(info);
           upPanel.add(messages.get(messages.size() - 1));
           upPanel.setPreferredSize(new Dimension(800, height));
           repaint();
           revalidate();
           messageSenderPanel.resetPanel();
           changeMessagesKeeperCoordinate(0);
       }
       else{
           chatFormEvent.setTweetText(messageSenderPanel.getTextArea().getText());
           chatFormEvent.setMessageId(messageSenderPanel.getEditableMessageId());
           chatPanelListener.editMessage(chatFormEvent);
           messageSenderPanel.editText(false);
           loadMessages();
       }
    }

    public void deleteMessage(MessageView messageView) throws IOException {
        chatFormEvent.setChatId(chatId);
        chatFormEvent.setMessageId(messageView.getMessageId());
        chatPanelListener.deleteMessage(chatFormEvent);
        loadMessages();
    }


    public void deleteTweet(CommentView commentView){
        chatFormEvent.setChatId(chatId);
        chatFormEvent.setMessageId(commentView.getTweetId());
        try {
            chatPanelListener.deleteMessage(chatFormEvent);
            loadMessages();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addStringListenerToMessageView(MessageView messageView){
        messageView.setStringListener(text -> {
            if(text.equals("edit")){
                messageSenderPanel.setEditableMessageId(messageView.getMessageId());
                messageSenderPanel.getTextArea().setText(messageView.getMessageText()
                .getText());
                messageSenderPanel.editText(true);
            }
            else if(text.equals("delete")){
                deleteMessage(messageView);
            }
        });
    }

    public void resetPanel(){
        remove(addPhotoPanel);
        add(upPanelKeeper);
        repaint();
        revalidate();
    }

}
