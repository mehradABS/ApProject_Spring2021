package app.chat.view;

import app.chat.listener.ContactPanelListener;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;
import view.usersView.UserPanel;
import view.usersView.UserPanelSelectable;
import view.usersView.UsersViewPanel;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class GroupSettingPanel extends JPanel {

    private int currentChatId;
    private String state = "chats";
    private final ContactPanelListener contactPanelListener;
    private StringListener stringListener;
    private UsersViewPanel<UserPanel> chatsViewPanel;
    private UsersViewPanel<UserPanelSelectable> addUserViewPanel;
    private final JScrollPane downPanel;

    public GroupSettingPanel (ContactPanelListener listener){
        addUserViewPanel = new UsersViewPanel<>(410,UserPanelSelectable::new);
        //
        chatsViewPanel = new UsersViewPanel<>(410,UserPanel::new);
        downPanel = new JScrollPane(chatsViewPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        downPanel.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        downPanel.setBounds(0,120,700,580);
        //
        JButton backButton = new JButton(Images.BACK_ICON);
        backButton.setBounds(5,10,54,45);
        backButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        //
        JButton removeButton = new JButton(Images.REMOVE_PERSON);
        removeButton.setBounds(200,10,54,45);
        removeButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        //
        JButton addButton = new JButton(Images.ADD_PERSON);
        addButton.setBounds(340,10,54,45);
        addButton.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        //
        JButton remove = new JButton(Texts.REMOVE);
        remove.setBounds(240,10,160,60);
        remove.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        remove.setFont(Fonts.BUTTONS_FONT);
        remove.setEnabled(false);
        //
        JButton add = new JButton(Texts.ADD);
        add.setBounds(240,10,160,60);
        add.setBackground(Color.decode(Colors.CHANGE_INFO_COLOR));
        add.setFont(Fonts.BUTTONS_FONT);
        add.setEnabled(false);
        //
        this.contactPanelListener = listener;
        //
        chatsViewPanel.setStringListener(text -> {
            if(!state.equals("members")) {
                chatsViewPanel.resetPanel();
                currentChatId = Integer.parseInt(text);
                state = "members";
                add(addButton);
                add(removeButton);
                loadMembers(currentChatId);
            }
            chatsViewPanel.resetSelectedPanels();
        });
        //
        addButton.addActionListener(e -> {
            chatsViewPanel.resetPanel();
            chatsViewPanel.resetSelectedPanels();
            remove(addButton);
            remove(removeButton);
            add(add);
            state = "add";
            loadFollowings();
        });
        //
        removeButton.addActionListener(e->{
            chatsViewPanel.resetPanel();
            chatsViewPanel.resetSelectedPanels();
            remove(addButton);
            remove(removeButton);
            add(remove);
            state = "remove";
            loadMembersForRemove(currentChatId);
        });
        //
        addUserViewPanel.setStringListener(text -> {
          if(state.equals("remove")){
              remove.setEnabled(addUserViewPanel.isAnyPanelChosen());
          }
          else if(state.equals("add")){
              add.setEnabled(addUserViewPanel.isAnyPanelChosen());
          }
        });
        //
        add.addActionListener(e->{
            loadGroupChats();
            add(currentChatId,addUserViewPanel.selectedPanelIds());
            remove(add);
            addUserViewPanel.resetSelectedPanels();
            addUserViewPanel.resetPanel();
            state = "chats";
        });
        //
        remove.addActionListener(e->{
            remove(currentChatId,addUserViewPanel.selectedPanelIds());
            remove(remove);
            addUserViewPanel.resetSelectedPanels();
            addUserViewPanel.resetPanel();
            state = "chats";
            listenMe("back");
        });
        //
        backButton.addActionListener(e->{
            switch (state) {
                case "members" -> {
                    chatsViewPanel.resetSelectedPanels();
                    chatsViewPanel.resetPanel();
                    remove(addButton);
                    remove(removeButton);
                    state = "chats";
                    loadGroupChats();
                }
                case "add" -> {
                    addUserViewPanel.resetSelectedPanels();
                    addUserViewPanel.resetPanel();
                    add(addButton);
                    add(removeButton);
                    remove(add);
                    loadMembers(currentChatId);
                    state = "members";
                }
                case "remove" -> {
                    addUserViewPanel.resetSelectedPanels();
                    addUserViewPanel.resetPanel();
                    add(addButton);
                    add(removeButton);
                    remove(remove);
                    loadMembers(currentChatId);
                    state = "members";
                }
                case "chats" -> listenMe("back");
            }
        });
        //
        setLayout(null);
        setBackground(Color.decode(Colors.INFO_PANEL));
        setBounds(0,0,410,700);
        add(backButton);
        add(downPanel);
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void loadGroupChats(){
        try {
            chatsViewPanel.setUserPanels(contactPanelListener.loadGroupChats());
            chatsViewPanel.setSize();
            chatsViewPanel.addPanels();
        } catch (IOException e) {
            e.printStackTrace();
        }
        downPanel.setViewportView(chatsViewPanel);
        repaint();
        revalidate();
    }

    public void loadMembers(int chatId){
        try {
            chatsViewPanel.setUserPanels(contactPanelListener.loadMembersOfChat(chatId));
            chatsViewPanel.setSize();
            chatsViewPanel.addPanels();
        } catch (IOException e) {
            e.printStackTrace();
        }
        downPanel.setViewportView(chatsViewPanel);
        repaint();
        revalidate();
    }


    public void add(int chatId, List<Integer> userIds){
        for (Integer userId:userIds) {
            contactPanelListener.add(chatId, userId);
        }
    }

    public void remove(int chatId, List<Integer> userIds){
        for (Integer userId:userIds) {
            contactPanelListener.remove(chatId, userId);
        }
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFollowings(){
        try {
            addUserViewPanel.setUserPanels
                    (contactPanelListener.loadFollowings(currentChatId));
            addUserViewPanel.setSize();
            addUserViewPanel.addPanels();
        } catch (IOException e) {
            e.printStackTrace();
        }
        downPanel.setViewportView(addUserViewPanel);
        repaint();
        revalidate();
    }

    public void loadMembersForRemove(int chatId){
        try {
            addUserViewPanel.setUserPanels(contactPanelListener.loadMembersOfChat(chatId));
            addUserViewPanel.setSize();
            addUserViewPanel.addPanels();
        } catch (IOException e) {
            e.printStackTrace();
        }
        downPanel.setViewportView(addUserViewPanel);
        repaint();
        revalidate();
    }
}
