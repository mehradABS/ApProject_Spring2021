package app.chat.view;


import app.chat.listener.ContactPanelListener;
import resources.Colors;
import resources.Fonts;
import resources.Images;
import resources.Texts;
import view.listeners.StringListener;
import view.usersView.UserPanel;
import view.usersView.UsersViewPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

public class ContactsPanel extends JPanel {

    private StringListener stringListener;
    private final ContactPanelListener contactPanelListener;
    private final JButton newGroupButton;
    private final UsersViewPanel<UserPanel> usersViewPanel;
    private final JPanel upPanel;
    private final JButton searchButton;
    private final JPanel downPanel;
    private final NewGroupPanel newGroupPanel;

    public ContactsPanel() {
        contactPanelListener = new ContactPanelListener();
        GroupSettingPanel groupSettingPanel = new GroupSettingPanel(
                contactPanelListener);
        //
        searchButton = new JButton(Images.SEARCH_ICON_SMALL);
        searchButton.setFocusable(false);
        searchButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        searchButton.setBounds(20,20,40,40);
        searchButton.addActionListener(e->{
            try {
                resetPanel();
                listenMe("search");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        //
        newGroupButton = new JButton(Texts.NEW_GROUP);
        newGroupButton.setBounds(80,20,250,40);
        newGroupButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        newGroupButton.setFocusable(false);
        newGroupButton.setFont(Fonts.BUTTONS_FONT);
        //
        usersViewPanel = new UsersViewPanel<>(410, UserPanel::new);
        usersViewPanel.setStringListener(this::listenMe);
        downPanel = new JPanel();
        downPanel.add(usersViewPanel);
        downPanel.setLayout(null);
        downPanel.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        //
        upPanel = new JPanel();
        upPanel.setLayout(null);
        upPanel.setBounds(0,0,410,80);
        upPanel.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        upPanel.add(newGroupButton);
        upPanel.add(searchButton);
        JButton button = new JButton(Images.SETTING1);
        button.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        button.setFocusable(false);
        button.setBounds(350,20,40,40);
        upPanel.add(button);
        button.addActionListener(e -> {
            removeAll();
            try {
                listenMe("setting");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            groupSettingPanel.loadGroupChats();
            add(groupSettingPanel);
            revalidate();
            repaint();
        });
        //
        newGroupPanel = new NewGroupPanel();
        newGroupButton.addActionListener(e -> {
              removeAll();
            try {
                newGroupPanel.setInfo();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            add(newGroupPanel);
              repaint();
              revalidate();
        });
        //
        newGroupPanel.setStringListener(text -> {
            if(text.equals("back")){
                removeAll();
                this.add(upPanel);
                this.add(downPanel);
                repaint();
                revalidate();
            }
            else if(text.equals("addGroup")){
                 contactPanelListener.makeGroupChat(newGroupPanel.groupName(),
                         newGroupPanel.getUserIds());
                removeAll();
                this.add(upPanel);
                loadChats();
                this.add(downPanel);
                repaint();
                revalidate();
            }
        });
        //
        groupSettingPanel.setStringListener(text -> {
            if(text.equals("back")){
                removeAll();
                loadChats();
                add(upPanel);
                add(downPanel);
                repaint();
                revalidate();
            }
        });
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        this.add(upPanel);
        this.add(downPanel);
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name) throws IOException {
        stringListener.stringEventOccurred(name);
    }

    public void loadChats() throws IOException {
        List<String[]> info = contactPanelListener.loadChats();
        usersViewPanel.setUserPanels(info);
        usersViewPanel.addPanels();
        downPanel.setBounds(0,80,410, usersViewPanel.getPreferredHeight());
        this.setPreferredSize(new Dimension(420,
                Math.max(usersViewPanel.getPreferredHeight()+80,690)));
        repaint();
        revalidate();
    }

    public void resetPanel(){
        usersViewPanel.setUserId(-1);
        removeAll();
        this.add(upPanel);
        this.add(downPanel);
        repaint();
        revalidate();
    }

    public int makeNewChat(int userId){
        return  contactPanelListener.makeNewChat(userId);
    }

    public UsersViewPanel<UserPanel> getUsersViewPanel() {
        return usersViewPanel;
    }
}
