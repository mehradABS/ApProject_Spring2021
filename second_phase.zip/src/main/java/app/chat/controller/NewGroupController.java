package app.chat.controller;

import Models.auth.User;
import controller.MainController;
import db.UserDB;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class NewGroupController extends MainController {


    public List<String[]> loadFriends() throws IOException {
        User current = context.getUsers().get(currentUserId);
        List<String[]> info = new LinkedList<>();
        for (Integer id:current.getFollowingUsername()) {
            User user = context.getUsers().get(id);
            if(!user.getBlackUsername().contains(currentUserId)
             && user.getAccount().isActive()){
                String[] fo = new String[3];
                fo[0] = String.valueOf(id);
                fo[1] = user.getAccount().getUsername();
                fo[2] = ((UserDB)context.getUsers()).loadProfile(id, 60);
                info.add(fo);
            }
        }
        return info;
    }
}