package app.chat.controller;

import Models.*;
import Models.auth.User;
import Models.messages.Message;
import app.chat.event.ChatFormEvent;
import app.personalPage.subPart.newPost.controller.PostController;
import app.personalPage.subPart.tweetHistory.controller.TweetHistoryController;
import controller.MainController;
import db.UserDB;
import resources.Texts;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

public class ChatPanelController extends MainController {

    private final TweetHistoryController tweetHistoryController;
    private final PostController postController;

    public ChatPanelController() {
        tweetHistoryController = new TweetHistoryController();
        postController = new PostController();
    }

    public List<String[]> loadMessages(int chatId) throws IOException {
        List<String[]> allInfo = new LinkedList<>();
        Chat chat = context.getChats().get(chatId);
        List<Message> messages = new LinkedList<>();
        User current = context.getUsers().get(currentUserId);
        int indexOfChatId = 0;
        for (int i = 0; i < current.getMyChatIds().size(); i++) {
            if(current.getMyChatIds().get(i) == chatId){
                indexOfChatId = i;
                break;
            }
        }
        for (int i = 0; i < current.getMyUnreadChatIds().size(); i++) {
            if(current.getMyUnreadChatIds().get(i) == chatId){
                current.getMyUnreadChatMessagesNumbers().remove(i);
                current.getMyUnreadChatIds().remove(i);
                break;
            }
        }
        for (Integer id: chat.getId_Message()) {
            messages.add(context.getMessages().get(id, "message"));
        }
        for (Integer id: chat.getId_forwardMessage()) {
            messages.add(context.getMessages().get(id, "message"));
        }
        for (Integer id: chat.getForwardTweets()) {
            messages.add(context.getMessages().get(id, "tweet"));
        }
        for (Integer id: chat.getForwardComments()) {
            messages.add(context.getMessages().get(id, "comment"));
        }
        Chat.sortMessages(messages);
        for (int i = 0; i < messages.size(); i++) {
            String[] info;
            if(chat.getId_Message().contains(messages.get(i).getId())){
                 boolean f = !chat.getDeletedMessage().contains(messages.get(i).getId());
                 boolean f2 = current.getMyChatMessagesIds().get(indexOfChatId)
                         .contains(messages.get(i).getId());
                 info = setMessageInfo(messages.get(i),
                         f && f2, f && f2, false, false);
                 info[info.length - 1] = "message";
            }
             else if(chat.getId_forwardMessage().
                    contains(messages.get(i).getId())){
                 boolean f = !chat.getDeletedMessage()
                         .contains(messages.get(i).getId());
                 boolean f2 = current.getMyChatMessagesIds().get(indexOfChatId)
                        .contains(messages.get(i).getId());
                 info = setMessageInfo(messages.get(i),
                         f && f2, false, true, false);
                 info[info.length - 1] = "message";
             }
             else if(chat.getForwardTweets().contains(messages.get(i).getId())){
                boolean f = !chat.getDeletedMessage().contains(messages.get(i).getId());
                if(f) {
                    info = setTweetInfo(messages.get(i));
                    info[info.length - 1] = "tweet";
                }
                else{
                    Message message = context.getMessages().get(messages.get(i).getId(),
                            "message");
                    info = setMessageInfo(message, false, false
                    ,true, true);
                    info[info.length - 1] = "message";
                }
             }
             else{
                boolean f = !chat.getDeletedMessage().contains(messages.get(i).getId());
                if(f) {
                    info = setTweetInfo(messages.get(i));
                    info[info.length - 1] = "comment";
                }
                else{
                    Message message = context.getMessages().get(messages.get(i).getId(),
                            "message");
                    info = setMessageInfo(message, false, false
                            ,true, true);
                    info[info.length - 1] = "message";
                }
            }
             allInfo.add(info);
        }
        context.getUsers().set(current);
        return allInfo;
    }

    public String[] setMessageInfo(Message message, boolean deletable,
                                   boolean editable
                            , boolean forward, boolean deletedTweet)
            throws IOException {
        User user;
        String[] info = new String[10];
        if(!forward){
            user = context.getUsers().get(message.getUserId());
            info[1] = message.getText();
        }
         else {
            user = context.getUsers().get(message.getForwarderId());
            info[1] = "forwarded from: " +
                    context.getUsers().
                            get(message.getUserId()).getAccount().getUsername()+"\n"+
                            message.getText();
         }
        info[0] = String.valueOf(deletable);
        if(!deletedTweet) {
            info[2] = context.getTweets().loadTweetImage(message.getId());
            if(forward){
                info[2] = context.getTweets().loadTweetImage(message.getImageId());
            }
        }
        else {info[2] = "null";}
        info[3] = user.getAccount().getUsername();
        info[4] = message.getLocalDateTime().getHour()+": "+message.getLocalDateTime()
                .getMinute();
        info[5] = String.valueOf(editable);
        info[6] = ((UserDB)context.getUsers()).loadProfile(message.getUserId(), 60);
        info[7] = String.valueOf(user.getId() == currentUserId);
        info[8] = String.valueOf(message.getId());
        return info;
    }

    public String[] setTweetInfo(Message message)
            throws IOException {
        User user = context.getUsers().get(message.getForwarderId());
        String[] info = tweetHistoryController.loadTweetInfo(message, user,
                "");
        if(message.getForwarderId() != -1) {
            info[1] = context.getTweets().loadTweetImage(message.getImageId());
        }
        String[] info1 = new String[15];
        System.arraycopy(info, 0, info1, 0, 12);
        info1[13] = String.valueOf(user.getId() == currentUserId);
        return info1;
    }

    public String[] newMessage(ChatFormEvent chatFormEvent) throws IOException {
        User current = context.getUsers().get(currentUserId);
        Message.setId_counter(context.getMessages().getIDCounter());
        Message msg = new Message("message", chatFormEvent.getTweetText(),
                current, LocalDateTime.now());
        Chat chat = context.getChats().get(chatFormEvent.getChatId());
        chat.getId_Message().add(msg.getId());
        int a = 0;
        for (int i = 0; i < current.getMyChatIds().size(); i++) {
            if(current.getMyChatIds().get(i) == chat.getId()){
                a = i;
                break;
            }
        }
        current.getMyChatMessagesIds().get(a).add(msg.getId());
        for (Integer userId:chat.getUsersIds()) {
            if(userId != currentUserId){
                User user = context.getUsers().get(userId);
                int b = 0;
                boolean f = true;
                for (int i = 0; i < user.getMyUnreadChatIds().size(); i++) {
                    if(user.getMyUnreadChatIds().get(i) == chat.getId()){
                        b = i;
                        f = false;
                        break;
                    }
                }
                if(!f) {
                    int c = user.getMyUnreadChatMessagesNumbers().get(b);
                    user.getMyUnreadChatMessagesNumbers().set(b, c + 1);
                }
                else{
                    user.getMyUnreadChatIds().add(chat.getId());
                    user.getMyUnreadChatMessagesNumbers().add(1);
                }
                context.getUsers().set(user);
            }
        }
        context.getUsers().set(current);
        context.getMessages().setIDCounter(Message.getId_counter());
        context.getMessages().set(msg, "message");
        context.getChats().set(chat);
        return setMessageInfo
                (msg, true, true, false, false);
    }

    public void deleteMessage(ChatFormEvent chatFormEvent)
            throws IOException {
        Chat chat = context.getChats().get(chatFormEvent.getChatId());
        if(chat.getId_Message().contains(chatFormEvent.getMessageId())
         || chat.getId_forwardMessage().contains(chatFormEvent.getMessageId())){
            postController.deleteTweetImage(chatFormEvent.getMessageId());
            Message msg = context.getMessages().get(chatFormEvent.getMessageId()
            ,"message");
            msg.setText(Texts.DELETED_MESSAGE);
            chat.getDeletedMessage().add(msg.getId());
            context.getMessages().set(msg, "message");
        }
        else if(chat.getForwardTweets().contains(chatFormEvent.getMessageId())){
           Message message = context.getTweets().get(chatFormEvent.getMessageId()
           ,"tweet");
           message.setText(Texts.DELETED_MESSAGE);
           chat.getDeletedMessage().add(message.getId());
           context.getMessages().set(message, "message");
       }
       else{
            Message message = context.getComments().get(chatFormEvent.getMessageId()
                    ,"comment");
            message.setText(Texts.DELETED_MESSAGE);
            chat.getDeletedMessage().add(message.getId());
            context.getMessages().set(message, "message");
       }
       context.getChats().set(chat);
    }

    public void editMessage(ChatFormEvent chatFormEvent) throws IOException {
        Message message = context.getMessages().get(chatFormEvent.getMessageId(),
                "message");
        message.setText(chatFormEvent.getTweetText());
        context.getMessages().set(message, "message");
    }
}