package app.chat.event;

import app.personalPage.subPart.newPost.event.PostFormEvent;


public class ChatFormEvent extends PostFormEvent {

    private int chatId;
    private int MessageId;

    public ChatFormEvent(Object source) {
        super(source);
    }

    public int getChatId() {
        return chatId;
    }

    public void setChatId(int chatId) {
        this.chatId = chatId;
    }

    public int getMessageId() {
        return MessageId;
    }

    public void setMessageId(int messageId) {
        MessageId = messageId;
    }
}
