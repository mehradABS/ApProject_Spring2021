package app.chat.listener;

import app.chat.controller.ContactPanelController;

import java.io.IOException;
import java.util.List;

public class ContactPanelListener {

    private final ContactPanelController contactPanelController;

    public ContactPanelListener() {
        contactPanelController = new ContactPanelController();
    }

    public List<String[]> loadChats() throws IOException {
        return contactPanelController.loadChats();
    }

    public int  makeNewChat(int userId){
        try {
            return contactPanelController.makeNewChat(userId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void makeGroupChat(String groupName, List<Integer> ids){
        try {
            contactPanelController.makeNewGroupChat(ids, groupName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String[]> loadGroupChats(){
        try {
            return contactPanelController.loadGroupChats();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String[]> loadMembersOfChat(int chatId){
        try {
            return contactPanelController.loadMembersOfChat(chatId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void add(int chatId, int userId){
        try {
            contactPanelController.addPersonToChat(chatId, userId);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void remove(int chatId, int userId){
        try {
            contactPanelController.removePersonFromChat(chatId, userId);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String[]> loadFollowings(int chatId){
        try {
            return contactPanelController.loadFollowings(chatId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
