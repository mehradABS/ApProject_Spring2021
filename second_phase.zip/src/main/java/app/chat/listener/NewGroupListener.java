package app.chat.listener;

import app.chat.controller.NewGroupController;

import java.io.IOException;
import java.util.List;

public class NewGroupListener {

    private final NewGroupController newGroupController = new NewGroupController();

    public List<String[]> loadFriends(){
        try {
            return newGroupController.loadFriends();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
