package app.chat.listener;

import app.chat.controller.ChatPanelController;
import app.chat.event.ChatFormEvent;

import java.io.IOException;
import java.util.List;

public class ChatPanelListener {

    private final ChatPanelController chatPanelController;

    public ChatPanelListener() {
        chatPanelController = new ChatPanelController();
    }

    public List<String[]> loadMessages(int chatId) throws IOException {
        return chatPanelController.loadMessages(chatId);
    }

    public String[] newMessage(ChatFormEvent chatFormEvent) throws IOException {
        return chatPanelController.newMessage(chatFormEvent);
    }

    public void editMessage(ChatFormEvent chatFormEvent) throws IOException {
        chatPanelController.editMessage(chatFormEvent);
    }

    public void deleteMessage(ChatFormEvent chatFormEvent) throws IOException {
        chatPanelController.deleteMessage(chatFormEvent);
    }
}
