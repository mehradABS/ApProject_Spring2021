package exceptions;

public class InvalidEntrance extends Exception{
     private final String type;

    public InvalidEntrance(String type) {
        super();
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
