package exceptions;

public class LoginException extends Exception{
    public LoginException() {
        super();
    }
}
