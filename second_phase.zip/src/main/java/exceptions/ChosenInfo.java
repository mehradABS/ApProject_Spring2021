package exceptions;

public class ChosenInfo extends Exception{

    private final String type;

    public ChosenInfo(String type) {
        super();
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
