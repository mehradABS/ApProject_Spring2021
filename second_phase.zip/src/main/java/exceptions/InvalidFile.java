package exceptions;

public class InvalidFile extends Exception {
    public InvalidFile() {
        super();
    }
}
