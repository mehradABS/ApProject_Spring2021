package view;



import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class FatherFrame extends JFrame {


    public FatherFrame() throws HeadlessException, IOException {
        ProgramMainPanel programMainPanel = new ProgramMainPanel();
        //
        //
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(programMainPanel);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }

}
