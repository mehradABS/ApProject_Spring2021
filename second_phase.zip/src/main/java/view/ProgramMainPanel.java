package view;


import app.Explore.view.ExploreMainPanel;
import app.List.view.ListMainPanel;
import app.authentication.view.AuthenticationMainPanel;
import app.chat.view.ChatMainPanel;
import app.chat.view.ContactsPanel;
import app.notification.view.NotificationMainPanel;
import app.personalPage.subPart.forwardMessage.view.ForwardPanel;
import app.personalPage.subPart.info.view.InfoPanel;
import app.personalPage.view.PersonalPageMainPanel;
import app.setting.view.SettingPanel;
import app.timeLine.subPart.commentsPage.view.CommentsPagePanel;
import app.timeLine.view.TimelinePage;
import resources.Colors;
import resources.Images;
import view.listeners.StringListener;
import view.menu.MenuPanel;
import view.postView.commentPage.CommentView;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class ProgramMainPanel extends JPanel {

    private StringListener stringListener;
    private final MenuPanel menuPanel;
    private final PersonalPageMainPanel personalPageMainPanel;
    private final InfoPanel infoPanel;
    private final TimelinePage timelineMainPanel;
    private final CommentsPagePanel<CommentView> commentsPagePanel;
    private final List<Integer> tweetHistoryKeeperMemento;
    private final JScrollPane tweetHistoryPanelKeeper;
    private final ExploreMainPanel exploreMainPanel;
    private final ChatMainPanel chatMainPanel;
    private final ContactsPanel contactsPanel;
    private final ListMainPanel listMainPanel;
    private final SettingPanel settingPanel;
    private final NotificationMainPanel notif;
    private final ForwardPanel forwardPanel = new ForwardPanel();

    public ProgramMainPanel() throws IOException {
        forwardPanel.setBounds(260,50,700,500);
        notif = new NotificationMainPanel();
        //
        settingPanel = new SettingPanel();
        //
        listMainPanel = new ListMainPanel();
        //
        exploreMainPanel = new ExploreMainPanel();
        //
        timelineMainPanel = new TimelinePage(CommentView::new);
        tweetHistoryKeeperMemento = new LinkedList<>();
        tweetHistoryPanelKeeper = new JScrollPane(timelineMainPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        tweetHistoryPanelKeeper.getVerticalScrollBar().setUnitIncrement(16);
        tweetHistoryPanelKeeper.setBounds(260,50,700,700);
        tweetHistoryPanelKeeper.setBackground(Color.decode(Colors.PROFILE_MAIN_PANEL));
        commentsPagePanel = new CommentsPagePanel<>(
                CommentView::new);
        //
        timelineMainPanel.addStringListeners(text -> {
            if(text.startsWith("commentPage")){
                commentsPagePanel.setOriginalTweetId(Integer.parseInt(
                        text.substring(11)));
                tweetHistoryKeeperMemento.add(Integer.parseInt(
                        text.substring(11)));
                if(tweetHistoryKeeperMemento.size() == 1){
                    commentsPagePanel.setOriginalMessageType("tweet");
                }
                else{
                    commentsPagePanel.setOriginalMessageType("comment");
                }
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.startsWith("share")){
                tweetHistoryPanelKeeper.setVisible(false);
                forwardPanel.setMessageId(Integer.parseInt(text.substring(5,
                        text.length()-1)));
                if(text.charAt(text.length()-1) == '+') {
                    forwardPanel.setMessageType("tweet");
                }
                else{
                    forwardPanel.setMessageType("comment");
                }
                forwardPanel.setInfo();
                add(forwardPanel);
            }
            else if(text.equals("mute")){
                timelineMainPanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(timelineMainPanel);
            }
            else {
                tweetHistoryPanelKeeper.setVisible(false);
                timelineMainPanel.getNewCommentPanel().setTweetId(Integer.parseInt(text));
                timelineMainPanel.getNewCommentPanel().setBounds
                        (260,50,700,500);
                add(timelineMainPanel.getNewCommentPanel());
            }
            repaint();
            revalidate();
        });
        //
        commentsPagePanel.addStringListeners(text -> {
            if(text.startsWith("commentPage")){
                tweetHistoryKeeperMemento.add(Integer.parseInt(
                        text.substring(11)));
                commentsPagePanel.setOriginalTweetId(Integer.parseInt(
                        text.substring(11)));
                if(tweetHistoryKeeperMemento.size() == 1){
                    commentsPagePanel.setOriginalMessageType("tweet");
                }
                else{
                    commentsPagePanel.setOriginalMessageType("comment");
                }
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.equals("back")){
                tweetHistoryKeeperMemento.remove(tweetHistoryKeeperMemento
                        .size()-1);
                if(tweetHistoryKeeperMemento.size() > 0){
                    commentsPagePanel.setOriginalTweetId(
                            tweetHistoryKeeperMemento.get(
                                    tweetHistoryKeeperMemento.size()-1));
                    if(tweetHistoryKeeperMemento.size() == 1){
                        commentsPagePanel.setOriginalMessageType("tweet");
                    }
                    else{
                        commentsPagePanel.setOriginalMessageType("comment");
                    }
                    commentsPagePanel.setInfo();
                    tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
                }
                else{
                    timelineMainPanel.setInfo();
                    tweetHistoryPanelKeeper.setViewportView(timelineMainPanel);
                }
            }
            else if(text.equals("mute")){
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setViewportView(commentsPagePanel);
            }
            else if(text.startsWith("share")){
                tweetHistoryPanelKeeper.setVisible(false);
                forwardPanel.setMessageId(Integer.parseInt(text.substring(5,
                        text.length()-1)));
                if(text.charAt(text.length()-1) == '+') {
                    forwardPanel.setMessageType("tweet");
                }
                else{
                    forwardPanel.setMessageType("comment");
                }
                forwardPanel.setInfo();
                add(forwardPanel);
            }
            else {
                tweetHistoryPanelKeeper.setVisible(false);
                timelineMainPanel.getNewCommentPanel().setTweetId(Integer.parseInt(text));
                timelineMainPanel.getNewCommentPanel().setBounds
                        (260,50,700,500);
                add(timelineMainPanel.getNewCommentPanel());
            }
            repaint();
            revalidate();
        });
        //
        timelineMainPanel.getNewCommentPanel().setStringListener(text -> {
            if(text.equals("back")){
                remove(timelineMainPanel.getNewCommentPanel());
                tweetHistoryPanelKeeper.setVisible(true);
                repaint();
                revalidate();
            }
            else if(text.equals("tweetButton")){
                remove(timelineMainPanel.getNewCommentPanel());
                timelineMainPanel.loadCommentsNumberOfPost(
                        timelineMainPanel.getNewCommentPanel().getTweetId());
                commentsPagePanel.setInfo();
                tweetHistoryPanelKeeper.setVisible(true);
                repaint();
                revalidate();
            }
        });
        //
        forwardPanel.setStringListener(text -> {
            remove(forwardPanel);
            forwardPanel.resetPanel();
            tweetHistoryPanelKeeper.setVisible(true);
            repaint();
            revalidate();
        });
        //
        personalPageMainPanel = new PersonalPageMainPanel();
        infoPanel = new InfoPanel();
        infoPanel.addStringListener(text -> {
            switch (text) {
                case "username", "biography" ->
                        personalPageMainPanel.updateDefaultInfoPanel();
                case "exit" -> {
                    remove(infoPanel);
                    repaint();
                    revalidate();
                }
            }
        });
        //
        personalPageMainPanel.setStringListener(text -> {
            if(text.equals("infoPanel")){
                infoPanel.setInfoPanel();
                add(infoPanel);
                repaint();
                revalidate();
            }
        });
        //
        chatMainPanel = new ChatMainPanel();
        contactsPanel = new ContactsPanel();
        JScrollPane contactsPanelKeeper = new JScrollPane(contactsPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        contactsPanelKeeper.setBounds(265,50,410,700);
        contactsPanelKeeper.setViewportView(contactsPanel);
        contactsPanelKeeper.getVerticalScrollBar().setUnitIncrement(16);
        contactsPanel.setStringListener(text -> {
            if(text.equals("search")){
                //reset All TODO
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(listMainPanel);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(contactsPanelKeeper);
                remove(chatMainPanel);
                resetTimeline();
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                listMainPanel.resetPanel();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.setInfo();
                add(exploreMainPanel);
            }
            else if(text.equals("setting")){
                remove(chatMainPanel);
                chatMainPanel.resetPanel();
                repaint();
                revalidate();
            }
            else {
                chatMainPanel.resetPanel();
                chatMainPanel.setChatId(Integer.parseInt(text));
                chatMainPanel.loadMessages();
                contactsPanel.loadChats();
                contactsPanel.repaint();
                contactsPanel.revalidate();
                add(chatMainPanel);
            }
            repaint();
            revalidate();
        });
        //
        menuPanel = new MenuPanel();
        //
        AuthenticationMainPanel authenticationMainPanel = new AuthenticationMainPanel();
        authenticationMainPanel.setStringListener(text -> {
            removeAll();
            add(menuPanel);
            repaint();
            revalidate();
        });
        //
        menuPanel.setStringListener(text -> {
            if(text.equals("profile")) {
                //reset explore chats ... TODO
                remove(notif);
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(listMainPanel);
                remove(exploreMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(contactsPanelKeeper);
                remove(chatMainPanel);
                resetTimeline();
                listMainPanel.resetPanel();
                contactsPanel.resetPanel();
                chatMainPanel.resetPanel();
                exploreMainPanel.resetPanel();
                personalPageMainPanel.setDefaultInfoPanel();
                add(personalPageMainPanel);
            }
            else if(text.equals("timeline")){
                //reset explore chats ... TODO
                remove(notif);
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(listMainPanel);
                remove(exploreMainPanel);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(contactsPanelKeeper);
                remove(chatMainPanel);
                listMainPanel.resetPanel();
                personalPageMainPanel.resetPanel();
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                infoPanel.resetPanel();
                timelineMainPanel.setInfo();
                exploreMainPanel.resetPanel();
                add(tweetHistoryPanelKeeper);
            }
            else if(text.equals("explore")){
                //reset All TODO
                remove(notif);
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(listMainPanel);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(contactsPanelKeeper);
                remove(chatMainPanel);
                resetTimeline();
                listMainPanel.resetPanel();
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.setInfo();
                add(exploreMainPanel);
            }
            else if(text.equals("chat")){
                //reset All TODO
                remove(notif);
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(listMainPanel);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(exploreMainPanel);
                listMainPanel.resetPanel();
                add(menuPanel);
                resetTimeline();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.resetPanel();
                contactsPanel.loadChats();
                add(contactsPanelKeeper);
            }
            else if(text.equals("lists")){
                //TODO
                remove(notif);
                remove(settingPanel);
                remove(contactsPanelKeeper);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(exploreMainPanel);
                remove(chatMainPanel);
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                add(menuPanel);
                resetTimeline();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.resetPanel();
                add(listMainPanel);
            }
            else if(text.equals("setting")){
                remove(notif);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(contactsPanelKeeper);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(exploreMainPanel);
                remove(chatMainPanel);
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                add(menuPanel);
                resetTimeline();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.resetPanel();
                settingPanel.setInfo();
                add(settingPanel);
            }
            else if(text.equals("notif")){
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(contactsPanelKeeper);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(exploreMainPanel);
                remove(chatMainPanel);
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                add(menuPanel);
                resetTimeline();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.resetPanel();
                add(notif);
            }
            else if(text.equals("logout")){
                remove(settingPanel);
                remove(listMainPanel);
                listMainPanel.resetPanel();
                remove(contactsPanelKeeper);
                remove(infoPanel);
                remove(personalPageMainPanel);
                remove(tweetHistoryPanelKeeper);
                remove(timelineMainPanel.getNewCommentPanel());
                remove(exploreMainPanel);
                remove(chatMainPanel);
                remove(notif);
                chatMainPanel.resetPanel();
                contactsPanel.resetPanel();
                add(menuPanel);
                resetTimeline();
                personalPageMainPanel.resetPanel();
                infoPanel.resetPanel();
                exploreMainPanel.resetPanel();
                remove(menuPanel);
                add(authenticationMainPanel);
            }
            repaint();
            revalidate();
        });
        //
        exploreMainPanel.setStringListener(text -> {
                if(text.startsWith("message")){
                    //reset All TODO
                    remove(notif);
                    remove(settingPanel);
                    remove(listMainPanel);
                    listMainPanel.resetPanel();
                    remove(listMainPanel);
                    remove(infoPanel);
                    remove(personalPageMainPanel);
                    remove(tweetHistoryPanelKeeper);
                    remove(timelineMainPanel.getNewCommentPanel());
                    remove(exploreMainPanel);
                    add(menuPanel);
                    resetTimeline();
                    listMainPanel.resetPanel();
                    personalPageMainPanel.resetPanel();
                    infoPanel.resetPanel();
                    exploreMainPanel.resetPanel();
                    int id = contactsPanel.makeNewChat
                            (Integer.parseInt(text.substring(7)));
                    chatMainPanel.setChatId(id);
                    contactsPanel.getUsersViewPanel().setUserId(id);
                    chatMainPanel.loadMessages();
                    contactsPanel.loadChats();
                    add(contactsPanelKeeper);
                    add(chatMainPanel);
                }
               else if(text.equals("list")){
                   //TODO
                    remove(notif);
                    remove(settingPanel);
                    remove(contactsPanelKeeper);
                    remove(infoPanel);
                    remove(personalPageMainPanel);
                    remove(tweetHistoryPanelKeeper);
                    remove(timelineMainPanel.getNewCommentPanel());
                    remove(exploreMainPanel);
                    remove(chatMainPanel);
                    chatMainPanel.resetPanel();
                    contactsPanel.resetPanel();
                    add(menuPanel);
                    resetTimeline();
                    personalPageMainPanel.resetPanel();
                    infoPanel.resetPanel();
                    exploreMainPanel.resetPanel();
                    add(listMainPanel);
               }
                repaint();
                revalidate();
        });
        //

        listMainPanel.setStringListener(text->{
            //TODO
            remove(notif);
            remove(listMainPanel);
            remove(listMainPanel);
            remove(infoPanel);
            remove(personalPageMainPanel);
            remove(tweetHistoryPanelKeeper);
            remove(timelineMainPanel.getNewCommentPanel());
            remove(contactsPanelKeeper);
            remove(chatMainPanel);
            resetTimeline();
            chatMainPanel.resetPanel();
            contactsPanel.resetPanel();
            personalPageMainPanel.resetPanel();
            infoPanel.resetPanel();
            exploreMainPanel.removeAll();
            exploreMainPanel.getSearchPanel().resetPanel();
            exploreMainPanel.getProfileMainPanel().setUserId(exploreMainPanel
                    .getSearchPanel().getUserId());
            exploreMainPanel.getProfileMainPanel().getProfileTopPanel().
                    setUserId(Integer.parseInt(text));
            exploreMainPanel.getProfileMainPanel().getProfileTopPanel().setInfo();
            exploreMainPanel.add(exploreMainPanel.getProfileMainPanel());
            exploreMainPanel.setInfo();
            add(exploreMainPanel);
            exploreMainPanel.setWitchPanel("list");
            repaint();
            revalidate();
        });
        //
        setLayout(null);
        setPreferredSize(new Dimension(2000,800));
        add(authenticationMainPanel);
        repaint();
        revalidate();
    }

    public void listenMe(String name){
        try {
            stringListener.stringEventOccurred(name);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(Images.START_PANEL_IMAGE,0,0,null);
    }

    public void resetTimeline() throws IOException {
        tweetHistoryKeeperMemento.removeAll(tweetHistoryKeeperMemento);
        tweetHistoryPanelKeeper.setViewportView(timelineMainPanel);
        timelineMainPanel.getNewCommentPanel().resetPanel();
        tweetHistoryPanelKeeper.setVisible(true);
        repaint();
        revalidate();
    }
}