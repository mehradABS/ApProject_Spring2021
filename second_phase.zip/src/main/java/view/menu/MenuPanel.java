package view.menu;

import resources.Colors;
import resources.Images;
import view.listeners.StringListener;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;


public class MenuPanel extends JPanel {

    private final JButton chatButton;
    private final JButton profileButton;
    private StringListener stringListener;
    private final JButton timelineButton;
    private final JButton exploreButton;
    private final JButton listsButton;
    private final JButton settingButton;
    private final JButton notifButton;
    private final JButton logoutButton;

    public MenuPanel() {
        profileButton = new JButton(Images.PROFILE_ICON);
        profileButton.setBounds(45,40,100,50);
        profileButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        profileButton.setFocusable(false);
        profileButton.addActionListener(e->{
            try {
                listenMe("profile");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        timelineButton = new JButton(Images.TIMELINE_ICON);
        timelineButton.setBounds(45,105,100,50);
        timelineButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        timelineButton.setFocusable(false);
        timelineButton.addActionListener(e -> {
            try {
                listenMe("timeline");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        exploreButton = new JButton(Images.EXPLORE_ICON);
        exploreButton.setBounds(45,170,100,50);
        exploreButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        exploreButton.setFocusable(false);
        exploreButton.addActionListener(e -> {
            try {
                listenMe("explore");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        chatButton = new JButton(Images.MESSAGE_BIG_ICON);
        chatButton.setBounds(45,235,100,50);
        chatButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        chatButton.setFocusable(false);
        chatButton.addActionListener(e -> {
            try {
                listenMe("chat");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        listsButton = new JButton(Images.LISTS);
        listsButton.setBounds(45,300,100,50);
        listsButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        listsButton.setFocusable(false);
        listsButton.addActionListener(e -> {
            try {
                listenMe("lists");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        settingButton = new JButton(Images.SETTING);
        settingButton.setBounds(45,365,100,50);
        settingButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        settingButton.setFocusable(false);
        settingButton.addActionListener(e -> {
            try {
                listenMe("setting");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        notifButton = new JButton(Images.NOTIFICATION);
        notifButton.setBounds(45,430,100,50);
        notifButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        notifButton.setFocusable(false);
        notifButton.addActionListener(e -> {
            try {
                listenMe("notif");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        logoutButton = new JButton(Images.LOGOUT);
        logoutButton.setBounds(45,495,100,50);
        logoutButton.setBackground(Color.decode(Colors.BUTTONS_COLOR));
        logoutButton.setFocusable(false);
        logoutButton.addActionListener(e -> {
            try {
                listenMe("logout");
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });
        //
        this.setLayout(null);
        this.setBackground(Color.decode(Colors.MENU_PANEL_COLOR));
        this.setBounds(50,50,200,700);
        this.add(profileButton);
        this.add(timelineButton);
        this.add(exploreButton);
        this.add(chatButton);
        this.add(listsButton);
        this.add(settingButton);
        this.add(notifButton);
        this.add(logoutButton);
    }

    public JButton getProfileButton() {
        return profileButton;
    }

    public void setStringListener(StringListener stringListener) {
        this.stringListener = stringListener;
    }

    public void listenMe(String name) throws IOException {
        stringListener.stringEventOccurred(name);
    }

    public JButton getTimelineButton() {
        return timelineButton;
    }

    public JButton getExploreButton() {
        return exploreButton;
    }
}
