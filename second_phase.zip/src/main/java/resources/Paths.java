package resources;

public class Paths {

    public static String CHAT_PATH;
    public static String CHAT_PATH_ID_COUNTER;
    public static String CHAT_IMAGE_PATH;
    public static String CHAT_DEFAULT_IMAGE_PATH;
    public static String MESSAGE_PATH;
    public static String TWEET_PATH;
    public static String COMMENT_PATH;
    public static String MESSAGE_PATH_ID_COUNTER;
    public static String TWEET_IMAGE_PATH;
    public static String TWEET_PATH_GET_ALL;
    public static String MESSAGE_PATH_GET_ALL;
    public static String COMMENT_PATH_GET_ALL;
    public static String USER_PATH_GET_ALL;
    public static String REPORT_PATH;
    public static String REPORT_PATH_ID_COUNTER;
    public static String REQUEST_PATH;
    public static String REQUEST_PATH_ID_COUNTER;
    public static String USER_PATH;
    public static String USER_PATH_ID_COUNTER;
    public static String USER_IMAGE_PATH;
    public static String USER_DEFAULT_IMAGE_PATH1;
    public static String USER_DEFAULT_IMAGE_PATH2;
}
