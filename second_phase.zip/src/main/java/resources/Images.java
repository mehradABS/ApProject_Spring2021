package resources;

import javax.swing.*;
import java.awt.*;

public class Images {

    public static Image START_PANEL_IMAGE;

    public static ImageIcon PROFILE_ICON ;

    public static  ImageIcon NEW_TWEET_ICON;

    public static  ImageIcon TIMELINE_ICON;

    public static  ImageIcon INFO_ICON;

    public static  ImageIcon SELECT_PHOTO_ICON;

    public static  ImageIcon TWEET_HISTORY_ICON;

    public static  ImageIcon CLOSE_ICON ;

    public static  ImageIcon BACK_ICON;

    public static  ImageIcon LIKE_ICON ;

    public static  ImageIcon DISLIKE_ICON;

    public static  ImageIcon REPLY_ICON ;

    public static  ImageIcon SHARE_ICON ;

    public static  ImageIcon BLOCK_ICON;

    public static ImageIcon REPORT_ICON;

    public static  ImageIcon MUTE_ICON;

    public static  ImageIcon UNBLOCK_ICON;

    public static  ImageIcon RETWEET_ICON ;

    public static  ImageIcon SEARCH_ICON ;

    public static  ImageIcon SEARCH_ICON_SMALL;

    public static  ImageIcon EXPLORE_ICON;

    public static  ImageIcon MESSAGE_ICON;

    public static  ImageIcon UNMUTE_ICON;

    public static  ImageIcon MESSAGE_BIG_ICON;


    public static  ImageIcon SEND_ICON ;

    public static  ImageIcon ADD_LIST;

    public static  ImageIcon REMOVE_LIST;

    public static  ImageIcon LISTS;

    public static  ImageIcon ADD_PERSON;

    public static  ImageIcon REMOVE_PERSON;

    public static  ImageIcon SETTING;

    public static  ImageIcon SETTING1;

    public static  ImageIcon NOTIFICATION;

    public static  ImageIcon ACCEPT;

    public static  ImageIcon DELETE;

    public static ImageIcon LOGOUT;
}
