package controller;


import db.Context;

public class MainController {

    protected static int currentUserId;

    protected final Context context;

    public MainController() {
        context = new Context();
    }

    public static void setCurrentUserId(int currentUserId) {
        MainController.currentUserId = currentUserId;
    }

    public static int getCurrentUserId() {
        return currentUserId;
    }
}
