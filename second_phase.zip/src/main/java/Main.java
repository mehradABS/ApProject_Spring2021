import config.MainConfig;
import view.FatherFrame;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
       new MainConfig();
       new FatherFrame();
    }
}
